#!/usr/bin/env python3
"""
Complete End-to-End Test of Chart Rendering Fix
Tests all components of the data pipeline to ensure charts render correctly
"""

import json
import sys
sys.path.insert(0, '/Users/rutujadhage/agentic-rag-nl2sql (PO)')

from agent_visualization_mapper import VisualizationMapper

print("=" * 80)
print("END-TO-END CHART RENDERING TEST")
print("=" * 80)

# Initialize mapper
mapper = VisualizationMapper()

# Test Case 1: Bar Chart
print("\n### TEST 1: Bar Chart Rendering Path ###\n")

query = "Show a bar chart of total amount by purchase order"
columns = ['purchase_order', 'total_amount']
rows = [
    ('PO-009', 8900.0),
    ('PO-006', 7250.0),
    ('PO-008', 6500.0),
    ('PO-007', 5000.0),
    ('PO-005', 4500.0),
    ('PO-004', 3800.0),
    ('PO-003', 3200.0),
    ('PO-002', 2500.0),
    ('PO-001', 1800.0),
    ('PO-010', 9200.0)
]

print(f"Query: {query}")
print(f"Columns: {columns}")
print(f"Rows: {len(rows)} records")

# Step 1: Map to visualization
viz = mapper.map(query, columns, rows)

print(f"\n✅ Visualization mapped successfully")
print(f"   Chart Type: {viz['chart_type']}")
print(f"   Title: {viz['title']}")
print(f"   X Key (used as): {viz['x_key']}")
print(f"   Y Key (used as): {viz['y_key']}")
print(f"   Data Points: {len(viz['data'])}")

# Step 2: Verify data format
print(f"\n✅ Verifying data format for Chart.js...")
first_point = viz['data'][0]
print(f"   First data point: {first_point}")
assert 'name' in first_point, "Missing 'name' key - Chart.js needs d['name']"
assert 'value' in first_point, "Missing 'value' key - Chart.js needs d['value']"
print(f"   ✓ Has 'name' key (for X axis labels)")
print(f"   ✓ Has 'value' key (for Y axis values)")

# Step 3: Simulate frontend JavaScript processing
print(f"\n✅ Simulating frontend JavaScript processing...")
labels = [d['name'] for d in viz['data']]
values = [float(d['value']) for d in viz['data']]
print(f"   Labels extracted: {labels}")
print(f"   Values extracted: {values}")

# Step 4: Test JSON serialization
print(f"\n✅ Testing JSON serialization (required for HTTP response)...")
try:
    json_str = json.dumps(viz)
    print(f"   Serialized successfully ({len(json_str)} bytes)")
    
    # Verify deserialization
    parsed = json.loads(json_str)
    print(f"   Deserialized successfully")
    print(f"   Round-trip test: {len(parsed['data'])} data points preserved")
except Exception as e:
    print(f"   ❌ Serialization failed: {e}")
    sys.exit(1)

# Test Case 2: Different Query Type
print(f"\n### TEST 2: Status Bar Chart ###\n")

query2 = "Draw a bar chart of total purchase amount by status"
columns2 = ['status', 'total_value']
rows2 = [
    ('DRAFT', 38000.0),
    ('REJECTED', 30000.0),
    ('APPROVED', 27000.0)
]

print(f"Query: {query2}")
print(f"Data Points: {len(rows2)}")

viz2 = mapper.map(query2, columns2, rows2)

print(f"✅ Second chart mapped")
print(f"   Chart Type: {viz2['chart_type']}")
print(f"   Data Points: {len(viz2['data'])}")
print(f"   First point: {viz2['data'][0]}")

# Test Case 3: Frontend Rendering Simulation
print(f"\n### TEST 3: Frontend Chart.js Simulation ###\n")

def simulate_chart_rendering(viz_data):
    """Simulates what frontend JavaScript does"""
    print(f"   1. Received visualization JSON with chart_type='{viz_data['chart_type']}'")
    
    # Route by type
    if viz_data['chart_type'] != 'bar':
        print(f"   ❌ Unexpected chart type: {viz_data['chart_type']}")
        return False
    
    # Extract labels and values
    try:
        labels = [d[viz_data['x_key']] for d in viz_data['data']]
        values = [float(d[viz_data['y_key']]) for d in viz_data['data']]
        print(f"   2. Extracted labels and values from data")
        print(f"      - {len(labels)} labels: {labels[:3]}...")
        print(f"      - {len(values)} values: {values[:3]}...")
    except KeyError as e:
        print(f"   ❌ Data format error - missing key: {e}")
        return False
    
    # Create Chart.js config
    config = {
        "type": "bar",
        "data": {
            "labels": labels,
            "datasets": [{
                "label": viz_data['y_key'],
                "data": values,
                "backgroundColor": "rgba(75, 192, 192, 0.7)"
            }]
        },
        "options": {
            "responsive": True,
            "maintainAspectRatio": False
        }
    }
    
    print(f"   3. Created Chart.js configuration")
    print(f"      - Type: {config['type']}")
    print(f"      - Labels: {len(config['data']['labels'])}")
    print(f"      - Values: {len(config['data']['datasets'][0]['data'])}")
    
    try:
        json.dumps(config)
        print(f"   4. Configuration is JSON-serializable ✓")
    except:
        print(f"   ❌ Configuration cannot be serialized to JSON")
        return False
    
    return True

print("Simulating Bar Chart #1:")
success1 = simulate_chart_rendering(viz)

print("\nSimulating Bar Chart #2:")
success2 = simulate_chart_rendering(viz2)

# Final Summary
print(f"\n" + "=" * 80)
if success1 and success2:
    print("✅ ALL TESTS PASSED - Charts should render correctly!")
    print("\nNext Steps:")
    print("1. Open http://localhost:5000 in browser")
    print("2. Type: 'Show a bar chart of total amount by purchase order'")
    print("3. Verify 10 bars appear with correct labels and values")
    print("4. Check browser console (F12) for messages:")
    print("   - Should see: ✅ Bar chart rendered: chart-0")
    print("   - Should NOT see red error messages")
else:
    print("❌ TESTS FAILED - Check errors above")
    sys.exit(1)
