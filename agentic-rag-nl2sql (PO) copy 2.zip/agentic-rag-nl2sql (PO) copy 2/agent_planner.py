class PlannerAgent:
    def _is_greeting_misspelling(self, text: str) -> bool:
        """
        Detect greeting misspellings using lenient pattern matching.
        Handles: helo, helloo, hlo, hii, hiiii, heyy, etc.
        
        IMPORTANT: Only match full words, not fragments.
        Don't match "which", "white", etc. that contain "h" + vowel patterns.
        """
        # Remove duplicate letters (helloo → helo, heyy → hey, hiiii → hi)
        deduplicated = ""
        prev_char = ""
        for char in text:
            if char != prev_char:
                deduplicated += char
            prev_char = char
        
        # Only match greeting cores as WHOLE WORDS or at word boundaries
        # Use word boundaries to avoid false positives like "which" → "hel"
        greeting_cores = [" hi ", " hello ", " hey ", " greet", " welc"]
        # Add space padding for word boundary checking
        padded_text = " " + deduplicated + " "
        
        # First try exact matches with word boundaries
        if any(core in padded_text for core in greeting_cores):
            return True
        
        # Now try more flexible pattern matching for greeting-like words
        # Remove vowels to create skeleton and match against greeting skeletons
        import re
        skeleton = re.sub(r'[aeiou]', '', deduplicated.lower())
        
        # Greeting skeletons (hello→hll, hi→h, hey→hy, helo→hl, etc.)
        greeting_skeletons = ['h', 'hll', 'hy', 'grt', 'wlc']
        
        # Check if the skeleton matches a greeting pattern
        # Must start with the greeting pattern and have length 1-5 chars different
        for gs in greeting_skeletons:
            if skeleton.startswith(gs) and len(skeleton) <= len(gs) + 2:
                return True
        
        return False

    def _is_goodbye_misspelling(self, text: str) -> bool:
        """
        Detect goodbye misspellings using lenient pattern matching.
        Handles: byee, byebye, goodbyee, seee you, etc.
        """
        # Remove duplicate letters
        deduplicated = ""
        prev_char = ""
        for char in text:
            if char != prev_char:
                deduplicated += char
            prev_char = char
        
        goodbye_cores = ["bye", "good", "farewel", "see ya"]
        return any(core in deduplicated for core in goodbye_cores)

    def _is_thanks_misspelling(self, text: str) -> bool:
        """
        Detect thank you misspellings using lenient pattern matching.
        Handles: thankss, thannk, apreciate, etc.
        """
        # Remove duplicate letters
        deduplicated = ""
        prev_char = ""
        for char in text:
            if char != prev_char:
                deduplicated += char
            prev_char = char
        
        thanks_cores = ["thank", "apprec", "thx"]
        return any(core in deduplicated for core in thanks_cores)

    def detect_greeting_or_goodbye(self, user_query: str) -> str | None:
        """
        Detect greetings, goodbyes, and thank yous BEFORE intent classification.
        Handles misspellings gracefully (helo, helloo, byee, etc).
        
        Returns:
        - 'greeting' → greeting message detected
        - 'goodbye' → goodbye message detected
        - 'thanks' → thank you message detected
        - None → continue with normal intent classification
        """
        q = user_query.lower().strip()
        
        # Greeting patterns (exact and misspellings)
        greetings = [
            " hello ", " hi ", " hey ", "good morning", "good afternoon",
            "good evening", "greetings", "welcome to"
        ]
        
        # Goodbye patterns (exact and misspellings)
        goodbyes = [
            " bye ", "bye bye", "goodbye", "see you", "see you later",
            "farewell", "talk to you later", "ttyl", "see ya"
        ]
        
        # Thank you patterns (exact and misspellings)
        thanks = [
            "thank you", "thanks", "appreciate it", "appreciate",
            "much appreciated", "thx"
        ]
        
        # Add spaces for word boundary matching
        padded_q = " " + q + " "
        
        # Check exact matches first (with word boundaries)
        for greeting in greetings:
            if greeting in padded_q or greeting in q:  # Some patterns don't need boundaries
                return "greeting"
        
        for goodbye in goodbyes:
            if goodbye in padded_q or goodbye in q:
                return "goodbye"
        
        for thank in thanks:
            if thank in padded_q or thank in q:
                return "thanks"
        
        # Check for misspellings (lenient)
        if self._is_greeting_misspelling(q):
            return "greeting"
        
        if self._is_goodbye_misspelling(q):
            return "goodbye"
        
        if self._is_thanks_misspelling(q):
            return "thanks"
        
        return None

    def detect_identity_or_product_question(self, user_query: str) -> str | None:
        """
        Detect identity and product description questions that should be answered
        by LLM-only (no SQL, no RAG).
        
        Returns:
        - 'identity' → "what is your name", "who are you", etc.
        - 'product' → "what is kraya", "what is kraya ai", etc.
        - None → continue with normal intent classification
        """
        q = user_query.lower().strip()
        
        # === IDENTITY QUESTIONS ===
        identity_patterns = [
            "what is your name",
            "who are you",
            "who am i talking to",
            "what's your name",
        ]
        
        for pattern in identity_patterns:
            if pattern in q:
                return "identity"
        
        # === PRODUCT/COMPANY DESCRIPTION QUESTIONS ===
        product_patterns = [
            "what is kraya",
            "what's kraya",
            "tell me about kraya",
            "describe kraya",
        ]
        
        for pattern in product_patterns:
            if pattern in q:
                return "product"
        
        return None

    def classify_intent(self, user_query: str) -> str:
        """
        INDUSTRY-GRADE Intent Classification
        
        Carefully separates DATABASE vs GENERAL questions.
        - 'rag_sql' → DATABASE question (data lookup, aggregation, business queries)
        - 'direct' → GENERAL question (knowledge, opinion, creative, non-data-related)
        
        IMPORTANT: Lean towards 'rag_sql' if uncertain.
        Only use 'direct' for clearly non-database questions.
        
        KEY FIX: "What is" questions about data (totals, counts, items) should be DATA queries,
        not general knowledge questions. Only use 'direct' for definitional "what is" (concepts, things).
        """
        q = user_query.lower()

        # === EXPLICIT DATABASE QUERIES (MUST be rag_sql) ===
        # These ALWAYS go to database, never to general Q&A
        database_keywords = [
            "list ", "show ", "which ", "how many", "what items",
            "total ", "sum of", "average ", "count", "highest", "lowest",
            "most ", "least ", "recent ", "top ", "group by",
            "purchase order", "po ", "item", "vendor", "company",
            "filter", "search for", "find", "where", "order by"
        ]
        
        # Check if this is explicitly a database question
        for keyword in database_keywords:
            if keyword in q:
                return "rag_sql"

        # === EXPLICIT NON-DATABASE (GENERAL) QUESTIONS ===
        # ONLY these bypass DB. Everything else tries RAG + SQL.
        general_keywords = [
            # Knowledge and explanation (non-data, conceptual)
            "define ", "explain ", "how does", "meaning of",
            "who was ", "who is ", "biography", "history of",
            
            # Creative and opinion-based (impossible for DB)
            "tell me a joke", "joke", "poem", "write ", "compose", "create",
            "opinion", "opinion on", "think about", "recommend a",
            
            # Real-world data (NOT in our business database)
            "weather", "forecast", "temperature", "climate",
            "news", "current events", "latest news",
            "translate", "translation",
            "movie", "book", "song", "actor", "director",
            
            # Predictions and speculative
            "will win", "who will", "predict", "prediction",
            "possible", "likely", "chance", "probability",
            
            # Instructions and how-tos (not data)
            "how to ", "recipe", "instructions", "steps", "guide",
            "philosophy", "ethics", "moral",
        ]

        # Check for EXPLICIT general indicators (strict matching)
        for keyword in general_keywords:
            if keyword in q:
                return "direct"

        # === DEFAULT: TRY DATABASE ===
        # If not explicitly "general", assume it MIGHT be database-related.
        # Let RAG + SQL handle it. If no results, show "not found in database".
        # This way, questions like "List all employees" or "revenue by category"
        # always go through the pipeline instead of being rejected upfront.
        return "rag_sql"
