import re

class SQLValidatorAgent:
    def __init__(self):
        # Track invalid columns to prevent retry reuse
        self.invalid_columns = set()
    
    def reset_invalid_columns(self):
        """Reset the invalid columns tracking for new queries."""
        self.invalid_columns = set()
    
    def add_invalid_column(self, column_name: str):
        """Mark a column as invalid (likely doesn't exist)."""
        self.invalid_columns.add(column_name.lower())
    
    def validate(self, sql: str, context: list = None) -> dict:
        """
        Validate SQL query.
        
        Args:
            sql: SQL query string
            context: Optional metadata chunks for column validation
            
        Returns:
            dict with 'valid' (bool) and 'error' (str or None)
        """
        if not sql or not isinstance(sql, str):
            return {'valid': False, 'error': 'Empty SQL query'}

        sql_strip = sql.strip()
        sql_upper = sql_strip.upper()

        # Allow only SELECT (allow WITH/SELECT prefixes)
        if not re.match(r'^(WITH\s+|SELECT\s+)', sql_upper):
            return {'valid': False, 'error': 'Query must start with SELECT or WITH'}

        # Block dangerous keywords (whole-word match)
        forbidden = ["DROP", "DELETE", "UPDATE", "INSERT", "ALTER", "TRUNCATE", "EXEC", "COPY"]
        for word in forbidden:
            if re.search(r"\b" + re.escape(word) + r"\b", sql_upper):
                return {'valid': False, 'error': f'Dangerous keyword {word} not allowed'}

        # Check if SQL contains previously invalid columns (stop retry reuse)
        for invalid_col in self.invalid_columns:
            if re.search(rf'\b{re.escape(invalid_col)}\b', sql.lower()):
                return {'valid': False, 'error': f'Column "{invalid_col}" does not exist in database (previously failed)'}

        # Extract column names from SQL and validate against metadata
        if context:
            validation_result = self._validate_columns(sql, context)
            if not validation_result['valid']:
                return validation_result

        # Semicolon is preferred but not strictly required — append later if needed
        return {'valid': True, 'error': None}

    def _validate_columns(self, sql: str, context: list) -> dict:
        """
        Validate that columns referenced in SQL exist in metadata.
        
        Args:
            sql: SQL query string
            context: List of metadata chunks
            
        Returns:
            dict with 'valid' (bool) and 'error' (str or None)
        """
        # Extract available columns from metadata
        available_columns = set()
        available_tables = set()
        
        for chunk in context:
            text = chunk.get("text", "").lower()
            table = chunk.get("table", "").lower()
            
            if table:
                available_tables.add(table)
            
            # Extract column definitions from schema text
            # Look for patterns like "column_name (type)" or "- column_name:"
            lines = text.split('\n')
            for line in lines:
                line = line.strip().lower()
                # Match patterns like "column_name type" or "- column_name:"
                if re.match(r'^[\w_]+\s+\(?\w+', line) or re.match(r'^-\s+[\w_]+', line):
                    # Extract the first word as column name
                    words = line.split()
                    if words:
                        col = words[0].replace('-', '').strip()
                        if col and col not in ['type', 'description', 'example']:
                            available_columns.add(col)
        
        # Extract columns referenced in SQL
        # This is a simple regex-based extraction; not perfect but catches most cases
        sql_lower = sql.lower()
        
        # Find columns in common patterns: SELECT col, WHERE col, GROUP BY col, ORDER BY col
        patterns = [
            r'select\s+([\w\.,\s\*()]+)\s+from',  # SELECT clause
            r'where\s+([\w\.,\s<>=!]+)',            # WHERE clause
            r'group\s+by\s+([\w\.,\s]+)',          # GROUP BY
            r'order\s+by\s+([\w\.,\s()]+)',        # ORDER BY
        ]
        
        referenced_columns = set()
        for pattern in patterns:
            matches = re.findall(pattern, sql_lower)
            for match in matches:
                # Split by comma and extract column names
                cols = re.findall(r'\b([\w_]+)\b', match)
                for col in cols:
                    if col not in ['*', 'and', 'or', 'null', 'true', 'false', 'from', 'as', 'desc', 'asc', 'limit', 'offset']:
                        referenced_columns.add(col)
        
        # For now, we're lenient with column validation since the exact column names
        # are hard to extract without full parsing. Focus on catching obvious errors.
        # The SQL executor will catch actual column errors during execution.
        
        return {'valid': True, 'error': None}
