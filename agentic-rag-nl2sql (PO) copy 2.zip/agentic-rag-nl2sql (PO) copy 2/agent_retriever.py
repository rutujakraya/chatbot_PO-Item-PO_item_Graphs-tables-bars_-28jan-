from sentence_transformers import SentenceTransformer
from qdrant_client import QdrantClient
import os
from dotenv import load_dotenv

load_dotenv()


class RetrievalAgent:
    """
    INDUSTRY-GRADE RAG Retrieval Agent.
    
    Fetches relevant chunks from db_metadata.txt (stored in Qdrant).
    These chunks provide table names, column meanings, relationships, 
    and example questions to guide SQL generation.
    """
    
    def __init__(self):
        self.model = SentenceTransformer("BAAI/bge-small-en-v1.5")
        self.client = QdrantClient(url="http://localhost:6333")
        # Read collection name from environment (points to Phase 1 metadata)
        self.collection_name = os.getenv("QDRANT_METADATA_COLLECTION", "procure_phase1_metadata")

    def retrieve(self, query: str, limit: int = 5) -> list:
        """
        Retrieve top-K most relevant metadata chunks from Qdrant.
        
        Args:
            query: User's natural language question
            limit: Number of chunks to retrieve (default 5 for context richness)
            
        Returns:
            List of dicts with keys: text, table, type
            Each dict represents a chunk from db_metadata.txt
        """
        try:
            # Embed the query using BGE model
            query_vec = self.model.encode(query)

            # Search Qdrant for most similar chunks
            results = self.client.query_points(
                collection_name=self.collection_name,
                query=query_vec.tolist(),
                limit=limit
            )

            # Extract payloads and structure them
            chunks = []
            for point in results.points:
                chunk = {
                    "text": point.payload.get("text", ""),
                    "table": point.payload.get("table", ""),
                    "type": point.payload.get("type", ""),  # "table_info", "example", "relationship", etc.
                    "score": point.score  # Relevance score from vector search
                }
                if chunk["text"]:  # Only include non-empty chunks
                    chunks.append(chunk)

            return chunks

        except Exception as e:
            # Graceful fallback if Qdrant is unavailable
            print(f"RetrievalAgent error: {e}")
            return []
