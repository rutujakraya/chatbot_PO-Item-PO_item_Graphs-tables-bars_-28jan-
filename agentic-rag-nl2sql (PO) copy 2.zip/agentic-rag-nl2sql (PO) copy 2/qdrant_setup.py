from qdrant_client import QdrantClient
from qdrant_client.models import VectorParams, Distance

client = QdrantClient(
    url="http://localhost:6333"
)

COLLECTION_NAME = "rag_schema_chunks"

# Delete if already exists (safe for dev)
client.recreate_collection(
    collection_name=COLLECTION_NAME,
    vectors_config=VectorParams(
        size=384,          # BGE-small embedding size
        distance=Distance.COSINE
    )
)

print("Qdrant collection created:", COLLECTION_NAME)
