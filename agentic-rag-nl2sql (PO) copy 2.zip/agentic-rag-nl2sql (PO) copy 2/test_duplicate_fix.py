#!/usr/bin/env python3
"""
Test that the fix suppresses duplicate table rendering
"""

import json
from decimal import Decimal
from datetime import datetime

# Simulate formatter behavior
class MockFormatter:
    def format(self, user_query, sql, result, skip_text=False):
        if skip_text:
            return ""  # Empty string when visualization is used
        
        # Return a detailed text table (what we want to avoid)
        return "po_no | status | total | created_at\n------|--------|-------|-----\nPO-001|DRAFT|5000|2026-01-22\n..."

# Simulate visualization mapper
class MockMapper:
    def map(self, user_query, columns, rows):
        # Return table visualization
        return {
            "chart_type": "table",
            "columns": [
                {"key": "po_no", "label": "PO Number"},
                {"key": "status", "label": "Status"},
                {"key": "total", "label": "Total"},
                {"key": "created_at", "label": "Created At"}
            ],
            "data": [
                {
                    "po_no": row[0],
                    "status": row[1],
                    "total": row[2],
                    "created_at": row[3]
                }
                for row in rows
            ]
        }

# Test
formatter = MockFormatter()
mapper = MockMapper()

columns = ['po_no', 'status', 'total', 'created_at']
rows = [
    ['PO-001', 'DRAFT', 5000.0, '2026-01-22T17:47:21.384554'],
    ['PO-002', 'APPROVED', 6000.0, '2026-01-21T17:47:21.384971'],
]

print("=" * 70)
print("TEST: Duplicate Table Rendering Fix")
print("=" * 70)

# OLD WAY (BROKEN)
print("\n❌ OLD WAY (Results in duplicate tables):")
print("-" * 70)
text_old = formatter.format("List POs", "SELECT *", {"columns": columns, "rows": rows}, skip_text=False)
viz_old = mapper.map("List POs", columns, rows)
response_old = {
    "text": text_old,
    "visualization": viz_old
}
print("Text response:")
print(f"  {repr(text_old)}")
print(f"\nVisualization response:")
print(f"  chart_type: {viz_old['chart_type']}")
print("\nResult: User sees TABLE twice (text + HTML)")

# NEW WAY (FIXED)
print("\n\n✅ NEW WAY (Only one table shown):")
print("-" * 70)
viz_new = mapper.map("List POs", columns, rows)
has_visualization = viz_new.get("chart_type") != "none"
text_new = formatter.format("List POs", "SELECT *", {"columns": columns, "rows": rows}, skip_text=has_visualization)

response_new = {
    "text": text_new,
    "visualization": viz_new if has_visualization else None
}

print("Text response:")
print(f"  {repr(text_new)} (empty because skip_text=True)")
print(f"\nVisualization response:")
print(f"  chart_type: {viz_new['chart_type']}")
print("\nResult: User sees TABLE once (HTML only)")

# Verify JSON serialization
print("\n\n✅ JSON Serialization Test:")
print("-" * 70)
json_str = json.dumps(response_new)
print(f"Response can be serialized: ✓")
parsed = json.loads(json_str)
print(f"Text in response: {repr(parsed['text'])}")
print(f"Has visualization: {parsed['visualization'] is not None}")
print(f"Visualization type: {parsed['visualization']['chart_type']}")

# Frontend logic simulation
print("\n\n✅ Frontend Rendering Logic:")
print("-" * 70)
if parsed.get("text"):
    print("Rendering text element: YES")
else:
    print("Rendering text element: NO ✓ (Suppressed because empty)")

if parsed.get("visualization") and parsed["visualization"].get("chart_type") != "none":
    print(f"Rendering visualization: YES ({parsed['visualization']['chart_type']} chart)")
else:
    print("Rendering visualization: NO")

print("\n" + "=" * 70)
print("✅ TEST PASSED: Only one table will be rendered")
print("=" * 70)
