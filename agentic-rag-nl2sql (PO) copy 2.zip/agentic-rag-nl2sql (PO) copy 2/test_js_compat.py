import sys
import json
sys.path.insert(0, '/Users/rutujadhage/agentic-rag-nl2sql (PO)')

# Test the chart rendering with Canvas fix
from agent_visualization_mapper import VisualizationMapper

# Create mapper
mapper = VisualizationMapper()

# Test 1: Bar chart with purchase orders
query1 = "Show a bar chart of total amount by purchase order"
columns1 = ['purchase_order', 'total_amount']
rows1 = [('PO-009', 8900.0), ('PO-006', 7250.0), ('PO-008', 6500.0), ('PO-007', 5000.0)]

result1 = mapper.map(query1, columns1, rows1)
print("\n=== BAR CHART TEST ===")
print(f"Chart Type: {result1.get('chart_type')}")
print(f"Title: {result1.get('title')}")
print(f"X Key: {result1.get('x_key')}")
print(f"Y Key: {result1.get('y_key')}")
print(f"Data Count: {len(result1.get('data', []))}")
print(f"\nFirst 2 data points:")
for i, point in enumerate(result1.get('data', [])[:2]):
    print(f"  {i}: {point}")

# Verify this matches what JavaScript expects
print("\n=== JAVASCRIPT EXPECTATIONS ===")
print("Chart.js expects labels from d['name'] and values from d['value']")
print("Current data format check:")
test_point = result1.get('data', [{}])[0]
print(f"  test_point['name'] = {test_point.get('name')} ✅" if 'name' in test_point else f"  'name' key missing ❌")
print(f"  test_point['value'] = {test_point.get('value')} ✅" if 'value' in test_point else f"  'value' key missing ❌")

# Test serialization
try:
    json_str = json.dumps(result1)
    print(f"\n✅ JSON serialization successful ({len(json_str)} bytes)")
except Exception as e:
    print(f"\n❌ JSON serialization failed: {e}")
