# GitHub Upload Guide - What to Exclude & Include

## ✅ Files/Folders to INCLUDE in GitHub

### Core Application Code
- ✓ `app.py` - Flask application entry point
- ✓ `agent_*.py` - All 10 agent modules
- ✓ `db_init.py` - Database initialization script
- ✓ `qdrant_setup.py` - Vector DB setup script
- ✓ `db_metadata.txt` - Database schema reference

### Frontend Assets
- ✓ `static/index.html` - Web UI
- ✓ `static/app.js` - Frontend logic
- ✓ `static/style.css` - Styling

### Configuration & Documentation
- ✓ `requirements.txt` - Python dependencies list
- ✓ `README.md` - Project overview
- ✓ All `.md` documentation files:
  - ✓ `SETUP_INSTALLATION_GUIDE.md`
  - ✓ `ARCHITECTURE_AND_WORKFLOW.md`
  - ✓ `QUICK_REFERENCE_GUIDE.md`
  - ✓ `SEMANTIC_*.md` files
  - ✓ Other documentation files

### Configuration Templates
- ✓ `.env.example` - Template for environment variables (NO secrets)
- ✓ `.gitignore` - Git ignore rules

---

## ❌ Files/Folders to EXCLUDE from GitHub

### Virtual Environment
```
❌ .venv/                  # Virtual environment folder
                          # Size: ~500MB, system-specific
                          # Each system creates its own
```

### Environment Variables
```
❌ .env                    # Contains secrets like passwords
                          # DB_PASSWORD, SECRET_KEY, API keys
                          # NEVER commit this!
```

### Database Files
```
❌ *.db                    # SQLite database files
❌ *.sqlite               # SQLite databases
❌ postgres_data/         # PostgreSQL data directory
❌ pgadmin_data/          # pgAdmin config
```

### Python Cache & Build
```
❌ __pycache__/           # Python bytecode cache
❌ *.pyc                  # Compiled Python files
❌ *.pyo                  # Optimized Python files
❌ *.egg-info/            # Egg installation info
❌ dist/                  # Distribution build folder
❌ build/                 # Build artifacts
```

### IDE & Editor Files
```
❌ .vscode/               # VS Code settings (optional - can share)
❌ .idea/                 # IntelliJ IDE
❌ *.swp                  # Vim swap files
❌ *.swo                  # Vim swap files
❌ *~                     # Backup files
❌ .DS_Store              # Mac system files
```

### Logs & Temporary Files
```
❌ *.log                  # Application logs
❌ logs/                  # Log directory
❌ tmp/                   # Temporary files
❌ temp/                  # Temporary files
❌ .cache/                # Cache files
```

### Vector Database
```
❌ qdrant_storage/        # Qdrant data directory
❌ qdrant_data/           # Qdrant local data
```

---

## 📝 Recommended .gitignore File

Create a `.gitignore` file in project root with:

```
# Virtual Environment
.venv/
venv/
ENV/
env/

# Environment Variables
.env
.env.local
.env.*.local

# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
pip-wheel-metadata/
share/python-wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# IDE
.vscode/
.idea/
*.swp
*.swo
*~
.DS_Store

# Logs
*.log
logs/
*.log.*

# Database & Data
*.db
*.sqlite
*.sqlite3
postgres_data/
pgadmin_data/
qdrant_storage/
qdrant_data/

# Temporary files
tmp/
temp/
.cache/
*.tmp

# OS specific
Thumbs.db
.DS_Store
```

---

## 🔐 Environment Variables - Secure Setup

### Option 1: Template File (.env.example)

**Create `.env.example` in GitHub** with placeholders:

```bash
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=procure_phase1_first3tables
DB_USER=postgres
DB_PASSWORD=your_secure_password_here

# Ollama Configuration
OLLAMA_MODEL=llama2
OLLAMA_HOST=http://localhost:11434

# Qdrant Configuration
QDRANT_HOST=localhost
QDRANT_PORT=6333
QDRANT_API_KEY=

# Application Configuration
FLASK_ENV=development
FLASK_DEBUG=True
SECRET_KEY=your_secret_key_here
```

**Users copy to actual .env:**
```bash
cp .env.example .env
# Then edit .env with their actual values
```

### Option 2: Document Template

In **SETUP_INSTALLATION_GUIDE.md**, show:
```bash
# Create .env file with these values:
DB_HOST=localhost
DB_PASSWORD=<your postgres password>
...
```

---

## ✅ GitHub Upload Checklist

Before uploading to GitHub:

- [ ] **Remove .venv folder**: `rm -rf .venv`
- [ ] **Remove .env file**: `rm .env` (keep .env.example)
- [ ] **Remove __pycache__**: `find . -type d -name __pycache__ -exec rm -rf {} +`
- [ ] **Remove .pyc files**: `find . -type f -name "*.pyc" -delete`
- [ ] **Create .gitignore** with content above
- [ ] **Verify git status**: `git status` (no .venv, .env, etc.)
- [ ] **Create .env.example** with template values
- [ ] **Add documentation** (setup + architecture guides)

---

## 🚀 For New Users Downloading from GitHub

### Step 1: Clone Repository
```bash
git clone https://github.com/your-user/agentic-rag-nl2sql.git
cd agentic-rag-nl2sql
```

### Step 2: Create Environment Variables
```bash
# Copy template
cp .env.example .env

# Edit with your values
nano .env  # or your editor
# Update: DB_PASSWORD, SECRET_KEY, etc.
```

### Step 3: Create Virtual Environment
```bash
python3 -m venv .venv
source .venv/bin/activate  # Mac/Linux
# or
.venv\Scripts\activate      # Windows
```

### Step 4: Install Dependencies
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### Step 5: Run Setup Scripts
```bash
python3 db_init.py          # Initialize database
python3 qdrant_setup.py     # Setup vector DB
```

### Step 6: Start Application
```bash
# Ensure services running (Ollama, Qdrant, PostgreSQL)
flask run
```

---

## 📊 Typical GitHub Repository Size

**Before cleanup** (with .venv):
```
├── .venv/              ~500 MB ❌
├── __pycache__/        ~50 MB  ❌
├── Source code         ~2 MB   ✓
└── Documentation       ~1 MB   ✓
───────────────────────
Total: ~553 MB
```

**After cleanup** (without .venv, cache, etc):
```
├── Source code         ~2 MB   ✓
├── Documentation       ~1 MB   ✓
└── Config templates    ~0.1 MB ✓
───────────────────────
Total: ~3 MB (100x smaller!)
```

---

## 🔐 Secret Management Best Practices

### ❌ NEVER commit:
- Database passwords
- API keys
- SECRET_KEY values
- Authentication tokens
- Private URLs
- Internal IP addresses

### ✅ DO commit:
- .env.example (template with placeholders)
- Configuration constants (port numbers, timeouts)
- Service endpoints (localhost references)
- Public documentation

### 🛡️ If accidentally committed:
```bash
# Remove from git history
git rm --cached .env
git commit --amend --no-edit
git push origin --force-with-lease

# Add to .gitignore
echo ".env" >> .gitignore
git add .gitignore
git commit -m "Add .env to gitignore"
git push
```

---

## 📋 GitHub Repository Template

**Recommended structure in GitHub:**

```
agentic-rag-nl2sql/
├── .gitignore                          ✓
├── .env.example                        ✓ (template only)
├── README.md                           ✓
├── requirements.txt                    ✓
│
├── SETUP_INSTALLATION_GUIDE.md         ✓
├── ARCHITECTURE_AND_WORKFLOW.md        ✓
├── QUICK_REFERENCE_GUIDE.md            ✓
│
├── app.py                              ✓
├── agent_orchestrator.py               ✓
├── agent_semantic_analyzer.py          ✓
├── agent_planner.py                    ✓
├── agent_retriever.py                  ✓
├── agent_sql_generator.py              ✓
├── agent_sql_validator.py              ✓
├── agent_sql_executor.py               ✓
├── agent_response_formatter.py         ✓
├── agent_visualization_mapper.py       ✓
├── agent_visualization.py              ✓
│
├── db_init.py                          ✓
├── qdrant_setup.py                     ✓
├── db_metadata.txt                     ✓
│
├── static/
│   ├── index.html                      ✓
│   ├── app.js                          ✓
│   └── style.css                       ✓
│
└── [Other documentation files]         ✓
```

---

## 🎯 Summary Checklist for GitHub

**Before pushing:**
```bash
# Remove unnecessary files
rm -rf .venv
rm .env
find . -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null
find . -type f -name "*.pyc" -delete

# Create necessary files
cp .env.example .env.example  # Ensure template exists
touch .gitignore             # Ensure .gitignore exists

# Verify what will be uploaded
git status

# Should show:
# ✓ Source code files
# ✓ Documentation files
# ✓ Configuration templates
# ❌ .venv (should not be here)
# ❌ .env (should not be here)
# ❌ __pycache__ (should not be here)
```

---

## 📞 For Documentation

Include this in your README.md:

```markdown
## Getting Started

### Prerequisites
- Python 3.10+
- PostgreSQL 15+
- Ollama with llama2 model
- Docker (for Qdrant)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-user/agentic-rag-nl2sql.git
   cd agentic-rag-nl2sql
   ```

2. **Create environment file**
   ```bash
   cp .env.example .env
   # Edit .env with your credentials
   ```

3. **Setup Python environment**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

4. **Initialize databases**
   ```bash
   python3 db_init.py
   python3 qdrant_setup.py
   ```

5. **Start services and run**
   ```bash
   flask run
   # Open http://localhost:5000
   ```

For detailed setup instructions, see [SETUP_INSTALLATION_GUIDE.md](SETUP_INSTALLATION_GUIDE.md)

For architecture details, see [ARCHITECTURE_AND_WORKFLOW.md](ARCHITECTURE_AND_WORKFLOW.md)
```

---

**You're now ready to upload your project to GitHub!**

Follow the checklist above to ensure clean, secure repository.
