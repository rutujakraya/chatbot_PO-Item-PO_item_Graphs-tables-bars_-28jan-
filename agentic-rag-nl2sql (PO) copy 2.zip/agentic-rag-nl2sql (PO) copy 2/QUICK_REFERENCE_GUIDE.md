# Quick Reference - Setup & Architecture at a Glance

## 🚀 Quick Start (5 Minutes)

### Prerequisites Already Installed?
```bash
# Check Python
python3 --version    # Should be 3.10+

# Check PostgreSQL
psql --version       # Should be 15+

# Verify Services Running
curl http://localhost:11434/api/tags    # Ollama
curl http://localhost:6333/health       # Qdrant
```

### Get Project Running
```bash
# 1. Activate environment
source .venv/bin/activate

# 2. Start services (if not already running)
# Terminal 1: Ollama (or keep running in background)
ollama serve

# Terminal 2: Qdrant
docker run -p 6333:6333 qdrant/qdrant:latest

# Terminal 3: Flask app
flask run

# 3. Open browser
# http://localhost:5000
```

---

## 📋 Tech Stack Checklist

| Component | Version | Purpose | Status |
|-----------|---------|---------|--------|
| **Python** | 3.10+ | Backend runtime | ✓ Required |
| **PostgreSQL** | 15+ | Main database | ✓ Required |
| **Ollama** | Latest | LLM runtime | ✓ Required |
| **Qdrant** | 0.11+ | Vector database | ✓ Required |
| **Flask** | 2.3+ | Web framework | ✓ Required |
| **Sentence Transformers** | 2.2+ | Embeddings | ✓ Required |
| **psycopg2** | 2.9+ | DB driver | ✓ Required |
| **requests** | 2.31+ | HTTP client | ✓ Required |
| **pandas** | 2.0+ | Data processing | ✓ Required |
| **Nivo.js** | Latest | Chart library | ✓ Frontend |

---

## 🔌 Service Ports & URLs

| Service | Port | URL | Status Check |
|---------|------|-----|--------------|
| **Flask API** | 5000 | http://localhost:5000 | `curl http://localhost:5000` |
| **Ollama LLM** | 11434 | http://localhost:11434 | `curl http://localhost:11434/api/tags` |
| **Qdrant Vector DB** | 6333 | http://localhost:6333 | `curl http://localhost:6333/health` |
| **PostgreSQL** | 5432 | localhost:5432 | `psql -U postgres` |
| **pgAdmin** | 5050 | http://localhost:5050 | Browser |

---

## 📦 Project File Structure

```
root/
├── .venv/                    # Virtual environment (NOT in GitHub)
├── static/
│   ├── index.html           # UI
│   ├── app.js               # Frontend logic
│   └── style.css            # Styling
├── agent_*.py               # 10 agent modules
├── app.py                   # Flask entry point
├── db_init.py               # Database setup
├── qdrant_setup.py          # Vector DB setup
├── requirements.txt         # Python packages
├── .env                     # Environment variables (NOT in GitHub)
├── db_metadata.txt          # Schema definitions
├── SETUP_INSTALLATION_GUIDE.md      # Setup instructions
├── ARCHITECTURE_AND_WORKFLOW.md     # This architecture
└── README.md               # Project overview
```

---

## 🎯 Core Workflow (Simple View)

```
Question
  ↓ (embed)
Vector Search (Qdrant)
  ↓ (retrieve schema)
SQL Generation (LLM)
  ↓ (validate + retry if needed)
SQL Execution (PostgreSQL)
  ↓ (format results)
Nivo JSON Creation
  ↓ (render)
Chart Display
```

---

## 🤖 Agents Overview

| Agent | Role | Input | Output |
|-------|------|-------|--------|
| **Semantic Analyzer** | Classify intent | Question | 5-dim context |
| **Planner** | Create strategy | Question | Execution plan |
| **Retriever** | RAG search | Question | Schema chunks |
| **SQL Generator** | Generate SQL | Question + schema | SQL query |
| **SQL Validator** | Validate SQL | SQL | Valid/Invalid |
| **SQL Executor** | Run query | SQL | Results |
| **Response Formatter** | Format results | Results | Clean data |
| **Visualization Mapper** | Create Nivo JSON | Data | Nivo JSON |
| **Visualization** | Render chart | Nivo JSON | Interactive chart |

---

## 🔑 Environment Variables (.env)

```bash
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=procure_phase1_first3tables
DB_USER=postgres
DB_PASSWORD=your_password

# Services
OLLAMA_HOST=http://localhost:11434
QDRANT_HOST=localhost
QDRANT_PORT=6333

# Application
FLASK_ENV=development
SECRET_KEY=your_secret_key
```

---

## 📊 5 Semantic Dimensions

### 1. **Table Intent**
- **Master**: Item properties, catalog data (items table)
- **Transactional**: Orders, purchases, frequency (po, po_items tables)
- **Mixed**: Requires both tables

### 2. **Result Cardinality**
- **Singular**: "Which item...?" (LIMIT 1)
- **Plural**: "List all...", "Show..." (LIMIT 20+)
- **Unknown**: Default to plural

### 3. **Aggregation Type**
- **Stored**: Read existing columns (price, cost)
- **Derived**: Compute values (SUM, COUNT, AVG)
- **None**: Simple filtering, no aggregation

### 4. **NULL Handling**
- **Preserve**: Keep NULL values
- **Default**: Replace with 0 or empty
- **Aggregate**: Handle in aggregate functions

### 5. **Entity Scope**
- **All**: Complete catalog, even unordered items
- **Referenced**: Only items in transactions
- **Unknown**: Default to referenced

---

## 🔄 Retry Strategy (If SQL Fails)

| Attempt | Strategy | Success Rate |
|---------|----------|--------------|
| 1 | Enhanced LLM prompt | ~75% |
| 2 | Explicit column listing | ~80% |
| 3 | Example-based learning | ~85% |
| 4 | Semantic fallback | ~95% |
| 5 | Simple fallback | ~70% (last resort) |

Max retries: 5 | Combined success: >98%

---

## 📊 Database Schema

### PO (Purchase Order) Table
```
id, po_no, status, total, created_at, is_deleted
```

### PO_Items Table
```
id, parent_po_id, item_id, item_name, code_sku, 
requested_quantity, per_unit_rate, total, is_deleted
```

### Items (Master) Table
```
id, name, code_sku, base_price, selling_price, mrp,
least_purchase_price, previous_purchase_price, is_deleted
```

---

## 🧪 Testing Commands

```bash
# Semantic analysis
python3 test_semantic_quick.py

# Full validation
python3 test_all_fixes_final.py

# Complete test suite
python3 test_semantic_correctness.py

# Database connection
psql -U postgres -d procure_phase1_first3tables

# Qdrant health
curl http://localhost:6333/health

# Ollama models
curl http://localhost:11434/api/tags
```

---

## 🆘 Troubleshooting Quick Fixes

| Issue | Fix |
|-------|-----|
| PostgreSQL connection error | Check .env credentials, verify psql running |
| Ollama not responding | Run `ollama serve`, check port 11434 |
| Qdrant connection failed | Run Docker container, check port 6333 |
| Missing dependencies | Run `pip install -r requirements.txt` |
| Virtual env not activating | Delete `.venv`, recreate: `python3 -m venv .venv` |
| Chart not rendering | Check browser console, verify Nivo JSON format |
| SQL validation fails | Check column names in db_metadata.txt |

---

## 📚 Documentation Files

| File | Purpose |
|------|---------|
| **SETUP_INSTALLATION_GUIDE.md** | Complete setup instructions for new systems |
| **ARCHITECTURE_AND_WORKFLOW.md** | Full architecture with diagrams and flows |
| **README.md** | Project overview and usage |
| **SEMANTIC_CORRECTNESS_GUIDE.md** | Semantic system explanation |
| **CODE_CHANGES_DETAILED.md** | Before/after code comparisons |
| **FIXES_SUMMARY.md** | Real-world bug fixes summary |

---

## 🎓 Example Queries That Work

```
1. "List the 5 most recently created purchase orders"
   → Bar chart of PO dates

2. "Which item has the highest total ordered quantity?"
   → KPI card showing top item

3. "How many purchase orders are in draft status?"
   → Single metric display

4. "Show me all items with their base prices"
   → Table with sortable columns

5. "Most ordered items by frequency"
   → Bar chart with item names and counts

6. "Total PO value by status"
   → Pie chart showing status distribution
```

---

## 🚀 Deployment Checklist

- [ ] Python 3.10+ installed
- [ ] PostgreSQL 15+ running with database created
- [ ] Ollama running with model loaded
- [ ] Qdrant running (Docker or local)
- [ ] Virtual environment created and activated
- [ ] requirements.txt installed
- [ ] .env file configured
- [ ] Database initialized (python3 db_init.py)
- [ ] Qdrant collections created (python3 qdrant_setup.py)
- [ ] All services accessible on expected ports
- [ ] Test query successful
- [ ] Frontend displays without errors

---

## 🔗 Useful Links

- **Python**: https://python.org
- **PostgreSQL**: https://postgresql.org
- **Ollama**: https://ollama.ai
- **Qdrant**: https://qdrant.tech
- **Flask**: https://flask.palletsprojects.com
- **Nivo**: https://nivo.rocks
- **Sentence Transformers**: https://sbert.net

---

**Ready to deploy? Follow SETUP_INSTALLATION_GUIDE.md for detailed steps.**

**Need architecture details? See ARCHITECTURE_AND_WORKFLOW.md for complete flows.**
