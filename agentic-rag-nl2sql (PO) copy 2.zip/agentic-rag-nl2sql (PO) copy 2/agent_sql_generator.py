import requests
import re
from agent_semantic_analyzer import SemanticAnalyzer


class SQLGeneratorAgent:
    """
    INDUSTRY-GRADE SQL Generation Agent.
    
    Uses LLaMA-3 8B with:
    1) Injected metadata chunks from db_metadata.txt (via Qdrant)
    2) Explicit examples of natural-language → SQL mappings
    3) Strict validation rules
    4) Fallback rule-based generation for edge cases
    """
    
    def __init__(self, model: str = "llama3:8b"):
        self.model = model
        self.url = "http://localhost:11434/api/generate"
        self.semantic_analyzer = SemanticAnalyzer()

    def _format_schema_context(self, context_chunks: list) -> str:
        """
        Format retrieved metadata chunks into a clean, readable schema section.
        
        Args:
            context_chunks: List of dicts from RetrievalAgent with 'text', 'table', 'type'
            
        Returns:
            Formatted schema string for LLM prompt
        """
        if not context_chunks:
            return "No schema information available."
        
        schema_lines = []
        for chunk in context_chunks:
            text = chunk.get("text", "").strip()
            table = chunk.get("table", "")
            chunk_type = chunk.get("type", "")
            
            if text:
                # Format: [table type] text content
                prefix = f"[{table} - {chunk_type}]" if table else f"[{chunk_type}]"
                schema_lines.append(f"{prefix}\n{text}")
        
        return "\n\n".join(schema_lines)

    def generate_sql(self, user_question: str, schema_context: list) -> str:
        """
        Generate PostgreSQL SQL from natural language question.
        
        Pipeline:
        1) Analyze semantic intent (master vs transactional, singular vs plural, etc.)
        2) Inject retrieved metadata (from db_metadata.txt via Qdrant)
        3) Provide explicit NL→SQL mapping examples + semantic rules
        4) Call LLaMA-3 8B with detailed instructions
        5) Validate output
        6) Fall back to rule-based generation if LLM fails
        """
        
        # STEP 1: Analyze semantic intent
        semantic_context = self.semantic_analyzer.analyze(user_question)
        semantic_rules = self.semantic_analyzer.get_prompt_injection(semantic_context)
        
        # Format metadata chunks for inclusion in prompt
        schema_text = self._format_schema_context(schema_context)
        
        # CRITICAL PROMPT: Emphasize metadata-driven generation with semantic rules
        prompt = f"""You are an EXPERT PostgreSQL SQL generator for a PROCUREMENT database.

YOUR TASK:
Convert the user's natural language question into a single PostgreSQL SELECT query.
Use ONLY the tables and columns described in the SCHEMA section below.
The schema is derived from db_metadata.txt and describes the procurement system.

{semantic_rules}

⚠️  CRITICAL OUTPUT FORMAT:
- Output ONLY the SQL query statement.
- No explanation, no preamble, no "HERE IS THE SQL QUERY...", no markdown.
- Start immediately with SELECT or WITH.
- End with a semicolon.
- Example output format: SELECT po_no FROM po WHERE status='APPROVED' LIMIT 20;

STRICT RULES:
1. Generate ONLY SELECT queries (terminated with semicolon).
2. Use ONLY tables and columns found in the SCHEMA section below.
3. NEVER reference information_schema, pg_catalog, or any system tables.
4. ALWAYS include soft-delete filter: WHERE is_deleted IS NULL OR is_deleted = false
5. Use JOINs for multi-table queries:
   - po.id = po_items.parent_po_id (to get items in a PO)
   - items.id = po_items.item_id (to get item details)
   - ALWAYS qualify columns with table aliases (e.g., i.name, items.name)
6. Use GROUP BY + aggregate functions (COUNT, SUM, AVG) for summaries.
7. ⚠️  CRITICAL: When using GROUP BY with ORDER BY:
   - If ordering by grouped column: Include in GROUP BY (safe)
   - If ordering by ungrouped column (e.g., created_at): Use a subquery wrapper
   - Example: SELECT * FROM (SELECT ... GROUP BY ...) t ORDER BY created_at DESC LIMIT 20;
8. Use ORDER BY + LIMIT for top-N or recent data queries.
9. Avoid SELECT * — always specify columns explicitly.
10. SPECIAL: For frequency charts (most ordered items), ALWAYS use this pattern:
    - SELECT i.name AS item_name, COUNT(*) AS frequency FROM po_items poi
    - JOIN items i ON poi.item_id = i.id WHERE poi.is_deleted IS NULL OR poi.is_deleted = false
    - GROUP BY i.id, i.name ORDER BY frequency DESC LIMIT 20;
    - Never use "i.item_name" (item_name is in po_items, not items table)
11. Return ONLY the SQL statement; do NOT explain.

PROCUREMENT-SPECIFIC EXAMPLES:
- "List approved POs" → SELECT po_no, status, total, created_at FROM po WHERE status = 'APPROVED' AND (is_deleted IS NULL OR is_deleted = false) ORDER BY created_at DESC LIMIT 20;
- "Items in PO-001" → SELECT poi.item_name, poi.code_sku, poi.requested_quantity, poi.per_unit_rate, poi.total FROM po_items poi JOIN po p ON poi.parent_po_id = p.id WHERE p.po_no = 'PO-001' AND (poi.is_deleted IS NULL OR poi.is_deleted = false);
- "Total PO value by status" → SELECT status, COUNT(id) as po_count, SUM(total) as total_value FROM po WHERE is_deleted IS NULL OR is_deleted = false GROUP BY status;
- "Most ordered items" → SELECT i.name AS item_name, COUNT(*) AS frequency FROM po_items poi JOIN items i ON poi.item_id = i.id WHERE poi.is_deleted IS NULL OR poi.is_deleted = false GROUP BY i.id, i.name ORDER BY frequency DESC LIMIT 20;
- "Recent purchase orders" → SELECT po_no, status, total, created_at FROM po WHERE is_deleted IS NULL OR is_deleted = false ORDER BY created_at DESC LIMIT 10;
- "POs with item counts (sorted by recent)" → SELECT * FROM (SELECT po.id, po.po_no, po.created_at, COUNT(poi.id) as item_count FROM po JOIN po_items poi ON po.id = poi.parent_po_id WHERE po.is_deleted IS NULL OR po.is_deleted = false GROUP BY po.id, po.po_no, po.created_at) t ORDER BY t.created_at DESC LIMIT 20;

⚠️ CRITICAL NOTES:
- ALWAYS qualify column names with table aliases when using JOINs (e.g., p.is_deleted, poi.is_deleted, not just is_deleted)
- This prevents "column reference is ambiguous" errors
- When multiple tables have the same column, PostgreSQL requires the table qualification
- For items table, use i.name NOT i.item_name (item_name column is only in po_items)
- RESPECT THE SEMANTIC RULES ABOVE — they are derived from careful analysis of the question intent

SCHEMA (from db_metadata.txt):
{schema_text}

USER QUESTION:
{user_question}

SQL OUTPUT (only the query, no explanation):
"""

        try:
            response = requests.post(
                self.url,
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "temperature": 0.1,  # Lower temperature for more deterministic SQL
                },
                timeout=60
            )
            sql = response.json().get("response", "").strip()
            
            # === FIX: Strip LLM preambles ===
            # Some models output "HERE IS THE SQL QUERY: " before the actual SQL
            # Extract just the SQL part
            if sql:
                # Try to find the first SELECT or WITH keyword
                sql_upper = sql.upper()
                select_idx = sql_upper.find("SELECT")
                with_idx = sql_upper.find("WITH")
                
                # Find the earliest of these two
                first_sql_idx = -1
                if select_idx >= 0 and with_idx >= 0:
                    first_sql_idx = min(select_idx, with_idx)
                elif select_idx >= 0:
                    first_sql_idx = select_idx
                elif with_idx >= 0:
                    first_sql_idx = with_idx
                
                # Extract SQL from first keyword onwards
                if first_sql_idx > 0:
                    sql = sql[first_sql_idx:].strip()
                    
        except Exception as e:
            print(f"SQLGeneratorAgent LLM error: {e}")
            sql = ""

        # === VALIDATION: Reject unsafe SQL ===
        if sql:
            sql_lower = sql.lower()
            sql_upper = sql.upper()
            # Reject if system tables referenced
            forbidden = ["information_schema", "pg_catalog", "pg_tables", "columns", "constraints"]
            for forbidden_table in forbidden:
                if forbidden_table in sql_lower:
                    print(f"SQLGeneratorAgent rejected SQL (forbidden table: {forbidden_table})")
                    return ""
            
            # Reject if non-SELECT operations (but allow CTEs and subqueries that contain SELECT)
            # Accept queries starting with SELECT or WITH (Common Table Expressions)
            if not (sql_upper.startswith("SELECT") or sql_upper.startswith("WITH")):
                print(f"SQLGeneratorAgent rejected SQL (must start with SELECT or WITH, got: {sql_upper[:30]}...)")
                return ""
            
            # Reject if no terminating semicolon
            if not sql.rstrip().endswith(";"):
                sql = sql.rstrip() + ";"
            
            return sql

        # === FALLBACK: Semantic-aware rule-based generation ===
        # If LLM fails, try semantic-guided fallback patterns
        print("SQLGeneratorAgent: LLM returned empty; attempting semantic-guided fallback")
        return self._semantic_fallback_generate_sql(
            user_question, schema_context, semantic_context
        )

    def _semantic_fallback_generate_sql(
        self, user_question: str, schema_context: list, semantic_context: dict
    ) -> str:
        """
        Semantic-guided fallback SQL generation.
        
        Instead of keyword matching, uses semantic classifications to apply
        general table selection, aggregation, and cardinality rules.
        
        Args:
            user_question: User's natural language question
            schema_context: Retrieved metadata chunks
            semantic_context: Semantic classification from analyzer
        """
        q = user_question.lower()
        
        # Get semantic recommendations
        recommendations = self.semantic_analyzer.get_table_recommendations(semantic_context)
        
        # Determine if master table should be primary
        if semantic_context["table_intent"] == "master":
            return self._generate_master_data_query(q, semantic_context, recommendations)
        
        # Determine if transactional data should be primary
        elif semantic_context["table_intent"] == "transactional":
            return self._generate_transactional_query(q, semantic_context, recommendations)
        
        # Mixed intent: try both
        else:
            # Try transactional first (more specific)
            result = self._generate_transactional_query(q, semantic_context, recommendations)
            if result:
                return result
            # Fall back to master data query
            return self._generate_master_data_query(q, semantic_context, recommendations)

    def _generate_master_data_query(
        self, q: str, semantic_context: dict, recommendations: dict
    ) -> str:
        """
        Generate SQL for master data (items table) queries.
        
        Rules applied:
        - Query ITEMS table
        - Return stored values (not aggregates)
        - Include all entities if semantic_context["entity_scope"] == "all"
        - Respect singular/plural cardinality
        - Preserve NULL values if specified
        """
        
        # Extract question intent
        cardinality = semantic_context["result_cardinality"]
        include_all = recommendations["include_all_entities"]
        singular_limit = recommendations["singular_limit"]
        
        # BASE: List items query
        if ("list" in q or "show" in q) and "item" in q:
            status_filter = ""
            if "approved" in q:
                status_filter = "AND status = 'APPROVED' "
            
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            
            return (
                f"SELECT name, code_sku, status, gst_percent FROM items "
                f"WHERE (is_deleted IS NULL OR is_deleted = false) {status_filter}"
                f"ORDER BY created_at DESC {limit_clause}"
            )
        
        # STORED PRICES: least_purchase_price, previous_purchase_price, etc.
        if "least" in q and "purchase" in q and "price" in q:
            # User wants the stored least_purchase_price column
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            return (
                "SELECT name, code_sku, least_purchase_price, least_purchase_date "
                "FROM items WHERE (is_deleted IS NULL OR is_deleted = false) "
                f"AND least_purchase_price IS NOT NULL "
                f"ORDER BY least_purchase_price ASC {limit_clause}"
            )
        
        if "previous" in q and "purchase" in q and "price" in q and "least" not in q:
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            return (
                "SELECT name, code_sku, previous_purchase_price, previous_purchase_date "
                "FROM items WHERE (is_deleted IS NULL OR is_deleted = false) "
                f"AND previous_purchase_price IS NOT NULL "
                f"ORDER BY previous_purchase_date DESC {limit_clause}"
            )
        
        # BOTH LEAST AND PREVIOUS PRICES
        if "least" in q and "previous" in q and "purchase" in q and "price" in q:
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            return (
                "SELECT name AS item_name, code_sku, least_purchase_price, previous_purchase_price "
                "FROM items WHERE (is_deleted IS NULL OR is_deleted = false) "
                f"AND (least_purchase_price IS NOT NULL OR previous_purchase_price IS NOT NULL) "
                f"ORDER BY name {limit_clause}"
            )
        
        # ITEM PROPERTIES (base_price, selling_price, mrp, etc.)
        if "price" in q and "item" in q:
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            return (
                "SELECT name, code_sku, base_price, selling_price, mrp, gst_percent "
                "FROM items WHERE (is_deleted IS NULL OR is_deleted = false) "
                f"ORDER BY created_at DESC {limit_clause}"
            )
        
        return ""

    def _generate_transactional_query(
        self, q: str, semantic_context: dict, recommendations: dict
    ) -> str:
        """
        Generate SQL for transactional (po, po_items) queries.
        
        Rules applied:
        - Query PO/PO_ITEMS as primary
        - Join ITEMS only for labels
        - Use aggregates (COUNT, SUM) for derived values
        - Apply singular/plural cardinality
        - Filter only ordered/referenced entities if required
        """
        
        cardinality = semantic_context["result_cardinality"]
        singular_limit = recommendations["singular_limit"]
        include_all = recommendations["include_all_entities"]
        
        # PATTERN 1: List POs (approved, draft, or all)
        if ("list" in q or "show" in q) and ("po" in q or "purchase order" in q):
            status_filter = ""
            if "approved" in q:
                status_filter = "AND status = 'APPROVED' "
            elif "draft" in q:
                status_filter = "AND status = 'DRAFT' "
            
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            return (
                f"SELECT po_no, status, total, created_at FROM po "
                f"WHERE (is_deleted IS NULL OR is_deleted = false) {status_filter}"
                f"ORDER BY created_at DESC {limit_clause}"
            )
        
        # PATTERN 2: Count POs
        if ("how many" in q or "count" in q) and ("po" in q or "purchase order" in q):
            status_filter = ""
            if "approved" in q:
                status_filter = "AND status = 'APPROVED' "
            elif "draft" in q:
                status_filter = "AND status = 'DRAFT' "
            
            return (
                f"SELECT COUNT(*) as po_count FROM po "
                f"WHERE (is_deleted IS NULL OR is_deleted = false) {status_filter}"
                ";"
            )
        
        # PATTERN 3: Items in a specific PO
        if ("item" in q or "items" in q) and ("in" in q) and ("po" in q):
            match = re.search(r"po-?(\d+)", q)
            if match:
                po_num = f"PO-{match.group(1).zfill(3)}"
                return (
                    f"SELECT poi.item_name, poi.code_sku, poi.requested_quantity, poi.per_unit_rate, poi.total "
                    f"FROM po_items poi JOIN po p ON poi.parent_po_id = p.id "
                    f"WHERE p.po_no = '{po_num}' AND (poi.is_deleted IS NULL OR poi.is_deleted = false);"
                )
        
        # PATTERN 4: PO value by status
        if ("total" in q) and ("po" in q or "purchase order" in q) and ("status" in q):
            return (
                "SELECT status, COUNT(id) as po_count, SUM(total) as total_value "
                "FROM po WHERE (is_deleted IS NULL OR is_deleted = false) "
                "GROUP BY status ORDER BY total_value DESC;"
            )
        
        # PATTERN 5: Most ordered/frequent items (transactional)
        # Matches: "most ordered items", "top items", "items ordered most frequently", "top 3 items", etc.
        if (
            ("most" in q or "top" in q or "frequent" in q or "frequently" in q)
            and "item" in q
        ):
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            return (
                "SELECT i.name AS item_name, COUNT(*) AS frequency "
                "FROM po_items poi "
                "JOIN items i ON poi.item_id = i.id "
                "WHERE (poi.is_deleted IS NULL OR poi.is_deleted = false) "
                f"GROUP BY i.id, i.name ORDER BY frequency DESC {limit_clause}"
            )
        
        # PATTERN 6: Recent POs
        if ("recent" in q or "latest" in q) and ("po" in q or "purchase order" in q):
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 10;"
            return (
                f"SELECT po_no, status, total, created_at FROM po "
                f"WHERE (is_deleted IS NULL OR is_deleted = false) "
                f"ORDER BY created_at DESC {limit_clause}"
            )
        
        # PATTERN 7: POs with item counts
        if (
            ("item" in q)
            and ("count" in q or "number" in q or "each" in q or "per" in q)
            and ("po" in q or "purchase order" in q)
        ) or (
            ("total" in q or "each" in q)
            and ("item" in q)
            and ("value" in q or "po" in q)
        ):
            return (
                "SELECT p.po_no, p.status, p.total, COUNT(poi.id) as item_count, SUM(poi.total) as items_total_value "
                "FROM po p JOIN po_items poi ON p.id = poi.parent_po_id "
                "WHERE (p.is_deleted IS NULL OR p.is_deleted = false) "
                "GROUP BY p.id, p.po_no, p.status, p.total ORDER BY p.po_no;"
            )
        
        return ""

    def _fallback_generate_sql(self, user_question: str, schema_context: list) -> str:
        """
        Legacy rule-based fallback SQL generation for procurement domain.
        
        This ensures we can still answer simple questions even if LLM fails.
        
        DEPRECATED: Use _semantic_fallback_generate_sql instead.
        """
        # Extract table names from schema context
        tables = set()
        schema_low = ""
        for chunk in schema_context:
            if isinstance(chunk, dict):
                if chunk.get("table"):
                    tables.add(chunk.get("table").lower())
                if chunk.get("text"):
                    schema_low += chunk.get("text", "").lower() + "\n"
            else:
                schema_low += str(chunk).lower() + "\n"
        
        q = user_question.lower()
        
        def has_table(name):
            return name in tables or name in schema_low

        # PATTERN 1: "list all [approved|draft] purchase orders"
        if ("list" in q or "show" in q) and ("po" in q or "purchase order" in q):
            if "approved" in q:
                return "SELECT po_no, status, total, created_at FROM po WHERE status = 'APPROVED' AND (is_deleted IS NULL OR is_deleted = false) ORDER BY created_at DESC LIMIT 20;"
            elif "draft" in q:
                return "SELECT po_no, status, total, created_at FROM po WHERE status = 'DRAFT' AND (is_deleted IS NULL OR is_deleted = false) ORDER BY created_at DESC LIMIT 20;"
            else:
                return "SELECT po_no, status, total, created_at FROM po WHERE is_deleted IS NULL OR is_deleted = false ORDER BY created_at DESC LIMIT 20;"

        # PATTERN 2: "how many pos" / "count purchase orders"
        if ("how many" in q or "count" in q) and ("po" in q or "purchase order" in q):
            if "approved" in q:
                return "SELECT COUNT(*) as po_count FROM po WHERE status = 'APPROVED' AND (is_deleted IS NULL OR is_deleted = false);"
            elif "draft" in q:
                return "SELECT COUNT(*) as po_count FROM po WHERE status = 'DRAFT' AND (is_deleted IS NULL OR is_deleted = false);"
            else:
                return "SELECT COUNT(*) as po_count FROM po WHERE is_deleted IS NULL OR is_deleted = false;"

        # PATTERN 2.5: "POs with item counts" / "items per PO" / "show PO numbers with items" / "each PO with total items"
        if (("item" in q) and ("count" in q or "number" in q or "each" in q or "per" in q) and ("po" in q or "purchase order" in q)) or \
           (("total" in q or "each") and ("item" in q) and ("value" in q or "po" in q)):
            return (
                "SELECT p.po_no, p.status, p.total, COUNT(poi.id) as item_count, SUM(poi.total) as items_total_value "
                "FROM po p JOIN po_items poi ON p.id = poi.parent_po_id "
                "WHERE p.is_deleted IS NULL OR p.is_deleted = false "
                "GROUP BY p.id, p.po_no, p.status, p.total ORDER BY p.po_no;"
            )

        # PATTERN 3: "items in po-XXX"
        if ("item" in q) and ("in" in q) and ("po" in q):
            match = re.search(r"po-?(\d+)", q)
            if match:
                po_num = f"PO-{match.group(1).zfill(3)}"
                return (
                    f"SELECT poi.item_name, poi.code_sku, poi.requested_quantity, poi.per_unit_rate, poi.total "
                    f"FROM po_items poi JOIN po p ON poi.parent_po_id = p.id "
                    f"WHERE p.po_no = '{po_num}' AND (poi.is_deleted IS NULL OR poi.is_deleted = false);"
                )

        # PATTERN 4: "total po value by status"
        if ("total" in q) and ("po" in q or "purchase order" in q) and ("status" in q):
            return (
                "SELECT status, COUNT(id) as po_count, SUM(total) as total_value "
                "FROM po WHERE is_deleted IS NULL OR is_deleted = false GROUP BY status ORDER BY total_value DESC;"
            )

        # PATTERN 5: "most ordered items" / "top items" / "items ordered most frequently"
        # CANONICAL PATTERN: Use items table to get item.name (NOT po_items.item_name for aggregated queries)
        if ("most" in q or "top" in q or "frequently" in q) and "item" in q and ("order" in q or "request" in q or "frequency" in q):
            return (
                "SELECT i.name AS item_name, COUNT(*) AS frequency "
                "FROM po_items poi "
                "JOIN items i ON poi.item_id = i.id "
                "WHERE poi.is_deleted IS NULL OR poi.is_deleted = false "
                "GROUP BY i.id, i.name ORDER BY frequency DESC LIMIT 20;"
            )

        # PATTERN 6: "recent purchase orders"
        if ("recent" in q or "latest" in q) and ("po" in q or "purchase order" in q):
            return (
                "SELECT po_no, status, total, created_at FROM po "
                "WHERE is_deleted IS NULL OR is_deleted = false ORDER BY created_at DESC LIMIT 10;"
            )

        # PATTERN 7: "list items" / "show items"
        if ("list" in q or "show" in q) and "item" in q:
            if "approved" in q:
                return "SELECT name, code_sku, status, gst_percent FROM items WHERE status = 'APPROVED' AND (is_deleted IS NULL OR is_deleted = false) LIMIT 20;"
            else:
                return "SELECT name, code_sku, status, gst_percent FROM items WHERE is_deleted IS NULL OR is_deleted = false LIMIT 20;"

        # No fallback pattern matched
        return ""

