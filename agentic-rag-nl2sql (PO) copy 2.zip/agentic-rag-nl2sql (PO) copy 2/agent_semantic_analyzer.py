"""
SEMANTIC ANALYZER AGENT

Classifies user questions based on semantic intent before SQL generation.
Uses linguistic patterns + schema metadata to determine:

1. TABLE INTENT: Master (items) vs Transactional (po, po_items)
2. RESULT CARDINALITY: Singular (top-1, most, highest) vs Plural (list, all)
3. AGGREGATION TYPE: Stored values vs Derived aggregates
4. NULL HANDLING: Preserve NULL vs Replace with aggregate
5. ENTITY SCOPE: All entities vs Only referenced entities

This classification guides SQL generation to be semantically correct.
"""

import re
from typing import Dict, List, Set, Optional, Tuple


class SemanticAnalyzer:
    """
    Analyzes natural language questions to determine semantic intent.
    
    Output is a structured dict that SQL generator uses instead of keyword matching.
    """

    # === LINGUISTIC PATTERNS (Schema-agnostic) ===

    # Patterns indicating MASTER DATA intent
    MASTER_INTENT_PATTERNS = [
        r'\b(what\s+)?items?\s+(exist|are|is there|do you have|available|enabled)',
        r'\b(list|show|find|get|retrieve)\s+(all\s+)?items?\b',
        r'\b(item\s+)?(names?|catalog|master|list|properties)',
        r'\b(properties|attributes|details|specs?)\s+of\s+items?',
        r'\b(stored|configured|registered)\s+(prices?|items?|names?)',
        r'\b(items?\s+)?(configuration|metadata|classification)',
        r'\b(names?|prices?|details)\s+of\s+items?',  # Properties of items
        r'\b(base_price|landing_price|selling_price|mrp|least\s+purchase\s+price|previous\s+purchase\s+price)\b',  # Stored prices
    ]

    # Patterns indicating TRANSACTIONAL intent
    TRANSACTIONAL_INTENT_PATTERNS = [
        r'\b(ordered|purchase|requested|supplied)\s+(items?|quantity|qtd)',
        r'\b(po|purchase\s+order)',
        r'\b(transaction|order|invoice|receipt|purchase\s+history)',
        r'\b(frequency|usage|how\s+many\s+times|total\s+ordered)',
        r'\b(invoice|grn|receipt|delivery)',
        r'\b(most\s+ordered|top\s+\d+|most\s+frequently)',  # Frequency metrics
    ]

    # Patterns indicating SINGULAR result intent (top-1, most, etc.)
    SINGULAR_RESULT_PATTERNS = [
        r'\b(which\s+(?:item|order|po|purchase\s+order|product)\s+(?:has|is))',  # "Which item has"
        r'\b(most|highest|top|best|cheapest|most\s+expensive|lowest)',
        r'\b(top\s+\d+|first|last|single|one)\b',
        r'\b(winner|leader|champion|maximum|minimum|largest|smallest)\b',
    ]

    # Patterns indicating PLURAL result intent (list, all, show)
    PLURAL_RESULT_PATTERNS = [
        r'\b(list|show|all|every|each|display|enumerate|items?)\b',
        r'\bwhere\b',  # "show items where..." = multiple items
        r'\b(count|total|sum|average|how many)\b',  # Aggregates suggest multiple items
    ]

    # Patterns indicating STORED VALUE (read existing column)
    STORED_VALUE_PATTERNS = [
        r'\b(least\s+purchase\s+price|previous\s+purchase\s+price)',  # Exact stored columns
        r'\b(base_price|landing_price|selling_price|mrp)',  # Other stored prices
        r'\b(least|previous|stored|configured|existing)\s+(?:purchase\s+)?(price|value)',
        r'\b(price|value|cost)\s+(?:for|of)\s+items?',  # Price of items (master data)
    ]

    # Patterns indicating DERIVED/COMPUTED intent
    DERIVED_VALUE_PATTERNS = [
        r'\b(calculate|compute|derived|based\s+on|from\s+.*(?:history|orders|transactions))',
        r'\b(average|min|max|sum|total|count|frequency)\b',
        r'\b(by|per)\s+(?:order|purchase|transaction)',
        r'\b(most|top|frequently)\s+(?:ordered|purchased)\b',  # Frequency metrics
    ]

    # Patterns indicating NULL preservation intent
    NULL_PRESERVATION_PATTERNS = [
        r'\b(is\s+null|null|not\s+set|empty|missing)',
        r'\b(where\s+\w+\s+is\s+null)',
    ]

    # Patterns indicating entity existence scope (all entities vs only ordered/referenced)
    ALL_ENTITIES_PATTERNS = [
        r'\b(all\s+items|every\s+item|complete\s+catalog|full\s+list)',
        r'\b(items\s+(?:in\s+)?master)',
        r'\b(available|registered|configured)\s+items?',
    ]

    def __init__(self):
        """Initialize semantic analyzer."""
        self.compiled_patterns = self._compile_patterns()

    def _compile_patterns(self) -> Dict[str, List[re.Pattern]]:
        """Precompile all regex patterns."""
        return {
            "master_intent": [re.compile(p, re.IGNORECASE) for p in self.MASTER_INTENT_PATTERNS],
            "transactional_intent": [
                re.compile(p, re.IGNORECASE) for p in self.TRANSACTIONAL_INTENT_PATTERNS
            ],
            "singular_result": [re.compile(p, re.IGNORECASE) for p in self.SINGULAR_RESULT_PATTERNS],
            "plural_result": [re.compile(p, re.IGNORECASE) for p in self.PLURAL_RESULT_PATTERNS],
            "stored_value": [re.compile(p, re.IGNORECASE) for p in self.STORED_VALUE_PATTERNS],
            "derived_value": [re.compile(p, re.IGNORECASE) for p in self.DERIVED_VALUE_PATTERNS],
            "null_preservation": [
                re.compile(p, re.IGNORECASE) for p in self.NULL_PRESERVATION_PATTERNS
            ],
            "all_entities": [re.compile(p, re.IGNORECASE) for p in self.ALL_ENTITIES_PATTERNS],
        }

    def analyze(self, user_question: str) -> Dict:
        """
        Analyze user question to extract semantic intent.

        Args:
            user_question: Natural language question

        Returns:
            Dict with semantic classifications:
            {
                "table_intent": "master" | "transactional" | "mixed",
                "result_cardinality": "singular" | "plural" | "unknown",
                "aggregation_type": "stored" | "derived" | "none",
                "null_handling": "preserve" | "default" | "aggregate",
                "entity_scope": "all" | "referenced" | "unknown",
                "confidence": float (0-1),
                "matched_patterns": List[str],
                "text_tokens": Set[str]  # lowercase key words
            }
        """
        q_lower = user_question.lower()
        text_tokens = set(q_lower.split())

        result = {
            "table_intent": self._classify_table_intent(q_lower),
            "result_cardinality": self._classify_result_cardinality(q_lower),
            "aggregation_type": self._classify_aggregation_type(q_lower),
            "null_handling": self._classify_null_handling(q_lower),
            "entity_scope": self._classify_entity_scope(q_lower),
            "confidence": 0.8,  # Will refine later
            "matched_patterns": [],
            "text_tokens": text_tokens,
        }

        return result

    # === TABLE INTENT CLASSIFICATION ===

    def _classify_table_intent(self, q_lower: str) -> str:
        """
        Determine if question is about master data or transactions.

        Returns: "master" | "transactional" | "mixed"
        """
        master_score = self._match_patterns(q_lower, self.compiled_patterns["master_intent"])
        trans_score = self._match_patterns(q_lower, self.compiled_patterns["transactional_intent"])

        if master_score > trans_score:
            return "master"
        elif trans_score > master_score:
            return "transactional"
        else:
            return "mixed"

    # === RESULT CARDINALITY CLASSIFICATION ===

    def _classify_result_cardinality(self, q_lower: str) -> str:
        """
        Determine if user expects singular (top-1) or plural (list) result.

        Returns: "singular" | "plural" | "unknown"
        
        Special logic:
        - "Most X" or "Top X" → singular (user wants THE one)
        - "Most X" pluralized (items) → still singular (the most item)
        - "Recent X" or "Latest X" → plural (recent list)
        - "Count", "how many" → plural context
        """
        singular_score = self._match_patterns(
            q_lower, self.compiled_patterns["singular_result"]
        )
        plural_score = self._match_patterns(q_lower, self.compiled_patterns["plural_result"])

        # Special cases: These are always plural regardless of patterns
        if "how many" in q_lower or "count" in q_lower:
            return "plural"
        
        if "recent" in q_lower or "latest" in q_lower:
            return "plural"
        
        # "most X items" or "top items" → singular (user wants the most item)
        if ("most" in q_lower or "top" in q_lower) and "item" in q_lower:
            return "singular"
        
        # "which X has/is" → always singular
        if "which" in q_lower:
            return "singular"
        
        if singular_score > plural_score:
            return "singular"
        elif plural_score > singular_score:
            return "plural"
        else:
            return "unknown"

    # === AGGREGATION TYPE CLASSIFICATION ===

    def _classify_aggregation_type(self, q_lower: str) -> str:
        """
        Determine if user expects stored values or derived aggregates.

        Returns: "stored" | "derived" | "none"
        """
        stored_score = self._match_patterns(q_lower, self.compiled_patterns["stored_value"])
        derived_score = self._match_patterns(q_lower, self.compiled_patterns["derived_value"])

        if stored_score > 0:
            return "stored"
        elif derived_score > 0:
            return "derived"
        else:
            return "none"

    # === NULL HANDLING CLASSIFICATION ===

    def _classify_null_handling(self, q_lower: str) -> str:
        """
        Determine how to handle NULL values.

        Returns: "preserve" | "default" | "aggregate"
        """
        if self._match_patterns(q_lower, self.compiled_patterns["null_preservation"]) > 0:
            return "preserve"
        elif "count" in q_lower or "sum" in q_lower:
            return "aggregate"
        else:
            return "default"

    # === ENTITY SCOPE CLASSIFICATION ===

    def _classify_entity_scope(self, q_lower: str) -> str:
        """
        Determine if user wants ALL entities or only referenced/ordered entities.

        Returns: "all" | "referenced" | "unknown"
        """
        if self._match_patterns(q_lower, self.compiled_patterns["all_entities"]) > 0:
            return "all"
        elif "ordered" in q_lower or "purchased" in q_lower or "in po" in q_lower:
            return "referenced"
        else:
            return "unknown"

    # === HELPER METHODS ===

    def _match_patterns(self, text: str, patterns: List[re.Pattern]) -> float:
        """Count matching patterns (simple scoring)."""
        return sum(1 for pattern in patterns if pattern.search(text))

    def get_table_recommendations(self, semantic_context: Dict) -> Dict[str, bool]:
        """
        Convert semantic analysis into table usage recommendations.

        Args:
            semantic_context: Output from analyze()

        Returns:
            {
                "use_master_tables": bool,
                "use_transactional_tables": bool,
                "prefer_stored_values": bool,
                "include_all_entities": bool,
                "singular_limit": bool,
                "preserve_nulls": bool,
            }
        """
        return {
            "use_master_tables": semantic_context["table_intent"]
            in ("master", "mixed"),
            "use_transactional_tables": semantic_context["table_intent"]
            in ("transactional", "mixed"),
            "prefer_stored_values": semantic_context["aggregation_type"] == "stored",
            "include_all_entities": semantic_context["entity_scope"] == "all",
            "singular_limit": semantic_context["result_cardinality"] == "singular",
            "preserve_nulls": semantic_context["null_handling"] == "preserve",
        }

    def get_prompt_injection(self, semantic_context: Dict) -> str:
        """
        Generate prompt injection text for SQL generator based on semantic analysis.

        This becomes part of the LLM prompt to guide SQL generation.
        """
        lines = ["SEMANTIC RULES FOR THIS QUESTION:"]

        # Table intent rule
        if semantic_context["table_intent"] == "master":
            lines.append(
                "- This question is about MASTER DATA (item properties, attributes, catalog)."
            )
            lines.append("  ➡️  Query ITEMS table primarily.")
            lines.append("  ➡️  DO NOT derive data from transactions.")
        elif semantic_context["table_intent"] == "transactional":
            lines.append(
                "- This question is about TRANSACTIONS (orders, purchases, frequency)."
            )
            lines.append("  ➡️  Query PO and PO_ITEMS tables.")
            lines.append("  ➡️  Join ITEMS only for labels/names.")
        else:
            lines.append("- This question may require both master and transactional data.")
            lines.append("  ➡️  Use JOINs carefully to combine perspectives.")

        # Result cardinality rule
        if semantic_context["result_cardinality"] == "singular":
            lines.append("- User expects ONE result (top item, most ordered, highest).")
            lines.append("  ➡️  Use ORDER BY ... DESC LIMIT 1")
            lines.append("  ➡️  Return only the single best match.")
        elif semantic_context["result_cardinality"] == "plural":
            lines.append("- User expects MULTIPLE results (list, all items, show catalog).")
            lines.append("  ➡️  Return the full result set (with reasonable LIMIT for UI).")

        # Aggregation type rule
        if semantic_context["aggregation_type"] == "stored":
            lines.append("- User is asking for STORED VALUES (existing columns).")
            lines.append("  ➡️  Read directly from the column.")
            lines.append("  ➡️  DO NOT use MIN/MAX/AVG/etc. unless user explicitly asks.")
            lines.append("  ➡️  Return NULL if the column value is NULL.")
        elif semantic_context["aggregation_type"] == "derived":
            lines.append("- User is asking for COMPUTED/DERIVED values.")
            lines.append("  ➡️  Use aggregation functions (SUM, AVG, MIN, MAX, COUNT).")
            lines.append("  ➡️  Base calculations on transactions, not stored values.")

        # Entity scope rule
        if semantic_context["entity_scope"] == "all":
            lines.append("- User wants ALL entities (complete catalog, even if not ordered).")
            lines.append("  ➡️  Query ITEMS table directly.")
            lines.append("  ➡️  Do NOT exclude items that have no transactions.")
        elif semantic_context["entity_scope"] == "referenced":
            lines.append("- User wants only entities that appear in transactions.")
            lines.append("  ➡️  JOIN through PO_ITEMS to get only ordered/referenced items.")

        # NULL handling rule
        if semantic_context["null_handling"] == "preserve":
            lines.append("- NULL values are significant to this question.")
            lines.append("  ➡️  Return NULL if a column value is NULL.")
            lines.append("  ➡️  DO NOT replace NULL with 0, default, or aggregate.")
        elif semantic_context["null_handling"] == "default":
            lines.append("- Handle NULL values naturally (empty string, 0, or default).")

        return "\n".join(lines)
