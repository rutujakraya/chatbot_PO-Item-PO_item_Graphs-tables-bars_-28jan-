import requests
import os
from dotenv import load_dotenv

load_dotenv()


class ResponseFormatterAgent:
    """
    SECURE Response Formatter Agent.
    
    CRITICAL SECURITY RULES:
    - NEVER expose SQL to users
    - NEVER expose table or column names to users
    - NEVER expose raw database data dumps
    - ALWAYS format as natural language
    - Keep user-facing responses clean and professional
    """
    
    def __init__(self, model: str = "llama3:8b"):
        self.model = model
        self.url = os.getenv("OLLAMA_URL", "http://localhost:11434") + "/api/generate"
        self.debug_mode = os.getenv("DEBUG_MODE", "False").lower() == "true"

    def generate_general_response(self, user_question: str) -> str:
        """
        DIRECT LLM PATH for general (non-database) questions.
        
        Uses LLaMA-3 8B to generate a SHORT, POLITE 1-2 LINE response.
        No database, no SQL, no context injection.
        SECURITY: Never mentions internal system details.
        TONE: Formal, professional, enterprise-grade (Kraya AI identity).
        """
        prompt = f"""You are Kraya AI, a professional enterprise assistant. Answer the user's question in 1-2 sentences only. 
Be formal, polite, and concise. Do NOT mention databases, SQL, or data lookups.
Do NOT use casual language, slang, or emojis.

Question: {user_question}

Answer (1-2 sentences, formal tone):"""

        try:
            response = requests.post(
                self.url,
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                },
                timeout=30
            )
            answer = response.json().get("response", "").strip()
            
            # Ensure we get roughly 1-2 lines; if too long, truncate
            lines = answer.split("\n")
            if len(lines) > 2:
                answer = "\n".join(lines[:2])
            
            # Remove any lingering newlines and clean up
            answer = answer.strip()
            
            return answer if answer else "I can assist with product, order, and vendor-related information. Please try rephrasing your question."
        except Exception as e:
            return "I'm unable to process your question at this moment. Please try again."

    def format(self, user_query: str, sql: str, result: dict, skip_text: bool = False) -> str:
        """Return a user-facing, natural-language answer.

        The formatter produces a concise, readable summary intended for end-users.
        Smart table rendering when appropriate (multi-row, multi-column, comparative data).
        NO internal execution messages (counts, limits, etc.) are shown.
        
        SECURITY RULES (CRITICAL):
        - NO SQL shown
        - NO column names shown
        - NO table names shown  
        - NO raw data dumps
        - ONLY natural language
        - NO internal debug/execution messages
        
        Args:
            user_query: The user's question
            sql: The executed SQL (not shown to user)
            result: Query result dict with columns and rows
            skip_text: If True, return empty string (used when HTML rendering is employed)
        """
        if skip_text:
            # HTML rendering will be used instead; suppress plain text
            return ""
        
        columns = result.get("columns", [])
        rows = result.get("rows", [])

        if not rows:
            return "I couldn't find any matching data for that request."

        num_rows = len(rows)
        num_cols = len(columns)
        
        # Detect if we should render as table
        should_render_table = self._should_render_table(user_query, num_rows, num_cols)
        
        if should_render_table:
            return self._render_table(columns, rows, num_rows)
        else:
            return self._render_text(columns, rows, num_rows)

    def _should_render_table(self, user_query: str, num_rows: int, num_cols: int) -> bool:
        """
        Determine if results should be rendered as a table.
        
        Show table when:
        - User explicitly asks for table
        - Result is multi-row AND multi-column
        - Result is comparative (multiple totals, counts, etc.)
        
        Don't show table when:
        - Single value result
        - Single row result
        - Greeting or identity questions
        """
        q = user_query.lower()
        
        # Check for explicit table requests
        explicit_table_keywords = ["draw table", "show in table", "display as table", "table format"]
        for keyword in explicit_table_keywords:
            if keyword in q:
                return True
        
        # Avoid tables for definitional questions
        avoid_keywords = ["what is", "why", "explain", "how does", "describe", "tell me about"]
        for keyword in avoid_keywords:
            if keyword in q:
                return False
        
        # If multiple rows and multiple columns, use table
        if num_rows > 1 and num_cols > 1:
            return True
        
        # If single row or single column, use text format
        return False

    def _render_table(self, columns: list, rows: list, num_rows: int) -> str:
        """Render results as a formatted table."""
        max_show = 20
        show_rows = rows[:max_show]
        
        # Calculate column widths
        col_widths = [len(str(col)) for col in columns]
        for row in show_rows:
            for i, cell in enumerate(row):
                col_widths[i] = max(col_widths[i], len(str(cell)))
        
        # Build table
        lines = []
        
        # Header
        header = " | ".join(
            str(col).ljust(col_widths[i]) for i, col in enumerate(columns)
        )
        lines.append(header)
        lines.append("-" * len(header))
        
        # Rows
        for row in show_rows:
            row_str = " | ".join(
                str(cell).ljust(col_widths[i]) for i, cell in enumerate(row)
            )
            lines.append(row_str)
        
        # Overflow indicator
        if num_rows > max_show:
            lines.append(f"\n... and {num_rows - max_show} more rows")
        
        return "\n".join(lines)

    def _render_text(self, columns: list, rows: list, num_rows: int) -> str:
        """Render results as readable text (not a table)."""
        # If common case: name + email columns, render a short bullet list
        lower_cols = [c.lower() for c in columns]
        try:
            name_idx = next(i for i, c in enumerate(lower_cols) if "name" in c)
        except StopIteration:
            name_idx = None
        try:
            email_idx = next(i for i, c in enumerate(lower_cols) if "email" in c or "e-mail" in c)
        except StopIteration:
            email_idx = None

        # Limit rows shown for readability
        max_show = 20
        show_rows = rows[:max_show]

        if name_idx is not None and email_idx is not None:
            lines = []
            for r in show_rows:
                name = r[name_idx]
                email = r[email_idx]
                lines.append(f"- {name} — {email}")
            if num_rows > max_show:
                lines.append(f"...and {num_rows - max_show} more.")
            return "\n".join(lines)

        # Generic: if two columns, present as short key: value pairs
        if len(columns) == 2:
            lines = []
            for r in show_rows:
                lines.append(f"- {r[0]}: {r[1]}")
            if num_rows > max_show:
                lines.append(f"...and {num_rows - max_show} more.")
            return "\n".join(lines)

        # Single row: show as natural language
        if num_rows == 1:
            row = rows[0]
            if len(columns) == 1:
                return str(row[0])
            else:
                # Format as key-value pairs
                lines = []
                for i, col in enumerate(columns):
                    lines.append(f"{col}: {row[i]}")
                return "\n".join(lines)

        # Fallback: show header and first few rows as readable CSV-like lines
        header = ", ".join(columns)
        lines = [header]
        for r in show_rows:
            lines.append(", ".join(str(v) for v in r))
        if num_rows > max_show:
            lines.append(f"...and {num_rows - max_show} more.")
        return "\n".join(lines)

    def format_verbose(self, user_query: str, sql: str, result: dict) -> str:
        """Return the previous verbose formatter (includes SQL and a table-like view).

        Useful for debugging; not used for end-user output.
        """
        columns = result.get("columns", [])
        rows = result.get("rows", [])
        lines = []
        lines.append(f"Query executed:\n{sql}\n")
        lines.append("Result:")
        if columns:
            lines.append(" | ".join(columns))
            lines.append("-" * 40)
        for row in rows:
            lines.append(" | ".join(str(v) for v in row))
        return "\n".join(lines)

    def clarify_large_result(self, total_count: int) -> str:
        """Return a polite clarification when a query would return too many rows."""
        return (
            f"Your query returned {total_count} records. For optimal results, please refine your request with: "
            "specific filters (date range, status, etc.), a limit on results, or ask for a summary (counts, totals) instead."
        )

    def polite_rejection(self) -> str:
        """Return a friendly message for non-database queries."""
        return (
            "I can help with questions about your data — such as users, orders, products, and sales. "
            "Please ask a data-related question. For example: 'How many orders were placed last month?' or 'Which are the top 5 best-selling products?'"
        )
