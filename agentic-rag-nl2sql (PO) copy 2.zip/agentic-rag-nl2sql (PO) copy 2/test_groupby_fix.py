#!/usr/bin/env python3
"""
Test the GROUP BY + ORDER BY fix for the orchestrator.
Specifically tests the case where ORDER BY references non-grouped columns.
"""

import sys
from agent_orchestrator import AgentOrchestrator

def main():
    print("\n" + "="*70)
    print("TESTING GROUP BY + ORDER BY FIX")
    print("="*70)
    
    orchestrator = AgentOrchestrator()
    
    # Test case: GROUP BY with ORDER BY non-grouped column
    test_questions = [
        "Show all purchase orders along with the number of items in each",
        "Count items per purchase order sorted by recent PO dates",
        "What is the total value by PO status?",
        "Show me PO numbers with how many items each has"
    ]
    
    for i, question in enumerate(test_questions, 1):
        print(f"\n{'='*70}")
        print(f"TEST {i}: {question}")
        print(f"{'='*70}")
        
        result = orchestrator.run(question)
        
        print(f"\n✓ Answer:")
        print(result.get("answer", "NO ANSWER"))
        
        print(f"\n✓ SQL Generated:")
        print(result.get("sql", "NO SQL"))
        
        print(f"\n✓ Result:")
        result_data = result.get("result", {})
        if result_data:
            print(f"  Rows: {len(result_data.get('rows', []))}")
            if result_data.get('columns'):
                print(f"  Columns: {', '.join(result_data['columns'])}")
        
        print(f"\n✓ Agent Flow:")
        for flow_item in result.get("agent_flow", []):
            print(f"  {flow_item}")

if __name__ == "__main__":
    main()
