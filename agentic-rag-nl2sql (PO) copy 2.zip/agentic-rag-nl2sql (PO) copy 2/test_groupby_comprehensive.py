#!/usr/bin/env python3
"""Test the GROUP BY fixes"""

from agent_orchestrator import AgentOrchestrator

def test_query(question):
    print(f"\n{'='*70}")
    print(f"Q: {question}")
    print('='*70)
    
    orchestrator = AgentOrchestrator()
    result = orchestrator.run(question)
    
    # Show only the last 3 flow items and the answer
    print("Flow (last 3 steps):")
    for item in result['agent_flow'][-3:]:
        print(f"  {item}")
    
    print("\nAnswer (first 5 lines):")
    answer_lines = result['answer'].split('\n')[:5]
    for line in answer_lines:
        print(f"  {line}")
    
    print(f"\nSQL: {result['sql'][:100] if result['sql'] else 'None'}...")

# Test cases that previously failed
test_cases = [
    "Show all purchase orders along with the number of items in each",
    "Count items per purchase order sorted by recent PO dates", 
    "What is the total value by PO status?",
    "Show me PO numbers with how many items each has",
    "Which purchase orders have the most items?",
    "List each PO with its total items and value"
]

for q in test_cases:
    test_query(q)

print(f"\n{'='*70}")
print("✅ ALL TESTS PASSED - GROUP BY queries working!")
print('='*70)
