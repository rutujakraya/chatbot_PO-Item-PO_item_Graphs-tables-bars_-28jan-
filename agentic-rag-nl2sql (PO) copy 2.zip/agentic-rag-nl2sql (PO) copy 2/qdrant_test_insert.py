from sentence_transformers import SentenceTransformer
from qdrant_client import QdrantClient
from qdrant_client.models import PointStruct

model = SentenceTransformer("BAAI/bge-small-en-v1.5")
client = QdrantClient(url="http://localhost:6333")

vector = model.encode("users table has id, name, email")

client.upsert(
    collection_name="rag_schema_chunks",
    points=[
        PointStruct(
            id=1,
            vector=vector.tolist(),
            payload={
                "type": "table_schema",
                "table": "users",
                "text": "users table has id, name, email"
            }
        )
    ]
)

print("Inserted test vector")
