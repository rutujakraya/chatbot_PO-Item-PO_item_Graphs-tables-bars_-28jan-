#!/usr/bin/env python3
"""
Test the 4 real-world failing cases reported by the user.
"""

import sys
sys.path.insert(0, '/Users/rutujadhage/agentic-rag-nl2sql (PO)')

from agent_semantic_analyzer import SemanticAnalyzer
from agent_sql_generator import SQLGeneratorAgent
from agent_retriever import RetrievalAgent
import json

# Initialize agents
semantic_analyzer = SemanticAnalyzer()
sql_generator = SQLGeneratorAgent()
retriever = RetrievalAgent()

# Test cases: (question, expected_sql_contains, description)
test_cases = [
    (
        "List the 5 most recently created purchase orders",
        ["SELECT", "po", "created_at", "DESC", "LIMIT 5"],
        "Should query PO table, ordered by created_at DESC, with LIMIT 5"
    ),
    (
        "List items with their least purchase price and previous purchase price",
        ["SELECT", "items", "least_purchase_price", "previous_purchase_price"],
        "Should query ITEMS table with stored columns (not derived from po_items)"
    ),
    (
        "Which item has the highest total ordered quantity?",
        ["SELECT", "LIMIT 1"],
        "Should return LIMIT 1 (singular result for 'which')"
    ),
    (
        "How many purchase orders are in draft status?",
        ["SELECT", "COUNT", "po", "draft", "STATUS"],
        "Should count POs with draft status (or filter by status='DRAFT')"
    ),
]

print("=" * 80)
print("SEMANTIC ANALYSIS FOR 4 REAL-WORLD FAILING CASES")
print("=" * 80)

for i, (question, expected_tokens, description) in enumerate(test_cases, 1):
    print(f"\n[TEST {i}] {question}")
    print(f"Description: {description}")
    print("-" * 80)
    
    # Analyze semantics
    semantic_context = semantic_analyzer.analyze(question)
    print(f"Semantic Intent:")
    print(f"  - table_intent: {semantic_context['table_intent']}")
    print(f"  - result_cardinality: {semantic_context['result_cardinality']}")
    print(f"  - aggregation_type: {semantic_context['aggregation_type']}")
    print(f"  - null_handling: {semantic_context['null_handling']}")
    print(f"  - entity_scope: {semantic_context['entity_scope']}")
    
    # Try to generate SQL
    try:
        schema_context = retriever.retrieve(question)
        sql = sql_generator.generate_sql(question, schema_context)
        
        if sql:
            print(f"\n✓ Generated SQL:")
            print(f"  {sql}")
            
            # Check if expected tokens are present
            sql_upper = sql.upper()
            missing_tokens = []
            for token in expected_tokens:
                if token.upper() not in sql_upper:
                    missing_tokens.append(token)
            
            if missing_tokens:
                print(f"\n⚠️  Missing expected tokens: {missing_tokens}")
            else:
                print(f"\n✓ All expected tokens found!")
        else:
            print(f"\n✗ SQL generation returned empty (fallback may have failed)")
    except Exception as e:
        print(f"\n✗ Error during SQL generation: {e}")
    
    print("=" * 80)

print("\nTest summary:")
print("- If all tests pass, the issues are resolved")
print("- If tests fail, review the semantic analysis and SQL generation logic")
