#!/usr/bin/env python3
"""Test that the fallback message bug is fixed."""

import requests

def test_no_fallback_message():
    """Verify the bad message 'I can assist with product, order, and vendor...' NEVER appears."""
    
    tests = [
        ("Find the total number of orders in the system", "Total orders"),
        ("Calculate the total revenue from all orders", "Total revenue"),
        ("Show the average order amount", "Average order"),
        ("List all products and their categories", "Products"),
        ("Find users who have placed orders", "Users with orders"),
        ("Show top 3 users by spending", "Top spenders"),
        ("What is the total count of all customers", "Total customers"),
        ("Find the maximum order value", "Max order"),
    ]
    
    bad_message = "I can assist with product, order, and vendor-related information"
    
    print("\n" + "="*70)
    print("🧪 CRITICAL BUG FIX VERIFICATION")
    print("="*70)
    print("\nTesting that bad message NEVER appears:\n")
    print(f"Bad Message: '{bad_message}'\n")
    print("="*70 + "\n")
    
    failed = 0
    passed = 0
    
    for question, label in tests:
        try:
            resp = requests.post(
                "http://localhost:8000/query",
                json={"question": question},
                timeout=15
            )
            data = resp.json()
            
            if bad_message in data['answer']:
                print(f"❌ FAIL: {label}")
                print(f"   Got bad message: {data['answer'][:80]}...\n")
                failed += 1
            else:
                print(f"✅ PASS: {label}")
                # Show what we got instead
                if data.get('sql'):
                    print(f"   Got SQL: {data['sql'][:60]}...")
                    print(f"   Answer: {data['answer'][:70]}...\n")
                else:
                    print(f"   Answer: {data['answer'][:70]}...\n")
                passed += 1
        except Exception as e:
            print(f"❌ ERROR: {label} - {str(e)}\n")
            failed += 1
    
    print("="*70)
    print(f"RESULTS: {passed}/{len(tests)} passed, {failed} failed")
    print("="*70)
    
    if failed == 0:
        print("\n🎉 CRITICAL BUG FIXED!")
        print("   Bad message NEVER appears ✅")
        print("   All queries handled correctly ✅\n")
        return True
    else:
        print(f"\n⚠️  BUG STILL PRESENT: {failed} tests failed\n")
        return False


if __name__ == "__main__":
    success = test_no_fallback_message()
    exit(0 if success else 1)
