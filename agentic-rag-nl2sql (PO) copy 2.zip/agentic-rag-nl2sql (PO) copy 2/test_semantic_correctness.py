#!/usr/bin/env python3
"""
Validation Test for Semantic Correctness Fix

Tests that:
1. SemanticAnalyzer correctly classifies questions
2. SQL Generator uses semantic context
3. Fallback pattern matching respects semantic rules
4. Common question types return semantically correct SQL
"""

import sys
from agent_semantic_analyzer import SemanticAnalyzer
from agent_sql_generator import SQLGeneratorAgent


def test_semantic_analyzer():
    """Test SemanticAnalyzer classifications"""
    print("\n" + "="*60)
    print("TESTING SEMANTIC ANALYZER")
    print("="*60)
    
    analyzer = SemanticAnalyzer()
    
    test_cases = [
        # (question, expected_table_intent, expected_cardinality, expected_aggregation)
        ("What items exist?", "master", "plural", "none"),
        ("List all items", "master", "plural", "none"),
        ("Item names", "master", "plural", "none"),
        ("Least purchase price", "master", "plural", "stored"),
        ("Most ordered items", "transactional", "plural", "derived"),
        ("Most ordered item", "transactional", "singular", "derived"),
        ("Which item is most ordered?", "transactional", "singular", "derived"),
        ("How many POs?", "transactional", "plural", "none"),
        ("Recent purchase orders", "transactional", "plural", "none"),
        ("Top 3 items", "transactional", "singular", "derived"),
        ("Calculate average price", "transactional", "plural", "derived"),
    ]
    
    passed = 0
    failed = 0
    
    for question, exp_table, exp_card, exp_agg in test_cases:
        result = analyzer.analyze(question)
        
        table_match = result['table_intent'] == exp_table
        card_match = result['result_cardinality'] == exp_card
        agg_match = result['aggregation_type'] == exp_agg
        
        status = "✓ PASS" if (table_match and card_match and agg_match) else "✗ FAIL"
        
        print(f"\n{status}")
        print(f"  Q: {question}")
        print(f"  Table: {result['table_intent']} (expected {exp_table}) {'✓' if table_match else '✗'}")
        print(f"  Cardinality: {result['result_cardinality']} (expected {exp_card}) {'✓' if card_match else '✗'}")
        print(f"  Aggregation: {result['aggregation_type']} (expected {exp_agg}) {'✓' if agg_match else '✗'}")
        
        if table_match and card_match and agg_match:
            passed += 1
        else:
            failed += 1
    
    print(f"\n{'='*60}")
    print(f"RESULTS: {passed} passed, {failed} failed")
    return failed == 0


def test_sql_generator_integration():
    """Test that SQL Generator uses semantic context"""
    print("\n" + "="*60)
    print("TESTING SQL GENERATOR INTEGRATION")
    print("="*60)
    
    generator = SQLGeneratorAgent()
    
    # Check that semantic analyzer is initialized
    assert hasattr(generator, 'semantic_analyzer'), \
        "❌ SQLGeneratorAgent missing semantic_analyzer"
    print("✓ SQLGeneratorAgent has semantic_analyzer")
    
    # Check that semantic analyzer has required methods
    assert hasattr(generator.semantic_analyzer, 'analyze'), \
        "❌ SemanticAnalyzer missing analyze() method"
    print("✓ SemanticAnalyzer has analyze() method")
    
    assert hasattr(generator.semantic_analyzer, 'get_prompt_injection'), \
        "❌ SemanticAnalyzer missing get_prompt_injection() method"
    print("✓ SemanticAnalyzer has get_prompt_injection() method")
    
    assert hasattr(generator, '_semantic_fallback_generate_sql'), \
        "❌ SQLGeneratorAgent missing _semantic_fallback_generate_sql() method"
    print("✓ SQLGeneratorAgent has _semantic_fallback_generate_sql() method")
    
    assert hasattr(generator, '_generate_master_data_query'), \
        "❌ SQLGeneratorAgent missing _generate_master_data_query() method"
    print("✓ SQLGeneratorAgent has _generate_master_data_query() method")
    
    assert hasattr(generator, '_generate_transactional_query'), \
        "❌ SQLGeneratorAgent missing _generate_transactional_query() method"
    print("✓ SQLGeneratorAgent has _generate_transactional_query() method")
    
    print("\n✓ SQL Generator integration complete")
    return True


def test_fallback_pattern_semantics():
    """Test that fallback patterns respect semantic rules"""
    print("\n" + "="*60)
    print("TESTING FALLBACK PATTERN SEMANTICS")
    print("="*60)
    
    generator = SQLGeneratorAgent()
    analyzer = SemanticAnalyzer()
    
    # Dummy schema context
    schema_context = [
        {"table": "items", "type": "table_info", "text": "Items table"},
        {"table": "po", "type": "table_info", "text": "PO table"},
        {"table": "po_items", "type": "table_info", "text": "PO Items table"},
    ]
    
    test_cases = [
        # Master data questions
        ("List all items", "items"),  # Should query items
        ("Show item names", "items"),  # Should query items
        
        # Transactional questions
        ("Most ordered item", "COUNT"),  # Should have aggregation
        ("Recent purchase orders", "po"),  # Should query po
        
        # Singular intent
        ("Most ordered item", "LIMIT 1"),  # Should have LIMIT 1
        ("Top item", "LIMIT 1"),  # Should have LIMIT 1
        
        # Plural intent
        ("List all items", "LIMIT 20"),  # Should have reasonable LIMIT
        ("Show purchase orders", "LIMIT 20"),  # Should have reasonable LIMIT
    ]
    
    passed = 0
    failed = 0
    
    for question, expected_keyword in test_cases:
        semantic_ctx = analyzer.analyze(question)
        
        # Get SQL from fallback
        if semantic_ctx['table_intent'] == 'master':
            sql = generator._generate_master_data_query(
                question.lower(), semantic_ctx, 
                analyzer.get_table_recommendations(semantic_ctx)
            )
        else:
            sql = generator._generate_transactional_query(
                question.lower(), semantic_ctx,
                analyzer.get_table_recommendations(semantic_ctx)
            )
        
        if sql and expected_keyword.lower() in sql.lower():
            print(f"✓ PASS: '{question}'")
            print(f"    Found '{expected_keyword}' in generated SQL")
            passed += 1
        else:
            print(f"✗ FAIL: '{question}'")
            print(f"    Expected '{expected_keyword}' in SQL")
            print(f"    Got: {sql[:100] if sql else 'EMPTY'}")
            failed += 1
    
    print(f"\n{'='*60}")
    print(f"RESULTS: {passed} passed, {failed} failed")
    return failed == 0


def main():
    """Run all validation tests"""
    print("\n" + "="*60)
    print("SEMANTIC CORRECTNESS FIX — VALIDATION TESTS")
    print("="*60)
    
    all_passed = True
    
    # Test 1: Semantic Analyzer
    try:
        if not test_semantic_analyzer():
            all_passed = False
    except Exception as e:
        print(f"\n❌ Semantic Analyzer test FAILED with error: {e}")
        all_passed = False
    
    # Test 2: SQL Generator Integration
    try:
        if not test_sql_generator_integration():
            all_passed = False
    except Exception as e:
        print(f"\n❌ SQL Generator integration test FAILED with error: {e}")
        all_passed = False
    
    # Test 3: Fallback Pattern Semantics
    try:
        if not test_fallback_pattern_semantics():
            all_passed = False
    except Exception as e:
        print(f"\n❌ Fallback pattern semantics test FAILED with error: {e}")
        all_passed = False
    
    # Summary
    print("\n" + "="*60)
    if all_passed:
        print("✓ ALL TESTS PASSED")
        print("="*60)
        return 0
    else:
        print("✗ SOME TESTS FAILED")
        print("="*60)
        return 1


if __name__ == "__main__":
    sys.exit(main())
