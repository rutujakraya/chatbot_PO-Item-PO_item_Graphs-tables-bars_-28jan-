#!/usr/bin/env python3
import requests

questions = [
    "bye",
    "2+2 is",
    "what is your name",
    "what is 2 + 2 is",
    "Find the maximum and minimum order total amount.",
    "Find the top 3 users by total spending.",
]

print("\n" + "="*70)
print("🧪 STATE BUG FIX VERIFICATION")
print("="*70 + "\n")

for i, q in enumerate(questions, 1):
    resp = requests.post("http://localhost:8000/query", json={"question": q}, timeout=15)
    data = resp.json()
    
    is_db_q = any(x in q.lower() for x in ['find', 'maximum', 'minimum', 'top', 'total', 'spending'])
    has_bad_msg = "not available" in data['answer'].lower()
    
    if is_db_q and has_bad_msg:
        print(f"❌ Q{i} FAILED: {q[:45]}")
        print(f"   Got: {data['answer'][:70]}...\n")
    else:
        print(f"✅ Q{i} PASS: {q[:45]}")
        print(f"   Got: {data['answer'][:70]}...\n")

print("="*70)
