import json
import re
from datetime import datetime


class VisualizationMapper:
    """
    Data-to-Visualization JSON Mapper
    
    Responsibility: Convert raw SQL results to visualization JSON schemas
    
    Hard rules:
    - Output ONLY valid JSON
    - Do NOT generate SQL
    - Do NOT write UI code (React, JSX, etc.)
    - Do NOT add explanations or markdown
    - Use only provided data (no invention)
    """
    
    def map(self, user_query: str, columns: list, rows: list) -> dict:
        """
        Map SQL results to visualization JSON.
        
        Args:
            user_query: User's original question
            columns: List of column names from SQL result
            rows: List of row data (lists or tuples)
            
        Returns:
            JSON-compatible dict with visualization schema
        """
        # Decide visualization type
        chart_type = self._decide_chart_type(user_query, columns, rows)
        
        if chart_type == "none":
            return {"chart_type": "none"}
        elif chart_type == "bar":
            return self._map_to_bar(user_query, columns, rows)
        elif chart_type == "line":
            return self._map_to_line(user_query, columns, rows)
        elif chart_type == "kpi":
            return self._map_to_kpi(user_query, columns, rows)
        else:  # table
            return self._map_to_table(columns, rows)
    
    def _decide_chart_type(self, user_query: str, columns: list, rows: list) -> str:
        """
        Decide which visualization type based on user intent.
        
        Returns: "bar", "line", "kpi", "table", or "none"
        """
        q = user_query.lower()
        
        # Single value → KPI
        if (len(rows) == 1 and len(columns) == 1) or \
           any(keyword in q for keyword in ["total", "count", "sum", "average", "avg", "maximum", "minimum", "max", "min"]):
            if len(rows) == 1 and len(columns) == 1:
                return "kpi"
        
        # Trend/Time series → LINE
        if any(keyword in q for keyword in ["trend", "over time", "time series", "line chart", "line"]):
            if self._has_date_column(columns):
                return "line"
        
        # Comparison/Groups → BAR
        if any(keyword in q for keyword in ["bar", "compare", "comparison", "by ", "breakdown", "distribution", "bar chart"]):
            return "bar"
        
        # Explicit table request
        if any(keyword in q for keyword in ["table", "list", "show all", "display"]):
            return "table"
        
        # Default: table
        return "table"
    
    def _has_date_column(self, columns: list) -> bool:
        """Check if any column looks like a date."""
        date_keywords = ["date", "time", "created", "updated", "timestamp"]
        return any(any(keyword in col.lower() for keyword in date_keywords) for col in columns)
    
    def _get_numeric_column(self, columns: list) -> int:
        """Get index of first numeric-looking column."""
        numeric_keywords = ["amount", "total", "price", "value", "count", "sum", "quantity"]
        for i, col in enumerate(columns):
            if any(keyword in col.lower() for keyword in numeric_keywords):
                return i
        # Fallback: try last column
        return len(columns) - 1
    
    def _get_category_column(self, columns: list) -> int:
        """Get index of first categorical column."""
        category_keywords = ["name", "status", "type", "category", "product", "order", "po"]
        for i, col in enumerate(columns):
            if any(keyword in col.lower() for keyword in category_keywords):
                return i
        # Fallback: first column
        return 0
    
    def _map_to_bar(self, user_query: str, columns: list, rows: list) -> dict:
        """Map to bar chart schema."""
        if not rows or not columns:
            return {"chart_type": "none"}
        
        try:
            x_idx = self._get_category_column(columns)
            y_idx = self._get_numeric_column(columns)
            
            if x_idx == y_idx or y_idx < 0:
                return {"chart_type": "none"}
            
            data = []
            for row in rows[:50]:  # Limit to 50 bars
                x_val = str(row[x_idx])
                y_val = self._to_number(row[y_idx])
                
                if y_val is not None:
                    data.append({"name": x_val, "value": y_val})
            
            if not data:
                return {"chart_type": "none"}
            
            title = f"{columns[y_idx]} by {columns[x_idx]}"
            
            return {
                "chart_type": "bar",
                "title": title,
                "x_key": "name",
                "y_key": "value",
                "data": data
            }
        except Exception:
            return {"chart_type": "none"}
    
    def _map_to_line(self, user_query: str, columns: list, rows: list) -> dict:
        """Map to line chart schema."""
        if not rows or not columns:
            return {"chart_type": "none"}
        
        try:
            # Find date column
            date_idx = -1
            value_idx = -1
            
            for i, col in enumerate(columns):
                if any(kw in col.lower() for kw in ["date", "time", "created", "timestamp"]):
                    date_idx = i
                if any(kw in col.lower() for kw in ["amount", "total", "price", "value", "count"]):
                    value_idx = i
            
            if date_idx < 0 or value_idx < 0:
                return {"chart_type": "none"}
            
            data = []
            for row in rows[:100]:  # Limit to 100 points
                date_val = self._to_date_string(row[date_idx])
                value_val = self._to_number(row[value_idx])
                
                if date_val and value_val is not None:
                    data.append({"date": date_val, "value": value_val})
            
            if not data:
                return {"chart_type": "none"}
            
            return {
                "chart_type": "line",
                "title": f"{columns[value_idx]} over time",
                "x_key": "date",
                "y_key": "value",
                "data": data
            }
        except Exception:
            return {"chart_type": "none"}
    
    def _map_to_kpi(self, user_query: str, columns: list, rows: list) -> dict:
        """Map to KPI/summary schema."""
        if not rows or not columns:
            return {"chart_type": "none"}
        
        try:
            # Single cell value
            if len(rows) == 1 and len(columns) == 1:
                value = self._to_number(rows[0][0])
                if value is not None:
                    return {
                        "chart_type": "kpi",
                        "title": columns[0],
                        "value": value,
                        "unit": ""
                    }
            
            # Sum a numeric column
            numeric_idx = self._get_numeric_column(columns)
            total = 0
            for row in rows:
                num = self._to_number(row[numeric_idx])
                if num is not None:
                    total += num
            
            return {
                "chart_type": "kpi",
                "title": f"Total {columns[numeric_idx]}",
                "value": total,
                "unit": ""
            }
        except Exception:
            return {"chart_type": "none"}
    
    def _map_to_table(self, columns: list, rows: list) -> dict:
        """Map to table schema."""
        if not columns or not rows:
            return {"chart_type": "none"}
        
        try:
            table_columns = [
                {"key": col, "label": self._humanize_label(col)}
                for col in columns
            ]
            
            table_data = []
            for row in rows[:100]:  # Limit to 100 rows
                row_dict = {}
                for i, col in enumerate(columns):
                    row_dict[col] = row[i] if i < len(row) else ""
                table_data.append(row_dict)
            
            return {
                "chart_type": "table",
                "columns": table_columns,
                "data": table_data
            }
        except Exception:
            return {"chart_type": "none"}
    
    def _to_number(self, value) -> float:
        """Convert value to number, return None if not possible."""
        if value is None:
            return None
        
        if isinstance(value, (int, float)):
            return float(value)
        
        try:
            return float(str(value).strip())
        except (ValueError, TypeError):
            return None
    
    def _to_date_string(self, value) -> str:
        """Convert value to YYYY-MM-DD string, return None if not possible."""
        if value is None:
            return None
        
        if isinstance(value, str):
            # Check if already in ISO format
            if re.match(r'\d{4}-\d{2}-\d{2}', value):
                return value[:10]
            # Try to parse common formats
            for fmt in ["%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y", "%Y/%m/%d"]:
                try:
                    dt = datetime.strptime(value[:10], fmt)
                    return dt.strftime("%Y-%m-%d")
                except (ValueError, TypeError):
                    continue
        
        if hasattr(value, "date"):  # datetime object
            return value.date().isoformat()
        
        return None
    
    def _humanize_label(self, column_name: str) -> str:
        """Convert column_name to human-readable label."""
        # Replace underscores with spaces
        label = column_name.replace("_", " ")
        # Capitalize words
        label = " ".join(word.capitalize() for word in label.split())
        return label
