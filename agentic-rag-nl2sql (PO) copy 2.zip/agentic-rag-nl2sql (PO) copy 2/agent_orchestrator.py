from agent_planner import PlannerAgent
from agent_retriever import RetrievalAgent
from agent_sql_generator import SQLGeneratorAgent
from agent_sql_validator import SQLValidatorAgent
from agent_sql_executor import SQLExecutorAgent
from agent_response_formatter import ResponseFormatterAgent
from agent_visualization_mapper import VisualizationMapper
import re
import json
import os
from dotenv import load_dotenv

load_dotenv()


class AgentOrchestrator:
    """
    INDUSTRY-GRADE Agentic Orchestrator with SECURITY & PRIVACY.
    
    Routes questions through TWO distinct pipelines:
    
    1) GENERAL QUESTIONS (intent='direct')
       → LLaMA-3 8B direct call
       → 2-line polite response
       → No database access
    
    2) DATABASE QUESTIONS (intent='rag_sql')
       → Retrieve metadata chunks from db_metadata.txt
       → Generate SQL using LLaMA-3 8B with injected context
       → Validate and execute SQL
       → Format business-friendly response
       → Map to visualization JSON (bar, line, table, kpi)
    
    SECURITY:
    - Sensitive information (passwords, credentials) NEVER exposed to users
    - SQL and raw data logged to TERMINAL ONLY for developer debugging
    - Chatbot UI shows ONLY clean natural-language answers
    - Requests for database internals (schema, table names, column names) are refused
    """
    
    def __init__(self):
        # Core agents
        self.planner = PlannerAgent()
        self.retriever = RetrievalAgent()
        self.sql_generator = SQLGeneratorAgent()
        self.sql_validator = SQLValidatorAgent()
        self.sql_executor = SQLExecutorAgent()
        self.formatter = ResponseFormatterAgent()
        self.mapper = VisualizationMapper()
        
        # Configuration
        self.max_rows_return = 20
        self.max_retries = 5  # Increased from 2 to 5 for better SQL generation resilience
        
        # Security & Logging
        self.debug_mode = os.getenv("DEBUG_MODE", "False").lower() == "true"
        self.log_queries = os.getenv("LOG_QUERIES", "True").lower() == "true"
        self.log_results = os.getenv("LOG_RESULTS", "True").lower() == "true"

    def _check_sensitive_request(self, user_query: str) -> bool:
        """
        SECURITY: Detect requests for sensitive database information.
        Block only EXPLICIT requests for credentials or system internals.
        
        IMPORTANT: Avoid over-blocking legitimate business questions.
        Users should be able to ask questions about data even if they
        contain words like "system" in normal context.
        """
        sensitive_keywords = [
            # Credentials (strict match - must be explicitly asking for)
            "password", "credential", "secret", "api key", "token",
            
            # Connection details (explicit system internals)
            "connection string", "hostname", "connection url",
            "database url", "db url",
            
            # System configuration (explicit requests)
            "environment variable", "env var",
            
            # Schema details (explicit requests for internals, not data)
            "table name", "column name", "table structure",
            "database structure", "what tables", "what columns",
            "show all tables", "list all columns",
            
            # Dangerous operations
            "drop table", "delete all", "truncate",
            "alter table", "create table without",
        ]
        
        query_lower = user_query.lower()
        for keyword in sensitive_keywords:
            if keyword in query_lower:
                return True
        
        return False

    def _log_backend(self, message: str):
        """
        Log to terminal ONLY (for developer debugging).
        NOT visible to chatbot UI.
        """
        if self.debug_mode:
            print(f"[BACKEND LOG] {message}")

    def _normalize_rows(self, rows: list, columns: list) -> list:
        """
        Convert database objects (Decimal, datetime) to JSON-serializable types.
        Decimal → float, datetime → ISO string
        """
        from decimal import Decimal
        from datetime import datetime
        
        if not rows:
            return rows
        
        normalized_rows = []
        for row in rows:
            if isinstance(row, (tuple, list)):
                normalized_row = []
                for value in row:
                    if isinstance(value, Decimal):
                        normalized_row.append(float(value))
                    elif isinstance(value, datetime):
                        normalized_row.append(value.isoformat())
                    else:
                        normalized_row.append(value)
                normalized_rows.append(normalized_row)
            else:
                normalized_rows.append(row)
        
        return normalized_rows

    def run(self, user_query: str) -> dict:
        """
        Main agentic control loop.
        
        Returns structured dict with:
        - answer: User-facing response (string)
        - sql: Generated SQL query or None
        - result: DB result dict or None
        - context: Retrieved metadata chunks or None
        - agent_flow: List of steps taken (for debugging)
        """
        
        # CRITICAL: Ensure SQL executor has a healthy connection
        # This prevents state leaking from previous requests
        self.sql_executor._ensure_connection()
        
        agent_flow = []

        # ===== STEP 0: GREETING/GOODBYE/THANKS DETECTION =====
        # These MUST be handled BEFORE agentic logic to avoid unnecessary DB calls
        greeting_type = self.planner.detect_greeting_or_goodbye(user_query)
        
        if greeting_type == "greeting":
            agent_flow.append("User greeting detected")
            answer = "Welcome to Kraya AI. How can I assist you today?"
            return {
                "answer": answer,
                "sql": None,
                "result": None,
                "context": None,
                "agent_flow": agent_flow
            }
        
        if greeting_type == "goodbye":
            agent_flow.append("User goodbye detected")
            answer = "Thank you for using Kraya AI. Have a great day."
            return {
                "answer": answer,
                "sql": None,
                "result": None,
                "context": None,
                "agent_flow": agent_flow
            }
        
        if greeting_type == "thanks":
            agent_flow.append("User gratitude detected")
            answer = "You're welcome. Kraya AI is happy to help."
            return {
                "answer": answer,
                "sql": None,
                "result": None,
                "context": None,
                "agent_flow": agent_flow
            }

        # ===== STEP 0b: IDENTITY & PRODUCT DESCRIPTION DETECTION =====
        # LLM-only questions (no SQL, no RAG)
        identity_type = self.planner.detect_identity_or_product_question(user_query)
        
        if identity_type == "identity":
            agent_flow.append("User identity question detected")
            answer = "I'm Kraya AI, a procurement assistant. I'm here to help you manage purchase orders, vendors, and related data efficiently."
            return {
                "answer": answer,
                "sql": None,
                "result": None,
                "context": None,
                "agent_flow": agent_flow
            }
        
        if identity_type == "product":
            agent_flow.append("User product description question detected")
            answer = (
                "What is Kraya?\n"
                "Kraya is a digital procurement platform designed to make sourcing, vendor management, and purchasing processes more efficient, transparent, and data-driven."
            )
            return {
                "answer": answer,
                "sql": None,
                "result": None,
                "context": None,
                "agent_flow": agent_flow
            }

        # ===== SECURITY CHECK: Reject sensitive requests =====
        if self._check_sensitive_request(user_query):
            agent_flow.append("Security check: BLOCKED (sensitive request)")
            answer = (
                "I can't share sensitive system or database details, "
                "but I can help answer questions about the data itself. "
                "For example: 'How many users do we have?' or 'Show me recent orders.'"
            )
            return {
                "answer": answer,
                "sql": None,
                "result": None,
                "context": None,
                "agent_flow": agent_flow
            }

        # ===== STEP 1: INTENT CLASSIFICATION =====
        intent = self.planner.classify_intent(user_query)
        agent_flow.append(f"Intent classification: {intent}")
        self._log_backend(f"User query: {user_query}")
        self._log_backend(f"Intent: {intent}")

        # ===== GENERAL QUESTION PATH =====
        if intent == "direct":
            # Use LLaMA-3 8B directly for general Q&A
            answer = self.formatter.generate_general_response(user_query)
            agent_flow.append("Route: Direct LLM (general question)")
            self._log_backend(f"General Q&A response: {answer}")
            
            return {
                "answer": answer,
                "sql": None,
                "result": None,
                "context": None,
                "agent_flow": agent_flow
            }

        # ===== DATABASE QUESTION PATH (RAG + SQL) =====
        agent_flow.append("Route: RAG + SQL (database question)")

        # STEP 2: Retrieve metadata context from db_metadata.txt
        context = self.retriever.retrieve(user_query, limit=5)
        
        if not context:
            agent_flow.append("⚠️  No metadata retrieved from Qdrant")
            answer = "I couldn't find relevant database information for that question. Please ensure Qdrant is running and contains schema chunks."
            return {
                "answer": answer,
                "sql": None,
                "result": None,
                "context": None,
                "agent_flow": agent_flow
            }
        
        agent_flow.append(f"Retrieved {len(context)} metadata chunks")

        # Reset invalid columns tracker for new query
        self.sql_validator.reset_invalid_columns()

        # STEP 3: Retry loop for SQL generation and execution
        for attempt in range(self.max_retries):
            agent_flow.append(f"--- Attempt {attempt + 1} ---")
            
            # 3a. Generate SQL with injected metadata context
            sql = self.sql_generator.generate_sql(user_query, context)
            
            if not sql:
                agent_flow.append(f"  ❌ SQL generation failed")
                continue
            
            agent_flow.append(f"  ✓ Generated SQL: {sql[:80]}...")
            # Log SQL to terminal ONLY (not UI)
            if self.log_queries:
                self._log_backend(f"Generated SQL: {sql}")

            # 3b. Validate SQL (now includes column checking)
            validation_result = self.sql_validator.validate(sql, context)
            if not validation_result['valid']:
                agent_flow.append(f"  ❌ SQL validation failed: {validation_result['error']}")
                continue
            
            agent_flow.append(f"  ✓ SQL validation passed")

            # 3c. Execute SQL on database
            try:
                self._log_backend(f"Executing SQL attempt {attempt + 1}/{self.max_retries}")
                result = self.sql_executor.execute(sql)
                
                if result is None:
                    self._log_backend(f"❌ Attempt {attempt + 1}: SQL execution returned None")
                    agent_flow.append(f"  ❌ SQL execution returned None")
                    continue
                
                # Log result to terminal ONLY (not UI)
                rows_count = len(result.get('rows', []))
                self._log_backend(f"✓ Attempt {attempt + 1}: Query result rows: {rows_count}")
                if self.log_results:
                    self._log_backend(f"Query result rows: {rows_count}")
                    if self.debug_mode:  # Only show actual data in debug mode
                        self._log_backend(f"Result data: {result}")
            except Exception as e:
                error_str = str(e)
                error_short = error_str[:60]
                self._log_backend(f"❌ Attempt {attempt + 1}: SQL execution error: {error_short}")
                agent_flow.append(f"  ❌ SQL execution error: {error_short}")
                
                # INTELLIGENT ERROR ANALYSIS: Detect specific SQL errors and trigger corrections
                
                # 0) COLUMN DOES NOT EXIST ERROR - Track invalid columns to prevent retry reuse
                if "does not exist" in error_str.lower() and "column" in error_str.lower():
                    # Extract column name from error if possible
                    col_match = re.search(r'column\s+"?([a-zA-Z0-9_.]+)"?', error_str, re.IGNORECASE)
                    if col_match:
                        invalid_col = col_match.group(1)
                        self.sql_validator.add_invalid_column(invalid_col)
                        self._log_backend(f"  → Detected non-existent column: {invalid_col} (marked for rejection)")
                        agent_flow.append(f"  → Column '{invalid_col}' does not exist (will not retry)")
                    # Continue to next attempt - LLM should avoid this column now
                    continue
                
                # 1) AMBIGUOUS COLUMN ERROR - LLM generated unqualified columns in JOIN queries
                if "is ambiguous" in error_str.lower() and "column" in error_str.lower():
                    self._log_backend(f"  → Detected ambiguous column error (unqualified in JOIN)")
                    agent_flow.append(f"  → Detected ambiguous column error (unqualified in JOIN)")
                    # Continue to next attempt - LLM should be smarter next time due to error exposure
                    continue
                
                # 2) GROUP BY violations - ORDER BY non-grouped column
                if "must appear in the group by clause" in error_str.lower() or "not a member of any table in the from clause" in error_str.lower():
                    # GROUP BY error detected - attempt to fix with subquery wrapper
                    self._log_backend(f"  → Detected GROUP BY error, attempting subquery wrapper fix...")
                    agent_flow.append(f"  → Detected GROUP BY error, attempting subquery wrapper fix...")
                    
                    # Try to wrap the query in a subquery
                    try:
                        # Extract the inner SELECT query
                        if sql.strip().upper().startswith("SELECT"):
                            inner_sql = sql.rstrip(";").strip()
                            wrapped_sql = f"SELECT * FROM ({inner_sql}) t LIMIT 20;"
                            
                            self._log_backend(f"  → Retry with wrapped SQL: {wrapped_sql[:80]}...")
                            agent_flow.append(f"  → Retrying with subquery wrapper...")
                            
                            # Validate and execute the wrapped query
                            validation_result = self.sql_validator.validate(wrapped_sql, context)
                            if validation_result['valid']:
                                try:
                                    result = self.sql_executor.execute(wrapped_sql)
                                    if result and len(result.get('rows', [])) > 0:
                                        self._log_backend(f"✓ Subquery wrapper fix succeeded!")
                                        agent_flow.append(f"  ✓ Subquery wrapper fix succeeded!")
                                        sql = wrapped_sql  # Update sql to the fixed version
                                        rows = result.get("rows", [])
                                        total = len(rows)
                                        
                                        # 3e. Format and return the result
                                        if total > self.max_rows_return:
                                            clarification = self.formatter.clarify_large_result(total)
                                            agent_flow.append(f"  → {total} rows (exceeds {self.max_rows_return} limit)")
                                            return {
                                                "answer": clarification,
                                                "sql": sql,
                                                "result": result,
                                                "context": context,
                                                "agent_flow": agent_flow
                                            }
                                        
                                        answer = self.formatter.format(user_query=user_query, sql=wrapped_sql, result=result)
                                        agent_flow.append(f"  ✓ Formatted result ({total} rows)")
                                        return {
                                            "answer": answer,
                                            "sql": sql,
                                            "result": result,
                                            "context": context,
                                            "agent_flow": agent_flow
                                        }
                                except Exception as wrap_error:
                                    self._log_backend(f"  → Subquery wrapper also failed: {str(wrap_error)[:60]}")
                                    agent_flow.append(f"  → Subquery wrapper also failed")
                    except Exception as wrap_prep_error:
                        self._log_backend(f"  → Could not prepare subquery wrapper: {str(wrap_prep_error)[:60]}")
                        agent_flow.append(f"  → Could not prepare subquery wrapper")
                
                continue
            
            agent_flow.append(f"  ✓ SQL execution successful")

            # 3d. Check result size
            rows = result.get("rows", [])
            total = len(rows)
            
            if total == 0:
                answer = "That information is not available in the database."
                agent_flow.append(f"  → No rows returned")
                return {
                    "answer": answer,
                    "sql": sql,
                    "result": result,
                    "context": context,
                    "agent_flow": agent_flow
                }
            
            # 3e. Handle large results
            if total > self.max_rows_return:
                clarification = self.formatter.clarify_large_result(total)
                agent_flow.append(f"  → {total} rows (exceeds {self.max_rows_return} limit, asking for clarification)")
                return {
                    "answer": clarification,
                    "sql": sql,
                    "result": None,  # Don't return raw data for large results
                    "context": context,
                    "agent_flow": agent_flow
                }

            # 3f. Format and return successful result with optional visualization
            # NEW APPROACH: Return structured JSON for tables/charts, not HTML/markdown
            
            columns = result.get("columns", [])
            num_rows = total
            num_cols = len(columns)
            
            # CRITICAL: Normalize Decimal and datetime to JSON-serializable types
            rows = self._normalize_rows(rows, columns)
            
            # Map SQL results to visualization JSON FIRST
            # (to determine if we'll render a visualization instead of text)
            columns = result.get("columns", [])
            viz_json = self.mapper.map(user_query, columns, rows)
            
            # Determine if we should suppress text rendering
            # If we have a table/chart visualization, don't also render text table
            has_visualization = viz_json.get("chart_type") != "none"
            
            # Initialize answer with text summary
            # Skip text rendering if visualization will be shown
            text_answer = self.formatter.format(
                user_query=user_query,
                sql=sql,
                result=result,
                skip_text=has_visualization  # Don't render text if we have visualization
            )
            
            # Build response payload
            response_payload = {
                "text": text_answer,
                "columns": columns,
                "rows": rows
            }
            
            # Add visualization if available
            if has_visualization:
                response_payload["visualization"] = viz_json
                agent_flow.append(f"  → Visualization mapped: {viz_json.get('chart_type')} from {total} rows")
            
            # Serialize response_payload as JSON string for transmission
            answer = json.dumps(response_payload)
            
            agent_flow.append(f"  → {total} rows returned as structured JSON")
            
            # SUCCESS: Return immediately without further retries
            return {
                "answer": answer,
                "sql": sql,
                "result": result,
                "context": context,
                "agent_flow": agent_flow
            }

        # ===== FALLBACK: All SQL generation attempts exhausted =====
        agent_flow.append(f"❌ Failed to generate valid SQL after {self.max_retries} attempts")
        agent_flow.append("Fallback: Treating as data not available")
        
        # Instead of generic vendor message, be honest about data availability
        answer = "That information is not available in the database."
        
        return {
            "answer": answer,
            "sql": None,
            "result": None,
            "context": context,
            "agent_flow": agent_flow
        }
