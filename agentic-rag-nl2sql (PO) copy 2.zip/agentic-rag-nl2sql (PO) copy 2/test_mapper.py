#!/usr/bin/env python3
from agent_visualization_mapper import VisualizationMapper
import json

mapper = VisualizationMapper()

# Test 1: Bar chart
print("TEST 1: BAR CHART")
result1 = mapper.map(
    "Show a bar chart of total amount by purchase order",
    ["po_no", "status", "total", "created_at"],
    [["PO-001", "DRAFT", "5000", "2026-01-22"],
     ["PO-002", "APPROVED", "6000", "2026-01-21"]]
)
print(json.dumps(result1, indent=2))
assert result1["chart_type"] == "bar"
assert len(result1["data"]) == 2

# Test 2: Line chart
print("\nTEST 2: LINE CHART")
result2 = mapper.map(
    "Show trend of total amount over time",
    ["created_at", "total", "count"],
    [["2026-01-20", "5000", "10"],
     ["2026-01-21", "7500", "15"],
     ["2026-01-22", "6000", "12"]]
)
print(json.dumps(result2, indent=2))
assert result2["chart_type"] == "line"
assert len(result2["data"]) == 3

# Test 3: KPI
print("\nTEST 3: KPI")
result3 = mapper.map(
    "What is the total count",
    ["total_count"],
    [["150"]]
)
print(json.dumps(result3, indent=2))
assert result3["chart_type"] == "kpi"
assert result3["value"] == 150

# Test 4: Table
print("\nTEST 4: TABLE")
result4 = mapper.map(
    "Show all customers",
    ["name", "email", "city"],
    [["Alice", "alice@ex.com", "NYC"],
     ["Bob", "bob@ex.com", "LA"]]
)
print(json.dumps(result4, indent=2))
assert result4["chart_type"] == "table"
assert len(result4["data"]) == 2

# Test 5: Invalid - no chart
print("\nTEST 5: INVALID (no chart)")
result5 = mapper.map(
    "Do something",
    ["random_col"],
    []
)
print(json.dumps(result5, indent=2))
assert result5["chart_type"] == "none"

print("\n✅ ALL 5 TESTS PASSED")
