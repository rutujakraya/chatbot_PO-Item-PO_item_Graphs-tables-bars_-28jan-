#!/usr/bin/env python3
"""Test the greeting detection fix."""

from agent_planner import PlannerAgent

planner = PlannerAgent()

# Test cases
test_cases = [
    # Original issue
    ("helo", "greeting"),
    
    # Various greeting misspellings with repeated letters
    ("hi", "greeting"),
    ("hii", "greeting"),
    ("hiiii", "greeting"),
    ("hiiiii", "greeting"),
    
    ("hey", "greeting"),
    ("heyy", "greeting"),
    ("heyyyy", "greeting"),
    
    ("hello", "greeting"),
    ("helllo", "greeting"),
    ("helllllo", "greeting"),
    ("helo", "greeting"),
    ("helllo", "greeting"),
    
    # Missing letters / misspellings
    ("hlo", "greeting"),
    ("hllo", "greeting"),
    
    # Original examples from user
    ("heyyyym", "greeting"),  # extra m at end
    ("hhhhey", "greeting"),
    ("heeeeey", "greeting"),
    ("hhhhelo", "greeting"),
    ("heeeelo", "greeting"),
    ("heollo", "greeting"),
    
    # Correct spellings
    ("hello", "greeting"),
    ("hi", "greeting"),
    ("hey", "greeting"),
    
    # Non-greetings (should return None or other type)
    ("how many items", "not-greeting"),
    ("what is the total", "not-greeting"),
    ("list all purchase orders", "not-greeting"),
]

print("Testing greeting detection:")
print("-" * 70)

passed = 0
failed = 0

for text, expected in test_cases:
    result = planner.detect_greeting_or_goodbye(text)
    
    if expected == "greeting":
        success = result == "greeting"
    elif expected == "not-greeting":
        success = result is None or result not in ["greeting", "goodbye", "thanks"]
    else:
        success = result == expected
    
    status = "✓ PASS" if success else "✗ FAIL"
    if success:
        passed += 1
    else:
        failed += 1
    
    print(f"{status} | Input: '{text:20s}' | Expected: {expected:15s} | Got: {str(result):15s}")

print("-" * 70)
print(f"Results: {passed} passed, {failed} failed out of {len(test_cases)} tests")
