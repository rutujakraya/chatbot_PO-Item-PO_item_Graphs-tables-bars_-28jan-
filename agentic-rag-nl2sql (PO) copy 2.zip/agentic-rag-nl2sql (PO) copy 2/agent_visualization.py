try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False

import json
import base64
from io import StringIO
import os
from dotenv import load_dotenv

load_dotenv()


class VisualizationAgent:
    """
    Enterprise-Grade Visualization Agent
    
    Handles:
    1) Automatic table rendering for multi-row/multi-column data
    2) Chart generation when user explicitly requests visuals
    3) DataFrame conversion from SQL results
    4) Clean, professional formatting
    
    IMPORTANT:
    - ONLY generate charts when user explicitly asks (keywords: draw, chart, graph, visualize, plot)
    - ALWAYS use real database data (NO fabrication)
    - Tables shown automatically for tabular data
    - NO visuals for greetings, identity, or single values
    
    NOTE: Requires pandas and plotly/matplotlib for full functionality.
    If not installed, returns plain text results gracefully.
    """
    
    def __init__(self):
        self.debug_mode = os.getenv("DEBUG_MODE", "False").lower() == "true"
        self.has_pandas = HAS_PANDAS
        self.chart_library = self._detect_chart_library()
    
    def _detect_chart_library(self) -> str:
        """Detect which chart library is available."""
        if not HAS_PANDAS:
            return None
        
        try:
            import plotly.express
            return "plotly"
        except ImportError:
            try:
                import matplotlib.pyplot
                return "matplotlib"
            except ImportError:
                return None
    
    def should_generate_chart(self, user_query: str) -> bool:
        """
        Determine if user explicitly asked for a chart/visualization.
        
        Keywords that trigger chart generation:
        - draw, chart, graph, visualize, plot, bar, line, pie, histogram
        """
        q = user_query.lower()
        chart_keywords = [
            "draw ", "show chart", "show graph", "bar chart", "line chart",
            "pie chart", "histogram", "graph of", "visualize", "plot",
            "chart of", "graph "
        ]
        
        return any(keyword in q for keyword in chart_keywords)
    
    def convert_to_dataframe(self, result: dict):
        """
        Convert SQL result dict to pandas DataFrame.
        
        Args:
            result: Dict with 'columns' and 'rows' keys
            
        Returns:
            pandas DataFrame or None if pandas not available
        """
        if not HAS_PANDAS:
            return None
        
        columns = result.get("columns", [])
        rows = result.get("rows", [])
        
        if not columns or not rows:
            return None
        
        return pd.DataFrame(rows, columns=columns)
    
    def generate_table_html(self, df: pd.DataFrame, max_rows: int = 20) -> str:
        """
        Generate clean HTML table from DataFrame.
        
        Args:
            df: pandas DataFrame
            max_rows: Maximum rows to display
            
        Returns:
            HTML string
        """
        if df is None or len(df) == 0:
            return None
        
        # Limit rows
        display_df = df.head(max_rows)
        
        # Generate HTML table
        html = display_df.to_html(index=False, classes="data-table")
        
        # Add overflow indicator
        if len(df) > max_rows:
            html += f"<p><em>... and {len(df) - max_rows} more rows</em></p>"
        
        # Add CSS styling
        styled_html = f"""
<style>
.data-table {{
    border-collapse: collapse;
    width: 100%;
    font-family: 'Segoe UI', sans-serif;
    font-size: 13px;
}}
.data-table th {{
    background-color: #f0f0f0;
    padding: 10px;
    text-align: left;
    border-bottom: 2px solid #ddd;
    font-weight: 600;
}}
.data-table td {{
    padding: 8px;
    border-bottom: 1px solid #ddd;
}}
.data-table tr:hover {{
    background-color: #f5f5f5;
}}
</style>
{html}
"""
        return styled_html
    
    def generate_chart(self, df: pd.DataFrame, user_query: str) -> str:
        """
        Generate chart from DataFrame based on user query.
        
        Uses detected chart library (plotly or matplotlib).
        
        Args:
            df: pandas DataFrame with data
            user_query: User's original question (for title inference)
            
        Returns:
            HTML string with embedded chart, or None if unable to generate
        """
        if df is None or len(df) == 0:
            return None
        
        if self.chart_library == "plotly":
            return self._generate_plotly_chart(df, user_query)
        elif self.chart_library == "matplotlib":
            return self._generate_matplotlib_chart(df, user_query)
        else:
            return None
    
    def _generate_plotly_chart(self, df: pd.DataFrame, user_query: str) -> str:
        """
        Generate interactive chart using Plotly.
        
        Automatically infers chart type based on data shape and user query.
        """
        try:
            import plotly.express as px
            import plotly.graph_objects as go
        except ImportError:
            return None
        
        # Infer chart type and axis mapping from query and data
        q = user_query.lower()
        
        # Determine appropriate chart type
        if len(df) <= 1:
            # Single row → no chart needed
            return None
        
        # For multi-row data, default to bar chart
        # Check if data looks like time series
        if any(col.lower() in ['date', 'created_at', 'updated_at', 'timestamp'] for col in df.columns):
            chart_type = "line"
        else:
            chart_type = "bar"
        
        # Detect if "pie" is requested
        if "pie" in q:
            chart_type = "pie"
        elif "line" in q:
            chart_type = "line"
        elif "histogram" in q or "distribution" in q:
            chart_type = "histogram"
        
        try:
            # Auto-select numeric and categorical columns
            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
            categorical_cols = df.select_dtypes(include=['object', 'string']).columns.tolist()
            
            if not numeric_cols:
                # No numeric data, can't chart
                return None
            
            # Generate chart based on type
            title = self._infer_chart_title(user_query)
            
            if chart_type == "pie" and categorical_cols and numeric_cols:
                x_col = categorical_cols[0]
                y_col = numeric_cols[0]
                fig = px.pie(
                    df,
                    names=x_col,
                    values=y_col,
                    title=title,
                    template="plotly_white"
                )
            elif chart_type == "line" and categorical_cols and numeric_cols:
                x_col = categorical_cols[0]
                y_col = numeric_cols[0]
                fig = px.line(
                    df,
                    x=x_col,
                    y=y_col,
                    title=title,
                    template="plotly_white",
                    markers=True
                )
            else:  # bar
                x_col = categorical_cols[0] if categorical_cols else numeric_cols[0]
                y_col = numeric_cols[0] if len(numeric_cols) > 1 else numeric_cols[0]
                
                fig = px.bar(
                    df,
                    x=x_col,
                    y=y_col,
                    title=title,
                    template="plotly_white"
                )
            
            # Return HTML
            return fig.to_html(include_plotlyjs='cdn', config={'responsive': True})
        
        except Exception as e:
            if self.debug_mode:
                print(f"[Plotly Chart Generation Error] {str(e)}")
            return None
    
    def _generate_matplotlib_chart(self, df: pd.DataFrame, user_query: str) -> str:
        """
        Generate static chart using Matplotlib (fallback if Plotly unavailable).
        """
        try:
            import matplotlib.pyplot as plt
            from io import BytesIO
        except ImportError:
            return None
        
        try:
            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
            categorical_cols = df.select_dtypes(include=['object', 'string']).columns.tolist()
            
            if not numeric_cols:
                return None
            
            fig, ax = plt.subplots(figsize=(10, 6))
            
            x_col = categorical_cols[0] if categorical_cols else numeric_cols[0]
            y_col = numeric_cols[0] if len(numeric_cols) > 1 else numeric_cols[0]
            
            ax.bar(df[x_col], df[y_col])
            ax.set_title(self._infer_chart_title(user_query), fontsize=14, fontweight='bold')
            ax.set_xlabel(x_col, fontsize=12)
            ax.set_ylabel(y_col, fontsize=12)
            plt.xticks(rotation=45, ha='right')
            plt.tight_layout()
            
            # Convert to base64 image
            buf = BytesIO()
            plt.savefig(buf, format='png', dpi=100)
            buf.seek(0)
            img_base64 = base64.b64encode(buf.read()).decode('utf-8')
            plt.close()
            
            html = f'<img src="data:image/png;base64,{img_base64}" style="max-width: 100%; height: auto;">'
            return html
        
        except Exception as e:
            if self.debug_mode:
                print(f"[Matplotlib Chart Generation Error] {str(e)}")
            return None
    
    def _infer_chart_title(self, user_query: str) -> str:
        """
        Infer a sensible chart title from user query.
        """
        # Remove common prefix/suffix words
        words = user_query.lower().split()
        title_words = [w for w in words if w not in [
            'show', 'draw', 'chart', 'of', 'a', 'the', 'please',
            'graph', 'visualize', 'plot', 'bar', 'line', 'pie'
        ]]
        
        title = " ".join(title_words).title()
        
        # Fallback if too short
        if len(title) < 3:
            title = "Data Visualization"
        
        return title
    
    def should_render_table(self, num_rows: int, num_cols: int) -> bool:
        """
        Determine if table should be rendered.
        
        Rules:
        - YES table if multi-row AND multi-column (independent of charts)
        - NO table if single row or single column
        
        NOTE: Chart vs. table selection is handled in orchestrator
        (if chart is generated, it suppresses text and this won't be called)
        """
        if num_rows > 1 and num_cols > 1:
            return True
        
        return False
    
    def render_markdown_table(self, df, max_rows: int = 20) -> str:
        """
        Generate Markdown table from DataFrame (alternative to HTML).
        
        Useful if UI prefers plain Markdown.
        """
        if df is None or len(df) == 0:
            return None
        
        display_df = df.head(max_rows)
        
        # Build markdown table manually
        lines = []
        
        # Header
        header = " | ".join(str(col) for col in display_df.columns)
        lines.append(header)
        lines.append(" | ".join(["---"] * len(display_df.columns)))
        
        # Rows
        for _, row in display_df.iterrows():
            row_str = " | ".join(str(val) for val in row)
            lines.append(row_str)
        
        markdown = "\n".join(lines)
        
        if len(df) > max_rows:
            markdown += f"\n\n*... and {len(df) - max_rows} more rows*"
        
        return markdown
