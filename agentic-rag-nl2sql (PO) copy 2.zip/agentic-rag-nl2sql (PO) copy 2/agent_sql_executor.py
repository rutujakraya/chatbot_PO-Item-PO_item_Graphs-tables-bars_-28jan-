import psycopg2
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class SQLExecutorAgent:
    """
    SECURE SQL Executor Agent.
    
    Database connection details are read from environment variables, NOT hardcoded.
    This ensures credentials are never exposed in code or UI.
    """
    
    def __init__(self):
        # Read credentials from environment variables
        self.db_host = os.getenv("DB_HOST", "localhost")
        self.db_port = int(os.getenv("DB_PORT", "5432"))
        self.db_name = os.getenv("DB_NAME", "agentic_rag_db")
        self.db_user = os.getenv("DB_USER", "")
        self.db_password = os.getenv("DB_PASSWORD", "")
        
        if not self.db_user:
            raise ValueError("DB_USER environment variable is not set")
        
        self.conn = None
        self._connect()
    
    def _connect(self):
        """Establish a fresh database connection."""
        try:
            self.conn = psycopg2.connect(
                dbname=self.db_name,
                user=self.db_user,
                password=self.db_password,
                host=self.db_host,
                port=self.db_port
            )
        except psycopg2.OperationalError as e:
            raise ConnectionError(
                f"Failed to connect to database. Check DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD in .env file"
            )
    
    def _ensure_connection(self):
        """Check if connection is alive, reconnect if dead."""
        if self.conn is None:
            print("[SQLExecutorAgent] Connection is None, reconnecting...")
            self._connect()
            return
        
        try:
            # Test the connection with a simple query
            with self.conn.cursor() as cur:
                cur.execute("SELECT 1")
        except psycopg2.Error:
            print("[SQLExecutorAgent] Connection is dead, reconnecting...")
            try:
                self.conn.close()
            except:
                pass
            self._connect()

    def execute(self, sql: str):
        """
        Execute SQL query and return results.
        
        Args:
            sql: SQL SELECT query
            
        Returns:
            dict with columns and rows
        """
        # Ensure connection is healthy before executing
        self._ensure_connection()
        
        try:
            with self.conn.cursor() as cur:
                cur.execute(sql)
                rows = cur.fetchall()
                columns = [desc[0] for desc in cur.description]

            return {
                "columns": columns,
                "rows": rows
            }
        except psycopg2.Error as e:
            # Log the error for debugging
            error_msg = str(e)[:100]
            print(f"[SQLExecutorAgent] Error executing SQL: {error_msg}")
            # Try to reconnect and don't expose database error details to users
            try:
                self.conn.close()
            except:
                pass
            self.conn = None
            raise Exception(f"Database query error: {error_msg}")
