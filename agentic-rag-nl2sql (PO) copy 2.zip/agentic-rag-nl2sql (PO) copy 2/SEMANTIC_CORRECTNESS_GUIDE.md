# SEMANTIC CORRECTNESS FIX — System Architecture

## Overview

This document explains the **semantic correctness fixes** implemented to address systemic issues where SQL is technically correct but semantically incorrect.

**Problem:** 
- SQL executes and returns valid results
- But the **meaning** is wrong (wrong table, wrong aggregation, wrong entity scope)
- Examples: deriving when user expects stored values, returning ranked lists when singular is expected, including non-existent items when DB has NULL

**Solution:**
- Added `agent_semantic_analyzer.py` — analyzes question intent before SQL generation
- Enhanced `agent_sql_generator.py` — uses semantic context to make correct table/aggregation/cardinality choices
- Refactored fallback pattern matching — replaced hardcoded rules with semantic-driven generation

---

## Core Components

### 1. SemanticAnalyzer (agent_semantic_analyzer.py)

Classifies questions across 5 semantic dimensions:

#### Dimension 1: TABLE INTENT
**Question:** Should we query master data (items) or transactional data (po, po_items)?

**Classification:**
- `"master"` — Question is about item properties, attributes, stored values
- `"transactional"` — Question is about orders, purchases, frequency, transactions
- `"mixed"` — Question requires both perspectives

**Patterns (examples):**
```
Master Intent:
- "what items exist"
- "item names"
- "item properties"
- "stored prices"

Transactional Intent:
- "ordered quantity"
- "purchase frequency"
- "how many times ordered"
- "most ordered items"
```

**Rule Applied:**
- **Master → Query ITEMS table only**
  - Do NOT derive from transactions
  - Do NOT exclude items without orders
  
- **Transactional → Query PO/PO_ITEMS, join ITEMS for labels only**
  - Use aggregates (COUNT, SUM)
  - Join ITEMS only for display names

#### Dimension 2: RESULT CARDINALITY
**Question:** Should we return 1 result or multiple results?

**Classification:**
- `"singular"` — User expects top-1, best, most, highest
- `"plural"` — User expects list, all, every item
- `"unknown"` — Unclear from linguistic patterns

**Patterns (examples):**
```
Singular Intent:
- "which item has the highest price"
- "most ordered item"
- "top 3 items"
- "first item"

Plural Intent:
- "list all items"
- "show items"
- "all purchase orders"
- "every transaction"
```

**Rule Applied:**
- **Singular → ORDER BY ... DESC LIMIT 1**
  - Return only 1 row
  - Focus on the "winner"
  
- **Plural → Return full list (with reasonable LIMIT for UI)**
  - No LIMIT 1
  - All matching rows

#### Dimension 3: AGGREGATION TYPE
**Question:** Should we read stored values or compute derived aggregates?

**Classification:**
- `"stored"` — User wants existing column value
- `"derived"` — User wants computed/aggregated value
- `"none"` — No aggregation mentioned

**Patterns (examples):**
```
Stored Value Intent:
- "least purchase price" (column: least_purchase_price)
- "previous purchase price" (column: previous_purchase_price)
- "base price", "landing price", "selling price"
- "stored" properties

Derived Value Intent:
- "calculate average price"
- "based on purchase history"
- "total ordered quantity"
- "from transactions"
```

**Rule Applied:**
- **Stored → SELECT column directly, return NULL if NULL**
  - Do NOT use MIN/MAX/AVG/etc
  - Do NOT fabricate values
  - Return NULL as-is (do not replace with 0 or aggregate)
  
- **Derived → Use aggregation functions (COUNT, SUM, AVG, MIN, MAX)**
  - Base on transactional data
  - Compute across multiple rows

#### Dimension 4: NULL HANDLING
**Question:** How should we treat NULL values?

**Classification:**
- `"preserve"` — NULL is significant; return it unchanged
- `"default"` — Use natural DB behavior
- `"aggregate"` — NULL is handled by aggregation function (COUNT ignores NULL, SUM skips NULL, etc.)

**Patterns (examples):**
```
Preserve NULL Intent:
- "is null", "null", "missing", "not set"
- "where X is null"

Aggregate Intent:
- "count items" (NULL excluded from COUNT(*))
- "sum total" (NULL excluded from SUM)
```

**Rule Applied:**
- **Preserve → Return NULL unchanged**
  - Do NOT replace with 0 or default
  - Do NOT infer missing values
  - Correctness > prettiness
  
- **Aggregate → Let aggregation function handle NULL**
  - COUNT(*) counts rows, COUNT(col) ignores NULL
  - SUM/AVG automatically skip NULL

#### Dimension 5: ENTITY SCOPE
**Question:** Should we include all entities or only referenced/ordered entities?

**Classification:**
- `"all"` — All entities (items in master, even if never ordered)
- `"referenced"` — Only entities that appear in transactions
- `"unknown"` — Not explicitly indicated

**Patterns (examples):**
```
All Entities Intent:
- "all items"
- "complete catalog"
- "full item list"

Referenced Entities Intent:
- "items in purchase orders"
- "ordered items"
- "ordered quantity"
```

**Rule Applied:**
- **All → Query entity table directly (items)**
  - No JOIN to transactional tables
  - Include items even if zero orders
  
- **Referenced → JOIN through transactional table**
  - Only entities that appear in po_items
  - Naturally excludes unordered items

---

## Enhanced SQL Generator

### Changes to agent_sql_generator.py

#### Before:
```python
def generate_sql(self, user_question: str, schema_context: list) -> str:
    # Old: No semantic analysis
    prompt = f"""Generate SQL for: {user_question}
                SCHEMA: {schema_text}"""
    sql = call_llm(prompt)
    return sql
```

#### After:
```python
def generate_sql(self, user_question: str, schema_context: list) -> str:
    # NEW: Analyze semantic intent first
    semantic_context = self.semantic_analyzer.analyze(user_question)
    semantic_rules = self.semantic_analyzer.get_prompt_injection(semantic_context)
    
    prompt = f"""Generate SQL for: {user_question}
                SEMANTIC RULES:
                {semantic_rules}
                
                SCHEMA: {schema_text}"""
    
    sql = call_llm(prompt)
    return sql
```

### Semantic Prompt Injection

The semantic analyzer generates specific prompts like:

```
SEMANTIC RULES FOR THIS QUESTION:
- This question is about MASTER DATA (item properties, attributes, catalog).
  ➡️  Query ITEMS table primarily.
  ➡️  DO NOT derive data from transactions.

- User expects MULTIPLE results (list, all items, show catalog).
  ➡️  Return the full result set (with reasonable LIMIT for UI).

- User is asking for STORED VALUES (existing columns).
  ➡️  Read directly from the column.
  ➡️  DO NOT use MIN/MAX/AVG/etc. unless user explicitly asks.
  ➡️  Return NULL if the column value is NULL.

- User wants ALL entities (complete catalog, even if not ordered).
  ➡️  Query ITEMS table directly.
  ➡️  Do NOT exclude items that have no transactions.
```

The LLM sees these rules **alongside** the schema and generates SQL that respects them.

---

## Semantic Fallback Pattern Matching

### Old Approach (Hardcoded + Keyword-based):
```python
if ("most" in q or "top" in q) and "item" in q and ("order" in q or "frequency" in q):
    # Return "most ordered items" query
    return "SELECT i.name, COUNT(*) FROM po_items..."
```

**Problem:** Per-question hardcoding, not generalizable.

### New Approach (Semantic-driven):
```python
def _generate_transactional_query(self, q, semantic_context, recommendations):
    """
    Generates transactional queries based on semantic signals,
    not keyword matching.
    """
    if semantic_context["table_intent"] == "transactional" and \
       "most" in semantic_context["matched_patterns"]:
        # Apply SINGULAR limit if user expects top-1
        limit = "LIMIT 1;" if recommendations["singular_limit"] else "LIMIT 20;"
        
        return f"SELECT i.name, COUNT(*) FROM po_items poi " \
               f"JOIN items i ON poi.item_id = i.id " \
               f"WHERE ... GROUP BY i.id, i.name " \
               f"ORDER BY COUNT(*) DESC {limit}"
```

**Benefit:** One general rule handles many variations:
- "most ordered items"
- "top item by frequency"
- "which item is ordered most"
- "most frequently ordered"

All generate semantically correct SQL because the logic is rule-based, not keyword-based.

---

## Examples: How Semantic Rules Fix Issues

### Example 1: Master vs Transactional

**User Question:** "Show item prices"

#### Old behavior (broken):
```
Hardcoded pattern: "list" + "item" + "price"
→ Queries po_items (transactional)
→ Returns price snapshots (item_name, per_unit_rate from individual orders)
❌ User expected master price data (base_price, selling_price, mrp)
```

#### New behavior (fixed):
```
Semantic Analysis:
- table_intent = "master" (properties, attributes, catalog)
- aggregation_type = "stored" (prices exist as columns)

Result:
→ Queries items table (master)
→ Returns base_price, selling_price, mrp (stored columns)
✓ Semantically correct
```

### Example 2: Stored vs Derived

**User Question:** "What is the least purchase price for item X?"

#### Old behavior (broken):
```
Hardcoded pattern: "least" + "purchase" + "price"
→ Uses MIN(per_unit_rate) FROM po_items
→ Recomputes from transactions
❌ User expected the stored column: least_purchase_price
```

#### New behavior (fixed):
```
Semantic Analysis:
- aggregation_type = "stored" (least_purchase_price is a column)
- null_handling = "preserve" (return NULL if not set)

Result:
→ Queries items table, SELECT least_purchase_price
→ Returns exact value or NULL
✓ Semantically correct, matches stored data
```

### Example 3: Singular vs Plural

**User Question:** "Most ordered item"

#### Old behavior (ambiguous):
```
Hardcoded pattern: "most" + "order" + "item"
→ Always returns TOP 20 items
❌ User expected top-1 item
```

#### New behavior (fixed):
```
Semantic Analysis:
- result_cardinality = "singular" (most → top-1)

Result:
→ ORDER BY COUNT(*) DESC LIMIT 1
→ Returns only the single most-ordered item
✓ Semantically correct cardinality
```

### Example 4: Entity Scope

**User Question:** "List all items"

#### Old behavior (broken):
```
Hardcoded pattern: "list" + "item"
→ Queries po_items (only ordered items)
→ Excludes items with no purchase history
❌ User expected complete item catalog
```

#### New behavior (fixed):
```
Semantic Analysis:
- table_intent = "master"
- entity_scope = "all" (all items, complete catalog)

Result:
→ Queries items table directly
→ No JOIN to po_items (which would exclude unordered items)
→ Returns ALL items
✓ Semantically correct scope
```

### Example 5: NULL Preservation

**User Question:** "What is the previous purchase price for item Y?"

#### Old behavior (broken):
```
Hardcoded pattern: "previous" + "purchase" + "price"
→ Queries WHERE previous_purchase_price IS NOT NULL
→ Excludes items that have no previous purchase history
→ Returns MIN() or derived value if missing
❌ User expected stored column or NULL (no previous purchase)
```

#### New behavior (fixed):
```
Semantic Analysis:
- aggregation_type = "stored" (previous_purchase_price is a column)
- null_handling = "preserve" (NULL is significant)

Result:
→ SELECT previous_purchase_price (no WHERE filter on IS NOT NULL)
→ Returns exact value or NULL
→ NULL means "this item has no previous purchase price"
✓ Semantically correct, preserves NULL meaning
```

---

## How to Extend for Future Questions

### Adding New Semantic Patterns

Edit `agent_semantic_analyzer.py`:

```python
class SemanticAnalyzer:
    # Add new patterns here
    NEW_PATTERN_LIST = [
        r'\b(pattern1|pattern2|pattern3)\b',
        r'\bregex\s+pattern\b',
    ]
    
    def __init__(self):
        self.compiled_patterns = self._compile_patterns()
        # Recompile includes new patterns automatically
```

### Adding New Fallback Query Types

Edit `agent_sql_generator.py`, add to `_generate_master_data_query()` or `_generate_transactional_query()`:

```python
def _generate_master_data_query(self, q, semantic_context, recommendations):
    # ... existing code ...
    
    # NEW: Handle "item classification" queries
    if "classification" in q and "item" in q:
        return (
            "SELECT name, code_sku, item_classification FROM items "
            "WHERE (is_deleted IS NULL OR is_deleted = false) "
            "ORDER BY created_at DESC LIMIT 20;"
        )
    
    return ""
```

The semantic context automatically determines:
- Whether to use master or transactional table
- Whether to apply singular limit
- How to handle NULL values
- Whether to include all entities

**No per-question conditionals needed** — semantic rules handle variation automatically.

---

## Semantic Rules Summary

### Rule 1: TABLE SELECTION (MASTER vs TRANSACTIONAL)

| User Intent | Primary Table | Allowed Joins | Notes |
|-------------|-------------|----------|-------|
| Item properties, attributes, catalog | items | None | Do NOT query po_items for master data |
| Quantities, frequency, usage, transactions | po, po_items | items (for labels) | Join items only for display, not aggregation |
| Both | Both | items | Start with primary table, join carefully |

### Rule 2: AGGREGATION (STORED vs DERIVED)

| User Intent | Action | Example |
|------------|--------|---------|
| Column exists and user asks for it | SELECT directly | "least purchase price" → SELECT least_purchase_price |
| Column doesn't exist, compute needed | Use aggregation | "average price" → SELECT AVG(per_unit_rate) |
| Unsure | Ask (prefer stored) | If column exists, read it; else compute |

### Rule 3: CARDINALITY (SINGULAR vs PLURAL)

| User Intent | Result | Example |
|------------|--------|---------|
| Top-1, best, highest, most | LIMIT 1 | "most ordered item" → LIMIT 1 |
| List, all, show, every | No LIMIT (or LIMIT 20) | "list items" → LIMIT 20 |

### Rule 4: NULL HANDLING

| Scenario | Action |
|----------|--------|
| User asks about NULL explicitly | Return NULL unchanged |
| Column is nullable and has NULL values | Return NULL (do not default to 0) |
| Using aggregation (COUNT, SUM) | Let function handle NULL (COUNT(*) counts rows, COUNT(col) excludes NULL) |

### Rule 5: ENTITY SCOPE

| User Intent | Scope | Implementation |
|------------|-------|-----------------|
| All items in catalog | Include all items | SELECT FROM items (no transactional join) |
| Only items that were ordered | Restrict to referenced | JOIN po_items or use IN subquery |
| Not specified | Assume all | Query master table directly |

---

## Testing & Validation

### Key Test Cases

```python
# Test 1: Master vs Transactional
assert analyze("what items exist")["table_intent"] == "master"
assert analyze("most ordered items")["table_intent"] == "transactional"

# Test 2: Singular vs Plural
assert analyze("which item is most ordered")["result_cardinality"] == "singular"
assert analyze("list all items")["result_cardinality"] == "plural"

# Test 3: Stored vs Derived
assert analyze("least purchase price")["aggregation_type"] == "stored"
assert analyze("calculate average price")["aggregation_type"] == "derived"

# Test 4: NULL handling
assert analyze("where price is null")["null_handling"] == "preserve"
assert analyze("count items")["null_handling"] == "aggregate"

# Test 5: Entity scope
assert analyze("all items")["entity_scope"] == "all"
assert analyze("items in purchase orders")["entity_scope"] == "referenced"
```

---

## Future Improvements

1. **Confidence Scoring** — Rank semantic classifications by confidence, use fallback if low
2. **Multi-intent Questions** — Handle questions that span multiple semantic dimensions
3. **User Feedback Loop** — Learn from corrections (user rejects wrong answer, corrects intent)
4. **Schema-aware Patterns** — Adapt patterns based on actual columns (column name → intent inference)
5. **Context Memory** — Track previous questions to infer intent in follow-ups ("And the total?" after "Most ordered item")

---

## Summary

The semantic correctness fix addresses systemic issues by:

✅ **Analyzing intent BEFORE SQL generation** (not guessing from keywords)
✅ **Applying general, rule-based logic** (not per-question hardcoding)
✅ **Respecting semantic dimensions** (table, cardinality, aggregation, NULL, scope)
✅ **Making LLM aware of semantic rules** (injecting rules into prompt)
✅ **Fallback that's guided by semantics** (not random keyword matching)
✅ **Future-proof design** (new questions reuse existing rules)

Result: **Factually correct answers** (not just executable SQL).
