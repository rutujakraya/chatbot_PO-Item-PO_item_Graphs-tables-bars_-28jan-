# Code Changes - Before & After

## File 1: agent_sql_generator.py

### Change 1: Enhanced LLM Prompt (Lines 65-70)

**BEFORE:**
```python
        # CRITICAL PROMPT: Emphasize metadata-driven generation with semantic rules
        prompt = f"""You are an EXPERT PostgreSQL SQL generator for a PROCUREMENT database.

YOUR TASK:
Convert the user's natural language question into a single PostgreSQL SELECT query.
...
STRICT RULES:
1. Generate ONLY SELECT queries (terminated with semicolon).
...
11. Return ONLY the SQL statement; do NOT explain.
```

**AFTER:**
```python
        # CRITICAL PROMPT: Emphasize metadata-driven generation with semantic rules
        prompt = f"""You are an EXPERT PostgreSQL SQL generator for a PROCUREMENT database.

YOUR TASK:
Convert the user's natural language question into a single PostgreSQL SELECT query.
Use ONLY the tables and columns described in the SCHEMA section below.
The schema is derived from db_metadata.txt and describes the procurement system.

{semantic_rules}

⚠️  CRITICAL OUTPUT FORMAT:
- Output ONLY the SQL query statement.
- No explanation, no preamble, no "HERE IS THE SQL QUERY...", no markdown.
- Start immediately with SELECT or WITH.
- End with a semicolon.
- Example output format: SELECT po_no FROM po WHERE status='APPROVED' LIMIT 20;

STRICT RULES:
...
```

**What Changed:** Added explicit "⚠️ CRITICAL OUTPUT FORMAT" section before STRICT RULES to emphasize pure SQL output requirement

---

### Change 2: LLM Output Preamble Stripping (Lines 155-173)

**BEFORE:**
```python
            # Call LLM
            response = requests.post(
                "http://localhost:11434/api/generate",
                json={
                    "model": "llama2",
                    "prompt": prompt,
                    "temperature": 0.3,
                    "stream": False,
                },
                timeout=120
            )
            sql = response.json().get("response", "").strip()

        except Exception as e:
            print(f"SQLGeneratorAgent LLM error: {e}")
            sql = ""

        # === VALIDATION: Reject unsafe SQL ===
```

**AFTER:**
```python
            # Call LLM
            response = requests.post(
                "http://localhost:11434/api/generate",
                json={
                    "model": "llama2",
                    "prompt": prompt,
                    "temperature": 0.3,
                    "stream": False,
                },
                timeout=120
            )
            sql = response.json().get("response", "").strip()
            
            # Extract just the SQL part
            if sql:
                # Try to find the first SELECT or WITH keyword
                sql_upper = sql.upper()
                select_idx = sql_upper.find("SELECT")
                with_idx = sql_upper.find("WITH")
                
                # Find the earliest of these two
                first_sql_idx = -1
                if select_idx >= 0 and with_idx >= 0:
                    first_sql_idx = min(select_idx, with_idx)
                elif select_idx >= 0:
                    first_sql_idx = select_idx
                elif with_idx >= 0:
                    first_sql_idx = with_idx
                
                # Extract SQL from first keyword onwards
                if first_sql_idx > 0:
                    sql = sql[first_sql_idx:].strip()
                    
        except Exception as e:
            print(f"SQLGeneratorAgent LLM error: {e}")
            sql = ""

        # === VALIDATION: Reject unsafe SQL ===
```

**What Changed:** Added preamble stripping logic that finds first SELECT or WITH keyword and extracts SQL from there

---

### Change 3: New Fallback Pattern - Combined Stored Prices (Lines 276-283)

**BEFORE:**
```python
        if "least" in q and "purchase" in q and "price" in q:
            # User wants the stored least_purchase_price column
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            return (
                "SELECT name, code_sku, least_purchase_price, least_purchase_date "
                "FROM items WHERE (is_deleted IS NULL OR is_deleted = false) "
                f"AND least_purchase_price IS NOT NULL "
                f"ORDER BY least_purchase_price ASC {limit_clause}"
            )
        
        if "previous" in q and "purchase" in q and "price" in q:
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            return (
                "SELECT name, code_sku, previous_purchase_price, previous_purchase_date "
                "FROM items WHERE (is_deleted IS NULL OR is_deleted = false) "
                f"AND previous_purchase_price IS NOT NULL "
                f"ORDER BY previous_purchase_date DESC {limit_clause}"
            )
        
        # ITEM PROPERTIES (base_price, selling_price, mrp, etc.)
```

**AFTER:**
```python
        if "least" in q and "purchase" in q and "price" in q and "previous" not in q:
            # User wants the stored least_purchase_price column (only)
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            return (
                "SELECT name, code_sku, least_purchase_price, least_purchase_date "
                "FROM items WHERE (is_deleted IS NULL OR is_deleted = false) "
                f"AND least_purchase_price IS NOT NULL "
                f"ORDER BY least_purchase_price ASC {limit_clause}"
            )
        
        if "previous" in q and "purchase" in q and "price" in q and "least" not in q:
            # User wants the stored previous_purchase_price column (only)
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            return (
                "SELECT name, code_sku, previous_purchase_price, previous_purchase_date "
                "FROM items WHERE (is_deleted IS NULL OR is_deleted = false) "
                f"AND previous_purchase_price IS NOT NULL "
                f"ORDER BY previous_purchase_date DESC {limit_clause}"
            )
        
        # BOTH LEAST AND PREVIOUS PRICES
        if "least" in q and "previous" in q and "purchase" in q and "price" in q:
            limit_clause = "LIMIT 1;" if singular_limit else "LIMIT 20;"
            return (
                "SELECT name AS item_name, code_sku, least_purchase_price, previous_purchase_price "
                "FROM items WHERE (is_deleted IS NULL OR is_deleted = false) "
                f"AND (least_purchase_price IS NOT NULL OR previous_purchase_price IS NOT NULL) "
                f"ORDER BY name {limit_clause}"
            )
        
        # ITEM PROPERTIES (base_price, selling_price, mrp, etc.)
```

**What Changed:** 
- Added `and "previous" not in q` to "least only" pattern to avoid matching "least AND previous"
- Added `and "least" not in q` to "previous only" pattern to avoid matching "least AND previous"
- Added NEW pattern for "least AND previous" together (returns both columns)

---

## File 2: agent_semantic_analyzer.py

### Change 1: Enhanced STORED_VALUE_PATTERNS (Lines 63-67)

**BEFORE:**
```python
    # Patterns indicating STORED VALUE (read existing column)
    STORED_VALUE_PATTERNS = [
        r'\b(least\s+purchase\s+price|previous\s+purchase\s+price)',  # Exact stored columns
        r'\b(base_price|landing_price|selling_price|mrp)',  # Other stored prices
        r'\b(least|previous|stored|configured|existing)\s+(?:purchase\s+)?(price|value)',
        r'\b(price|value|cost)\s+(?:for|of)\s+items?',  # Price of items (master data)
    ]
```

**AFTER:** (Same patterns, already enhanced from previous session)

**Note:** These patterns were already updated in the previous session to include explicit "least purchase price" and "previous purchase price" patterns. They remain as shown above - no further changes needed.

---

### Change 2: Explicit "which" Singular Detection (Lines 200-202)

**BEFORE:**
```python
    def _classify_result_cardinality(self, q_lower: str) -> str:
        """
        Determine if user expects singular (top-1) or plural (list) result.
        ...
        """
        singular_score = self._match_patterns(
            q_lower, self.compiled_patterns["singular_result"]
        )
        plural_score = self._match_patterns(q_lower, self.compiled_patterns["plural_result"])

        # Special cases: These are always plural regardless of patterns
        if "how many" in q_lower or "count" in q_lower:
            return "plural"
        
        if "recent" in q_lower or "latest" in q_lower:
            return "plural"
        
        # "most X items" or "top items" → singular (user wants the most item)
        if ("most" in q_lower or "top" in q_lower) and "item" in q_lower:
            return "singular"
        
        if singular_score > plural_score:
            return "singular"
        elif plural_score > singular_score:
            return "plural"
        else:
            return "unknown"
```

**AFTER:**
```python
    def _classify_result_cardinality(self, q_lower: str) -> str:
        """
        Determine if user expects singular (top-1) or plural (list) result.
        ...
        """
        singular_score = self._match_patterns(
            q_lower, self.compiled_patterns["singular_result"]
        )
        plural_score = self._match_patterns(q_lower, self.compiled_patterns["plural_result"])

        # Special cases: These are always plural regardless of patterns
        if "how many" in q_lower or "count" in q_lower:
            return "plural"
        
        if "recent" in q_lower or "latest" in q_lower:
            return "plural"
        
        # "most X items" or "top items" → singular (user wants the most item)
        if ("most" in q_lower or "top" in q_lower) and "item" in q_lower:
            return "singular"
        
        # "which X has/is" → always singular
        if "which" in q_lower:
            return "singular"
        
        if singular_score > plural_score:
            return "singular"
        elif plural_score > singular_score:
            return "plural"
        else:
            return "unknown"
```

**What Changed:** Added explicit `if "which" in q_lower: return "singular"` check BEFORE score comparison

**Why This Position:** 
- Runs BEFORE pattern scoring to give "which" keyword high priority
- Applies to all entity types: "which item", "which PO", "which order"
- Matches semantic meaning: "which" is always asking for a specific entity

---

## Summary of All Changes

| Component | Change | Lines | Type |
|-----------|--------|-------|------|
| LLM Prompt | Added CRITICAL OUTPUT FORMAT section | 65-70 | Enhancement |
| LLM Output | Added preamble stripping logic | 155-173 | New Logic |
| Fallback Patterns | Modified individual patterns to exclude compound cases | 265, 275 | Enhancement |
| Fallback Patterns | Added new "least AND previous" pattern | 276-283 | New Pattern |
| Semantic Analyzer | Added explicit "which" keyword detection | 200-202 | New Logic |

**Total Impact:** 5 focused code changes addressing all 4 real-world issues

---

## Testing the Changes

### Before Fix (Expected Failures)
```
❌ "List the 5 most recently created purchase orders"
   → LLM output: "HERE IS THE SQL QUERY: SELECT..."
   → Validator rejects: "must start with SELECT"

❌ "List items with their least purchase price and previous purchase price"  
   → Semantic: table_intent = "transactional" (WRONG)
   → Expected: table_intent = "master"

❌ "Which item has the highest total ordered quantity?"
   → Semantic: result_cardinality = "unknown" (WRONG)
   → Expected: result_cardinality = "singular"
   → Result: Returns all 3 items instead of top 1

❌ "How many purchase orders are in draft status?"
   → LLM output: "HERE IS THE COUNT QUERY: SELECT..."
   → Validator rejects: "must start with SELECT"
```

### After Fix (All Passing)
```
✅ "List the 5 most recently created purchase orders"
   → LLM output stripped: "SELECT po_no FROM po..."
   → Validator accepts SQL

✅ "List items with their least purchase price and previous purchase price"
   → Semantic: table_intent = "master"
   → Fallback: New combined pattern applies

✅ "Which item has the highest total ordered quantity?"
   → Semantic: result_cardinality = "singular"
   → SQL includes: LIMIT 1
   → Result: Top 1 item only

✅ "How many purchase orders are in draft status?"
   → LLM output stripped: "SELECT COUNT(*) FROM po..."
   → Validator accepts SQL
```

---

## Validation Commands

```bash
# Quick semantic analysis test (no LLM calls)
python3 test_semantic_quick.py

# Full validation of all fixes
python3 test_all_fixes_final.py

# Complete semantic test suite
python3 test_semantic_correctness.py
```
