# Agentic RAG — Demo UI

This repository contains a minimal FastAPI backend and a single-file frontend demonstrating an "agentic" RAG system built around your existing `AgentOrchestrator`.

Quick start

1. Create and activate a virtualenv (optional but recommended):

```bash
python3 -m venv .venv
source .venv/bin/activate
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run the FastAPI server (from the repo root):

```bash
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```

4. Open `http://localhost:8000` in your browser. Ask questions in the chat box. Each response includes collapsible panels for the generated SQL, retrieved context, and a short agent flow summary.

Notes
- The backend calls your existing `AgentOrchestrator` (imported from `agent_orchestrator`).
- The demo extracts the generated SQL from the final formatted answer (the formatter includes the SQL). If you prefer a more structured contract, consider returning structured objects from `AgentOrchestrator.format()`.
