#!/usr/bin/env python3
"""
Quick test of semantic analysis and fallback patterns for 4 failing cases.
"""

import sys
sys.path.insert(0, '/Users/rutujadhage/agentic-rag-nl2sql (PO)')

from agent_semantic_analyzer import SemanticAnalyzer

# Initialize analyzer
analyzer = SemanticAnalyzer()

test_questions = [
    ("List the 5 most recently created purchase orders", 
     {"table_intent": "transactional", "result_cardinality": "plural"}),
    
    ("List items with their least purchase price and previous purchase price",
     {"table_intent": "master", "aggregation_type": "stored"}),
    
    ("Which item has the highest total ordered quantity?",
     {"result_cardinality": "singular"}),
    
    ("How many purchase orders are in draft status?",
     {"table_intent": "transactional", "result_cardinality": "plural"}),
]

print("=" * 80)
print("SEMANTIC ANALYSIS FOR 4 FAILING CASES")
print("=" * 80)

for question, expected_attrs in test_questions:
    print(f"\n❓ Question: {question}")
    result = analyzer.analyze(question)
    print(f"   Semantic Classification:")
    print(f"   ├─ table_intent: {result['table_intent']}")
    print(f"   ├─ result_cardinality: {result['result_cardinality']}")
    print(f"   ├─ aggregation_type: {result['aggregation_type']}")
    print(f"   ├─ null_handling: {result['null_handling']}")
    print(f"   └─ entity_scope: {result['entity_scope']}")
    
    # Check expected attributes
    matches = True
    for key, expected_value in expected_attrs.items():
        actual_value = result[key]
        match = "✓" if actual_value == expected_value else "✗"
        print(f"   {match} {key}: expected='{expected_value}', actual='{actual_value}'")
        if actual_value != expected_value:
            matches = False
    
    if matches:
        print(f"   ✓ PASS: Semantic classification correct")
    else:
        print(f"   ✗ FAIL: Semantic classification mismatch")

print("\n" + "=" * 80)
print("Semantic analysis complete.")
