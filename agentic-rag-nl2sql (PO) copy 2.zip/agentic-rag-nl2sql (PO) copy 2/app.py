from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os
from dotenv import load_dotenv

from agent_orchestrator import AgentOrchestrator

load_dotenv()

app = FastAPI(title="Agentic RAG Demo")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

orchestrator = AgentOrchestrator()


class QueryRequest(BaseModel):
    question: str


@app.post("/query")
async def query(req: QueryRequest):
    """
    Accepts a question, runs the AgentOrchestrator, and returns structured JSON.
    
    SECURITY:
    - Sensitive information is NEVER exposed
    - SQL is NOT shown in UI (logged to terminal only)
    - Raw data is NOT shown (formatted to natural language)
    - Table/column names are NOT shown
    
    Returns: { question, answer, sql, context, agent_flow }
    Note: sql is included in response for development/debugging, but NOT shown in frontend UI
    """
    question = req.question
    try:
        # Run the full orchestrator to get the structured result
        # The orchestrator handles all security checks internally
        res = orchestrator.run(question)

        # Extract components
        answer = res.get("answer", "")
        sql = res.get("sql")  # May be None for general questions or security-blocked requests
        context = res.get("context")
        agent_flow = res.get("agent_flow", [])

        # SECURITY: Sanitize response for UI
        # - SQL is included in response for developer debugging/transparency
        # - But frontend should NOT display it to end users
        # - Answer is always shown (never raw SQL or data)
        
        response_data = {
            "question": question,
            "answer": answer,
            "sql": sql,  # For developer inspection only
            "context": context,  # Metadata chunks (for transparency)
            "agent_flow": agent_flow,  # Step-by-step execution (for debugging)
        }
        
        return response_data

    except Exception as e:
        # Don't expose detailed error messages to users
        print(f"[ERROR] API Exception: {str(e)}")  # Log to backend
        raise HTTPException(
            status_code=500,
            detail="An error occurred processing your request. Please try again."
        )


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy"}


# Serve the demo frontend
app.mount("/", StaticFiles(directory="static", html=True), name="static")

