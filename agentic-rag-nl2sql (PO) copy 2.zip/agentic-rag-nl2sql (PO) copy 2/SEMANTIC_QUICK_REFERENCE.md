# Semantic Correctness Quick Reference

## Common Question Types & Expected Behavior

### Master Data Questions

| Question | Expected Table | Expected Result | Semantic Rules |
|----------|--------------|-----------------|-----------------|
| "What items exist?" | items | Complete catalog | table=master, scope=all |
| "Show item names" | items | All item names | table=master, scope=all |
| "Item properties" | items | Stored columns (base_price, landing_price, etc.) | table=master, aggregation=stored |
| "List approved items" | items | Items where status='APPROVED' | table=master |
| "Item classification" | items | item_classification column | table=master, aggregation=stored |

### Transactional Questions

| Question | Expected Table | Expected Result | Semantic Rules |
|----------|--------------|-----------------|-----------------|
| "Most ordered items" | po_items + items | Top item by frequency | table=transactional, cardinality=singular |
| "Items in PO-001" | po_items + po | Items in specific order | table=transactional |
| "How many POs?" | po | Count of POs | table=transactional, cardinality=plural |
| "Recent purchase orders" | po | Recent orders | table=transactional, cardinality=plural |
| "Total PO value by status" | po | SUM grouped by status | table=transactional, aggregation=derived |

### Stored Value Questions

| Question | Expected Column | Do NOT Use | Semantic Rules |
|----------|-----------------|-----------|-----------------|
| "Least purchase price" | least_purchase_price | MIN(per_unit_rate) | aggregation=stored |
| "Previous purchase price" | previous_purchase_price | MIN/MAX from history | aggregation=stored |
| "Base price" | base_price | Aggregation | aggregation=stored |
| "Selling price" | selling_price | Aggregation | aggregation=stored |
| "MRP" | mrp | Aggregation | aggregation=stored |

### Derived Value Questions

| Question | How to Compute | Expected Aggregation | Semantic Rules |
|----------|---------------|-------------------|-----------------|
| "Average order value" | SUM(po.total) / COUNT(po) | AVG or SUM+COUNT | aggregation=derived |
| "Total purchase quantity" | SUM(requested_quantity) | SUM | aggregation=derived |
| "Number of orders per item" | COUNT(po_items) per item | COUNT grouped by item | aggregation=derived |

### Singular vs Plural

| Question Pattern | Cardinality | Result Count | Semantic Rules |
|-----------------|-------------|--------------|-----------------|
| "Most X" | Singular | 1 | LIMIT 1 |
| "Top X" | Singular | 1 | LIMIT 1 |
| "Which has highest..." | Singular | 1 | LIMIT 1 |
| "List X" | Plural | Many | LIMIT 20 (or none) |
| "Show all X" | Plural | Many | No LIMIT 1 |
| "Every X" | Plural | Many | No LIMIT 1 |

### NULL Handling

| Question Type | NULL Handling | Example |
|--------------|--------------|---------|
| "What is the value?" | Preserve | "What is previous purchase price?" → Returns NULL if never purchased |
| "Count items" | Aggregate | NULL excluded from COUNT(col) |
| "Sum total" | Aggregate | NULL excluded from SUM |
| "Show NULL values" | Preserve | WHERE column IS NULL |

### Entity Scope

| Question Pattern | Entity Scope | Includes Unordered Items? | Semantic Rules |
|-----------------|------------|-------------------------|-----------------|
| "All items" | all | YES | Query items directly |
| "Complete catalog" | all | YES | No JOIN to po_items |
| "Ordered items" | referenced | NO | JOIN through po_items |
| "Items in POs" | referenced | NO | JOIN through po_items |

---

## Decision Tree for Semantic Analysis

```
User Question
    ↓
1. TABLE INTENT?
    ├─ Item properties, attributes, catalog? → MASTER
    └─ Orders, purchases, frequency? → TRANSACTIONAL
    ↓
2. CARDINALITY?
    ├─ "Most", "Top", "Which has highest"? → SINGULAR
    └─ "List", "Show all", "Every"? → PLURAL
    ↓
3. AGGREGATION?
    ├─ Stored column exists (least_purchase_price, base_price)? → STORED
    └─ Need to compute (calculate, based on history)? → DERIVED
    ↓
4. ENTITY SCOPE?
    ├─ "All items", "Complete catalog"? → ALL
    └─ "Ordered items", "Items in POs"? → REFERENCED
    ↓
5. NULL HANDLING?
    ├─ "Is NULL", "Missing", "Not set"? → PRESERVE
    └─ Aggregation function? → AGGREGATE
    ↓
Generate SQL following semantic rules
```

---

## SQL Generation Patterns by Semantic Intent

### Master Data + Singular + Stored
```sql
SELECT name, code_sku, least_purchase_price, least_purchase_date
FROM items
WHERE (is_deleted IS NULL OR is_deleted = false)
  AND least_purchase_price IS NOT NULL
ORDER BY least_purchase_price ASC LIMIT 1;
```

### Master Data + Plural + Stored
```sql
SELECT name, code_sku, base_price, selling_price, mrp, gst_percent
FROM items
WHERE (is_deleted IS NULL OR is_deleted = false)
ORDER BY created_at DESC LIMIT 20;
```

### Transactional + Singular + Derived
```sql
SELECT i.name, COUNT(*) AS frequency
FROM po_items poi
JOIN items i ON poi.item_id = i.id
WHERE (poi.is_deleted IS NULL OR poi.is_deleted = false)
GROUP BY i.id, i.name
ORDER BY frequency DESC LIMIT 1;
```

### Transactional + Plural + Derived
```sql
SELECT i.name, COUNT(*) AS frequency
FROM po_items poi
JOIN items i ON poi.item_id = i.id
WHERE (poi.is_deleted IS NULL OR poi.is_deleted = false)
GROUP BY i.id, i.name
ORDER BY frequency DESC LIMIT 20;
```

---

## Common Mistakes to Avoid

### ❌ Mistake 1: Deriving Master Data
```sql
-- WRONG: Computing stored value from transactions
SELECT item_id, MIN(per_unit_rate) as least_price
FROM po_items
GROUP BY item_id;

-- CORRECT: Read from stored column
SELECT id, name, least_purchase_price
FROM items;
```

### ❌ Mistake 2: Returning Plural When Singular Expected
```sql
-- WRONG: User asked "most ordered item" but got list of 20
SELECT i.name, COUNT(*) FROM po_items poi
JOIN items i ON poi.item_id = i.id
GROUP BY i.id, i.name
ORDER BY COUNT(*) DESC LIMIT 20;

-- CORRECT: Return only top-1
... LIMIT 1;
```

### ❌ Mistake 3: Excluding Unordered Items
```sql
-- WRONG: User asked "all items" but joining to po_items excludes unordered
SELECT DISTINCT i.name FROM items i
JOIN po_items poi ON i.id = poi.item_id;

-- CORRECT: Query items directly
SELECT name FROM items
WHERE (is_deleted IS NULL OR is_deleted = false);
```

### ❌ Mistake 4: Replacing NULL with 0
```sql
-- WRONG: Hiding NULL values
SELECT COALESCE(previous_purchase_price, 0) FROM items;

-- CORRECT: Preserve NULL meaning
SELECT previous_purchase_price FROM items;
```

### ❌ Mistake 5: Aggregating When User Expects Stored
```sql
-- WRONG: Computing from transactions when column exists
SELECT item_id, AVG(per_unit_rate) as avg_price FROM po_items GROUP BY item_id;

-- CORRECT: Read from master data
SELECT id, name, base_price, landing_price FROM items;
```

---

## Extending for New Questions

### Add new pattern to semantic analyzer:

```python
# agent_semantic_analyzer.py
NEW_MASTER_PATTERNS = [
    r'\b(vendor|supplier|name)\s+of\s+(item|product)',
    r'\b(item\s+)?(vendor|supplier)\b',
]

NEW_TRANSACTIONAL_PATTERNS = [
    r'\b(invoice|payment|delivery)\s+(status|date)',
]

NEW_SINGULAR_PATTERNS = [
    r'\bfirst\s+order\b',
    r'\blast\s+purchase\b',
]
```

### Optional: Add fallback pattern

```python
# agent_sql_generator.py
def _generate_master_data_query(self, q, semantic_context, recommendations):
    # ... existing patterns ...
    
    # NEW PATTERN: Vendor information
    if "vendor" in q and "item" in q:
        return (
            "SELECT i.name, i.code_sku, ... "
            "FROM items i WHERE ..."
        )
```

**That's it!** Semantic rules handle cardinality, NULL handling, scope automatically.

---

## Testing Your Changes

### Quick test:
```python
from agent_semantic_analyzer import SemanticAnalyzer

analyzer = SemanticAnalyzer()

# Test your new question
result = analyzer.analyze("your test question here")

print(f"Table intent: {result['table_intent']}")
print(f"Cardinality: {result['result_cardinality']}")
print(f"Aggregation: {result['aggregation_type']}")
print(f"Entity scope: {result['entity_scope']}")
print(f"NULL handling: {result['null_handling']}")

# Verify expectations
assert result['table_intent'] == 'expected_intent'
assert result['result_cardinality'] == 'expected_cardinality'
```

---

## When to Use Each Semantic Dimension

| Dimension | Use When | Example |
|----------|----------|---------|
| **table_intent** | Deciding primary table (items vs po/po_items) | "What items exist?" → items |
| **result_cardinality** | Deciding LIMIT (1 vs many) | "Most ordered?" → LIMIT 1 |
| **aggregation_type** | Deciding aggregation (stored vs derived) | "Least price?" → Read column |
| **entity_scope** | Deciding JOIN (include all vs only referenced) | "All items?" → Query items directly |
| **null_handling** | Deciding NULL strategy (preserve vs aggregate) | "Previous price?" → Keep NULL |

All interact together to produce semantically correct SQL.
