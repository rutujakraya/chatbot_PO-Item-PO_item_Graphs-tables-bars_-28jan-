const chatEl = document.getElementById('chat');
const form = document.getElementById('askForm');
const input = document.getElementById('question');

// Global chart instances to prevent memory leaks
const chartInstances = {};
let chartCounter = 0;

function addMessage(text, who='system'){
  const wrap = document.createElement('div');
  wrap.className = 'msg ' + (who==='user' ? 'user' : 'system');

  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  // Parse if text is JSON (structured response with visualization)
  try {
    const parsed = JSON.parse(text);
    
    // Handle structured response with optional visualization
    if (parsed.text !== undefined || parsed.visualization !== undefined || parsed.columns !== undefined) {
      // Add text response
      if (parsed.text) {
        const textEl = document.createElement('div');
        textEl.className = 'text-response';
        textEl.innerText = parsed.text;
        bubble.appendChild(textEl);
      }
      
      // Add visualization if present
      if (parsed.visualization && parsed.visualization.chart_type !== 'none') {
        renderVisualization(parsed.visualization, bubble);
      }
      // Add table data if provided directly (fallback for legacy format)
      else if (parsed.columns && parsed.rows) {
        const tableViz = {
          chart_type: 'table',
          columns: parsed.columns,
          data: parsed.rows
        };
        renderVisualization(tableViz, bubble);
      }
    } else {
      // Fallback: treat as plain text
      bubble.innerText = text;
    }
  } catch (e) {
    // Not JSON - treat as plain text
    bubble.innerText = text;
  }
  
  wrap.appendChild(bubble);
  chatEl.appendChild(wrap);
  chatEl.scrollTop = chatEl.scrollHeight;
}

function renderVisualization(viz, container) {
  // Route to appropriate renderer based on chart_type
  if (!viz || !viz.chart_type) return;
  
  switch(viz.chart_type) {
    case 'bar':
      renderBarChart(viz, container);
      break;
    case 'line':
      renderLineChart(viz, container);
      break;
    case 'table':
      renderTable(viz, container);
      break;
    case 'kpi':
      renderKPI(viz, container);
      break;
    default:
      console.warn('Unknown chart type:', viz.chart_type);
  }
}

function renderBarChart(chartData, container) {
  // Render bar chart using Chart.js
  const chartId = 'chart-' + (chartCounter++);
  
  // Title
  if (chartData.title) {
    const title = document.createElement('h4');
    title.className = 'chart-title';
    title.innerText = chartData.title;
    container.appendChild(title);
  }
  
  // Wrapper div for chart container
  const wrapper = document.createElement('div');
  wrapper.style.position = 'relative';
  wrapper.style.width = '100%';
  wrapper.style.maxWidth = '600px';
  wrapper.style.height = '350px';
  wrapper.style.marginBottom = '20px';
  wrapper.style.backgroundColor = 'rgba(51, 65, 85, 0.3)';
  wrapper.style.borderRadius = '8px';
  wrapper.style.overflow = 'hidden';
  
  // Canvas for Chart.js
  const canvas = document.createElement('canvas');
  canvas.id = chartId;
  canvas.style.display = 'block';
  canvas.style.width = '100%';
  canvas.style.height = '100%';
  wrapper.appendChild(canvas);
  container.appendChild(wrapper);
  
  // Initialize chart after canvas is in DOM
  setTimeout(() => {
    const ctx = document.getElementById(chartId).getContext('2d');
    if (!ctx) {
      console.error('Failed to get canvas context for', chartId);
      return;
    }
    
    // Prepare data
    const labels = chartData.data.map(d => d[chartData.x_key] || d.name);
    const values = chartData.data.map(d => parseFloat(d[chartData.y_key] || d.value) || 0);
    
    // Destroy previous chart instance if it exists
    if (chartInstances[chartId]) {
      chartInstances[chartId].destroy();
    }
    
    // Create chart
    try {
      const chart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [{
            label: chartData.y_key || 'Value',
            data: values,
            backgroundColor: 'rgba(75, 192, 192, 0.7)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1,
            borderRadius: 4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: true,
              position: 'top',
              labels: {
                color: '#e6eef8',
                font: { size: 12 }
              }
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                color: '#94a3b8'
              },
              grid: {
                color: 'rgba(255, 255, 255, 0.05)'
              }
            },
            x: {
              ticks: {
                color: '#94a3b8'
              },
              grid: {
                color: 'rgba(255, 255, 255, 0.05)'
              }
            }
          }
        }
      });
      
      chartInstances[chartId] = chart;
      console.log('✅ Bar chart rendered:', chartId);
    } catch (e) {
      console.error('Error rendering bar chart:', e);
    }
  }, 50);
}

function renderLineChart(chartData, container) {
  // Render line chart using Chart.js
  const chartId = 'chart-' + (chartCounter++);
  
  // Title
  if (chartData.title) {
    const title = document.createElement('h4');
    title.className = 'chart-title';
    title.innerText = chartData.title;
    container.appendChild(title);
  }
  
  // Wrapper div for chart container
  const wrapper = document.createElement('div');
  wrapper.style.position = 'relative';
  wrapper.style.width = '100%';
  wrapper.style.maxWidth = '600px';
  wrapper.style.height = '350px';
  wrapper.style.marginBottom = '20px';
  wrapper.style.backgroundColor = 'rgba(51, 65, 85, 0.3)';
  wrapper.style.borderRadius = '8px';
  wrapper.style.overflow = 'hidden';
  
  // Canvas for Chart.js
  const canvas = document.createElement('canvas');
  canvas.id = chartId;
  canvas.style.display = 'block';
  canvas.style.width = '100%';
  canvas.style.height = '100%';
  wrapper.appendChild(canvas);
  container.appendChild(wrapper);
  
  // Initialize chart after canvas is in DOM
  setTimeout(() => {
    const ctx = document.getElementById(chartId).getContext('2d');
    if (!ctx) {
      console.error('Failed to get canvas context for', chartId);
      return;
    }
    
    // Prepare data
    const labels = chartData.data.map(d => d[chartData.x_key] || d.date);
    const values = chartData.data.map(d => parseFloat(d[chartData.y_key] || d.value) || 0);
    
    // Destroy previous chart instance if it exists
    if (chartInstances[chartId]) {
      chartInstances[chartId].destroy();
    }
    
    // Create chart
    try {
      const chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: chartData.y_key || 'Value',
            data: values,
            borderColor: 'rgba(75, 192, 192, 1)',
            backgroundColor: 'rgba(75, 192, 192, 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.3,
            pointBackgroundColor: 'rgba(75, 192, 192, 1)',
            pointBorderColor: '#fff',
            pointRadius: 4,
            pointHoverRadius: 6
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: true,
              position: 'top',
              labels: {
                color: '#e6eef8',
                font: { size: 12 }
              }
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                color: '#94a3b8'
              },
              grid: {
                color: 'rgba(255, 255, 255, 0.05)'
              }
            },
            x: {
              ticks: {
                color: '#94a3b8'
              },
              grid: {
                color: 'rgba(255, 255, 255, 0.05)'
              }
            }
          }
        }
      });
      
      chartInstances[chartId] = chart;
      console.log('✅ Line chart rendered:', chartId);
    } catch (e) {
      console.error('Error rendering line chart:', e);
    }
  }, 50);
}

function renderTable(tableData, container) {
  // Render table from data array
  const tableEl = document.createElement('table');
  tableEl.className = 'data-table';
  
  // Determine columns
  let columns = tableData.columns || [];
  let rows = tableData.data || [];
  
  // If columns is empty but we have rows, infer from first row
  if (columns.length === 0 && rows.length > 0) {
    const firstRow = rows[0];
    if (Array.isArray(firstRow)) {
      // Raw array format - create generic columns
      columns = firstRow.map((_, i) => ({ key: i, label: 'Column ' + (i + 1) }));
    } else {
      // Object format - use keys as columns
      columns = Object.keys(firstRow).map(key => ({ key: key, label: humanizeLabel(key) }));
    }
  }
  
  // Header
  const thead = document.createElement('thead');
  const headerRow = document.createElement('tr');
  
  columns.forEach(col => {
    const th = document.createElement('th');
    th.innerText = col.label || humanizeLabel(col.key) || col;
    headerRow.appendChild(th);
  });
  thead.appendChild(headerRow);
  tableEl.appendChild(thead);
  
  // Body
  const tbody = document.createElement('tbody');
  rows.forEach(row => {
    const tr = document.createElement('tr');
    
    if (Array.isArray(row)) {
      // Array format
      row.forEach((cell, i) => {
        const td = document.createElement('td');
        td.innerText = formatCellValue(cell);
        tr.appendChild(td);
      });
    } else {
      // Object format
      columns.forEach(col => {
        const td = document.createElement('td');
        const value = row[col.key] !== undefined ? row[col.key] : '';
        td.innerText = formatCellValue(value);
        tr.appendChild(td);
      });
    }
    tbody.appendChild(tr);
  });
  tableEl.appendChild(tbody);
  
  container.appendChild(tableEl);
}

function renderKPI(kpiData, container) {
  // Render KPI metric
  const kpiEl = document.createElement('div');
  kpiEl.className = 'kpi-container';
  
  if (kpiData.title) {
    const title = document.createElement('div');
    title.className = 'kpi-title';
    title.innerText = kpiData.title;
    kpiEl.appendChild(title);
  }
  
  const value = document.createElement('div');
  value.className = 'kpi-value';
  value.innerText = formatCellValue(kpiData.value);
  kpiEl.appendChild(value);
  
  if (kpiData.unit) {
    const unit = document.createElement('div');
    unit.className = 'kpi-unit';
    unit.innerText = kpiData.unit;
    kpiEl.appendChild(unit);
  }
  
  container.appendChild(kpiEl);
}

function humanizeLabel(str) {
  // Convert snake_case or camelCase to Title Case
  if (!str) return '';
  return str
    .replace(/_/g, ' ')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

function formatCellValue(value) {
  // Format value for display
  if (value === null || value === undefined) return '';
  if (typeof value === 'number') {
    if (Number.isInteger(value)) return value.toString();
    return parseFloat(value.toFixed(2)).toString();
  }
  return value.toString();
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const q = input.value.trim();
  if(!q) return;
  addMessage(q, 'user');
  input.value = '';

  const placeholder = addLoading();

  try {
    const res = await fetch('/query', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({question: q})
    });
    
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(txt || 'Server error');
    }
    
    const data = await res.json();
    removeLoading(placeholder);

    // The answer is a JSON string with {text, visualization} structure
    addMessage(data.answer, 'system');
  } catch(err) {
    removeLoading(placeholder);
    addMessage('Error: ' + err.message, 'system');
  }
});

function addLoading() {
  const id = 'loading-' + Date.now();
  const el = document.createElement('div');
  el.id = id;
  el.className = 'msg system';
  const b = document.createElement('div');
  b.className = 'bubble';
  b.innerText = 'Thinking...';
  el.appendChild(b);
  chatEl.appendChild(el);
  chatEl.scrollTop = chatEl.scrollHeight;
  return id;
}

function removeLoading(id) {
  const el = document.getElementById(id);
  if(el) el.remove();
}

