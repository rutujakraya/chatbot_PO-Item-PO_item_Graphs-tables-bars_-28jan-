timepass.txt

also add new thing (feature) if user ask to draw table it should display info in table or if some info can look good in table then provide table even if user don't ask to draw table ( but keep in mind not every response should be in table format)

now give complete prompt again 
also when user asks question like what is ur name, your name, what is kraya AI, it give intent - rag_sql

these type of questons are for llama3 

add somewhere in code if someone asked what is kraya or kraya ai then tell in short 
1. What is Kraya?

Kraya is a digital procurement platform designed to make sourcing, vendor management, and purchasing processes more efficient, transparent, and data-driven.

2. Who uses Kraya?

Kraya is built for business buyers and procurement teams in SMEs and larger enterprises who want to automate purchasing, manage vendors better, and cut costs.

( this is fixed answer )
