#!/usr/bin/env python3
"""Test chatbot functionality with database queries."""

import json
import requests

BASE_URL = "http://localhost:8000"

def test_query(question, test_num, test_name):
    """Test a single question and print results."""
    print(f"\n{'='*70}")
    print(f"TEST {test_num}: {test_name}")
    print(f"{'='*70}")
    print(f"Question: {question}")
    print()
    
    try:
        resp = requests.post(
            f"{BASE_URL}/query",
            json={"question": question},
            timeout=30
        )
        data = resp.json()
        
        print(f"✓ Answer: {data['answer']}")
        print(f"✓ SQL: {data.get('sql', 'N/A')}")
        print(f"✓ Result rows: {len(data.get('result', {}).get('rows', []))}")
        
    except Exception as e:
        print(f"✗ ERROR: {str(e)}")


if __name__ == "__main__":
    tests = [
        ("Show all users with their name and email", 1, "List all users"),
        ("Find the total number of orders in the system", 2, "Count total orders"),
        ("Calculate the total revenue from all orders", 3, "Total revenue"),
        ("Show the average order amount", 4, "Average order amount"),
        ("Show all products and their categories", 5, "All products with categories"),
        ("Find the top 3 users by total spending", 6, "Top 3 users by spending"),
        ("List orders with status equal to COMPLETED", 7, "Completed orders"),
        ("Show orders placed after 2024-01-01", 8, "Recent orders"),
        ("List users who have placed at least one order", 9, "Users with orders"),
        ("Show the number of orders per user", 10, "Orders per user"),
    ]
    
    print("\n" + "🧪 CHATBOT TEST SUITE (10 QUERIES)" + "\n")
    
    for question, num, name in tests:
        test_query(question, num, name)
    
    print("\n" + "="*70)
    print("✅ TEST SUITE COMPLETE")
    print("="*70 + "\n")
