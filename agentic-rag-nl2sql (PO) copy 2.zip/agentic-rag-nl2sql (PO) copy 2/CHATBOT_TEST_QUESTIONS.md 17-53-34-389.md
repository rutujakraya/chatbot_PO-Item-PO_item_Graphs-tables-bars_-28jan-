# Chatbot Test Questions (30 Questions)

## Database Questions (20)
<!-- 


List all purchase orders with their PO number and status.

Show only approved purchase orders.


List the 5 most recently created purchase orders.
Show all items included in PO-001.

For each purchase order, show the total value of its line items.

Show the total ordered quantity per item.

Show all purchase orders along with the number of items in each.

List items with their least purchase price and previous purchase price.

For each purchase order, list item name, quantity, and line total.

Show the top 3 items by total purchase value.

Which item has the highest total ordered quantity? 

How many purchase orders are in draft status?

List all distinct items that have ever been ordered?

---------------------------------------------

 -->

## Dumb Questions (5)

1. **Is a hot dog a sandwich?**
2. **What is the meaning of life?**
3. **Can you tell me a joke?**
4. **What's your favorite color?**
5. **Do you dream of electric sheep?**

## General Questions (5)

1. **How do I reset my password?**
2. **What is your company's privacy policy?**
3. **How can I contact customer support?**
4. **What payment methods do you accept?**
5. **What are your business hours?**

## Edge Cases & Miscellaneous (5)

1. **Show me customers AND orders from January.**
2. **What if I search for non-existent product XYZ123?**
3. **Can you delete all orders?** (permission check)
4. **Show me products sorted by price descending.**
5. **How many customers made purchases in Q1 2025?**

---

## Expected Test Coverage

- **Valid SQL queries**: Questions 1-15 (Database)
- **Out-of-scope queries**: Questions 16-20 (Dumb)
- **Policy/Support queries**: Questions 21-25 (General)
- **Complex queries**: Questions 26-30 (Edge Cases)

## Testing Notes

- Track response accuracy (correct SQL vs incorrect)
- Monitor handling of ambiguous queries
- Test graceful degradation for out-of-scope questions
- Verify permission checks for destructive operations
- Check response formatting and clarity
