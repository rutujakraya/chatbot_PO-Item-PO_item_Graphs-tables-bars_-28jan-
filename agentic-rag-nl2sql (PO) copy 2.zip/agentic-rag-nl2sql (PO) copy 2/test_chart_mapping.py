#!/usr/bin/env python3
"""
Diagnostic: Check if visualization mapper is working correctly
"""

from decimal import Decimal
from agent_visualization_mapper import VisualizationMapper

mapper = VisualizationMapper()

# Test Case 1: Bar chart from backend query
print("=" * 70)
print("TEST 1: Bar Chart from 'Show a bar chart of total amount by purchase order'")
print("=" * 70)

columns = ['purchase_order', 'total_amount']
rows = [
    ['PO-009', 8900.0],
    ['PO-006', 7250.0],
    ['PO-003', 5600.0],
    ['PO-008', 3550.0],
]

viz = mapper.map("Show a bar chart of total amount by purchase order", columns, rows)
print(f"\nVisualization result:")
print(f"  chart_type: {viz.get('chart_type')}")
print(f"  title: {viz.get('title')}")
print(f"  x_key: {viz.get('x_key')}")
print(f"  y_key: {viz.get('y_key')}")
print(f"  data points: {len(viz.get('data', []))}")

if viz.get('data'):
    print(f"\n  First 2 data points:")
    for i, d in enumerate(viz.get('data', [])[:2]):
        print(f"    [{i}]: {d}")
else:
    print("\n  ❌ NO DATA!")

# Test Case 2: Bar chart from 'Draw a bar chart of total purchase amount by status'
print("\n" + "=" * 70)
print("TEST 2: Bar Chart from 'Draw a bar chart of total purchase amount by status'")
print("=" * 70)

columns2 = ['status', 'total_value']
rows2 = [
    ['DRAFT', 38000.0],
    ['REJECTED', 30000.0],
    ['APPROVED', 27000.0],
]

viz2 = mapper.map("Draw a bar chart of total purchase amount by status", columns2, rows2)
print(f"\nVisualization result:")
print(f"  chart_type: {viz2.get('chart_type')}")
print(f"  title: {viz2.get('title')}")
print(f"  x_key: {viz2.get('x_key')}")
print(f"  y_key: {viz2.get('y_key')}")
print(f"  data points: {len(viz2.get('data', []))}")

if viz2.get('data'):
    print(f"\n  All data points:")
    for i, d in enumerate(viz2.get('data', [])):
        print(f"    [{i}]: {d}")
else:
    print("\n  ❌ NO DATA!")

# Test the JSON serialization
print("\n" + "=" * 70)
print("JSON SERIALIZATION TEST")
print("=" * 70)

import json

try:
    json_str = json.dumps(viz2)
    print("✅ Visualization can be serialized to JSON")
    print(f"   Size: {len(json_str)} bytes")
    
    # Parse it back
    parsed = json.loads(json_str)
    print(f"✅ Can be parsed back from JSON")
    print(f"   Data in parsed: {len(parsed.get('data', []))} points")
except Exception as e:
    print(f"❌ JSON serialization error: {e}")

print("\n" + "=" * 70)
