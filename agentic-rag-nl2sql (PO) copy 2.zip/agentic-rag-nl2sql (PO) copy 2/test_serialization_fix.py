#!/usr/bin/env python3
"""
Integration test showing the complete fix for Decimal/datetime serialization
and proper table visualization in the UI.
"""

import json
from decimal import Decimal
from datetime import datetime

# Simulate what the backend does after SQL execution

def normalize_rows(rows: list, columns: list) -> list:
    """Convert Decimal and datetime to JSON-serializable types"""
    if not rows:
        return rows
    
    normalized_rows = []
    for row in rows:
        if isinstance(row, (tuple, list)):
            normalized_row = []
            for value in row:
                if isinstance(value, Decimal):
                    normalized_row.append(float(value))
                elif isinstance(value, datetime):
                    normalized_row.append(value.isoformat())
                else:
                    normalized_row.append(value)
            normalized_rows.append(normalized_row)
        else:
            normalized_rows.append(row)
    
    return normalized_rows


# Test Case: "List the 5 most recently created purchase orders"
# This is the exact query from the error message

print("=" * 70)
print("TEST: List the 5 most recently created purchase orders")
print("=" * 70)

# 1. Simulate database result with Decimal and datetime
columns = ['po_no', 'status', 'total', 'created_at']
rows_from_db = [
    ('PO-001', 'DRAFT', Decimal('5000.00'), datetime(2026, 1, 22, 17, 47, 21, 384554)),
    ('PO-002', 'APPROVED', Decimal('6000.00'), datetime(2026, 1, 21, 17, 47, 21, 384971)),
    ('PO-003', 'REJECTED', Decimal('7000.00'), datetime(2026, 1, 20, 17, 47, 21, 385111)),
    ('PO-004', 'DRAFT', Decimal('8000.00'), datetime(2026, 1, 19, 17, 47, 21, 385253)),
    ('PO-005', 'APPROVED', Decimal('9000.00'), datetime(2026, 1, 18, 17, 47, 21, 385397))
]

print("\n[BACKEND] Raw database result:")
print(f"  Columns: {columns}")
print(f"  First row: {rows_from_db[0]}")
print(f"  Types: {[type(v).__name__ for v in rows_from_db[0]]}")

# 2. Normalize rows
rows_normalized = normalize_rows(rows_from_db, columns)

print("\n[BACKEND] After normalization:")
print(f"  First row: {rows_normalized[0]}")
print(f"  Types: {[type(v).__name__ for v in rows_normalized[0]]}")

# 3. Build response (simulating visualization mapper)
response_payload = {
    "text": "Here are the 5 most recently created purchase orders.",
    "columns": columns,
    "rows": rows_normalized,
    "visualization": {
        "chart_type": "table",
        "columns": [
            {"key": "po_no", "label": "PO Number"},
            {"key": "status", "label": "Status"},
            {"key": "total", "label": "Total"},
            {"key": "created_at", "label": "Created At"}
        ],
        "data": [
            {
                "po_no": row[0],
                "status": row[1],
                "total": row[2],
                "created_at": row[3]
            }
            for row in rows_normalized
        ]
    }
}

# 4. Try to serialize to JSON (this would have failed before)
print("\n[BACKEND] Attempting JSON serialization...")
try:
    json_str = json.dumps(response_payload)
    print("✅ SUCCESS! JSON serialization works")
    print(f"  Response size: {len(json_str)} bytes")
except TypeError as e:
    print(f"❌ FAILED! {e}")
    exit(1)

# 5. Parse on frontend (simulate)
print("\n[FRONTEND] Parsing response...")
parsed = json.loads(json_str)
print(f"✅ Parsed successfully")
print(f"  Text: {parsed['text']}")
print(f"  Columns: {parsed['columns']}")
print(f"  Rows: {len(parsed['rows'])} rows")
print(f"  Visualization type: {parsed['visualization']['chart_type']}")

# 6. Verify table data structure
print("\n[FRONTEND] Table rendering structure:")
print(f"  Column headers: {[c['label'] for c in parsed['visualization']['columns']]}")
print(f"  First row: {parsed['visualization']['data'][0]}")
print(f"  All values JSON-serializable: ✅")

# 7. Show what the UI will render
print("\n[UI DISPLAY] Expected output:")
print("\n  Text Response:")
print(f"    {parsed['text']}\n")
print("  Table:")
print(f"    | {' | '.join([c['label'] for c in parsed['visualization']['columns']])} |")
print(f"    | {'-' * 60} |")
for row in parsed['visualization']['data']:
    values = [str(row[col['key']]) for col in parsed['visualization']['columns']]
    print(f"    | {' | '.join(values)} |")

print("\n" + "=" * 70)
print("✅ COMPLETE FIX VERIFIED")
print("=" * 70)
print("\nSummary:")
print("  ✓ Decimal values converted to float")
print("  ✓ Datetime objects converted to ISO string")
print("  ✓ JSON serialization succeeds")
print("  ✓ Frontend can parse and render table")
print("  ✓ No 'Object of type Decimal is not JSON serializable' error")
print("\nThe user will see a properly formatted table with all 5 POs.")
