#!/usr/bin/env python3
"""
Comprehensive test suite for GROUP BY + SQL generation fixes.
Tests all four main issues that were fixed:
1. SQL validation rejecting CTEs
2. GROUP BY + ORDER BY handling
3. Intelligent error detection and correction
4. Proper fallback patterns
"""

from agent_orchestrator import AgentOrchestrator
import sys

def test_groupby_queries():
    """Test GROUP BY queries that were previously failing"""
    
    test_cases = [
        {
            "question": "Show all purchase orders along with the number of items in each",
            "expected": ["po_no", "item_count"],
            "min_rows": 5
        },
        {
            "question": "What is the total value by PO status?",
            "expected": ["status", "total_value"],
            "min_rows": 2
        },
        {
            "question": "Show me PO numbers with how many items each has",
            "expected": ["po_no", "item_count"],
            "min_rows": 5
        },
        {
            "question": "List each PO with its total items and value",
            "expected": ["po_no", "item_count"],
            "min_rows": 5
        }
    ]
    
    results = []
    orchestrator = AgentOrchestrator()
    
    for i, test in enumerate(test_cases, 1):
        print(f"\nTest {i}: {test['question']}")
        print("-" * 70)
        
        try:
            result = orchestrator.run(test['question'])
            
            # Check answer
            answer = result.get('answer', '')
            has_data = answer and 'not available' not in answer.lower()
            
            # Check SQL
            sql = result.get('sql', '')
            has_sql = bool(sql)
            
            # Count attempts
            attempts = len([x for x in result.get('agent_flow', []) if 'Attempt' in x])
            
            success = has_data and has_sql and attempts <= 5
            
            results.append({
                'test': test['question'],
                'success': success,
                'has_data': has_data,
                'has_sql': has_sql,
                'attempts': attempts,
                'answer_preview': answer.split('\n')[0][:60] if answer else 'No answer'
            })
            
            status = "✅ PASS" if success else "❌ FAIL"
            print(f"{status} - Attempts: {attempts}, Data: {has_data}, SQL: {has_sql}")
            print(f"Answer: {results[-1]['answer_preview']}...")
            
        except Exception as e:
            print(f"❌ EXCEPTION: {str(e)[:60]}")
            results.append({
                'test': test['question'],
                'success': False,
                'error': str(e)[:60]
            })
    
    return results

def print_summary(results):
    """Print test summary"""
    print("\n" + "=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)
    
    passed = sum(1 for r in results if r.get('success'))
    total = len(results)
    
    for r in results:
        status = "✅" if r.get('success') else "❌"
        print(f"{status} {r['test'][:50]}")
    
    print("-" * 70)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 ALL GROUP BY QUERIES NOW WORKING!")
        return 0
    else:
        print(f"\n⚠️  {total - passed} tests failed")
        return 1

if __name__ == "__main__":
    print("=" * 70)
    print("GROUP BY + SQL GENERATION FIX TEST SUITE")
    print("=" * 70)
    
    results = test_groupby_queries()
    exit_code = print_summary(results)
    sys.exit(exit_code)
