from decimal import Decimal
from datetime import datetime
import json

# Test normalization
def normalize_rows(rows, columns):
    if not rows:
        return rows
    
    normalized_rows = []
    for row in rows:
        if isinstance(row, (tuple, list)):
            normalized_row = []
            for value in row:
                if isinstance(value, Decimal):
                    normalized_row.append(float(value))
                elif isinstance(value, datetime):
                    normalized_row.append(value.isoformat())
                else:
                    normalized_row.append(value)
            normalized_rows.append(normalized_row)
        else:
            normalized_rows.append(row)
    
    return normalized_rows

# Test data
rows = [
    ('PO-001', 'DRAFT', Decimal('5000.00'), datetime(2026, 1, 22)),
    ('PO-002', 'APPROVED', Decimal('6000.00'), datetime(2026, 1, 21))
]

normalized = normalize_rows(rows, ['po_no', 'status', 'total', 'created_at'])
response = {
    "text": "Here are 2 purchase orders:",
    "columns": ['po_no', 'status', 'total', 'created_at'],
    "rows": normalized,
    "visualization": {
        "chart_type": "table",
        "columns": [
            {"key": "po_no", "label": "PO Number"},
            {"key": "status", "label": "Status"},
            {"key": "total", "label": "Total"},
            {"key": "created_at", "label": "Created At"}
        ],
        "data": [
            {"po_no": row[0], "status": row[1], "total": row[2], "created_at": row[3]}
            for row in normalized
        ]
    }
}

# Test JSON serialization
json_str = json.dumps(response)
print("✅ JSON serialization works!")
print(json_str)
