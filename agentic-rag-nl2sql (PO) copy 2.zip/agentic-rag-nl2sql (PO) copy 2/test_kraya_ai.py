#!/usr/bin/env python3
"""
Quick validation script for Kraya AI greeting/goodbye/thanks detection.
Run this to verify the implementation works as expected.

Usage:
    python3 test_kraya_ai.py
"""

from agent_planner import PlannerAgent

def test_greetings_and_goodbyes():
    """Test greeting/goodbye/thanks detection with exact matches AND misspellings."""
    planner = PlannerAgent()
    
    test_cases = [
        # === EXACT GREETINGS ===
        ("hi", "greeting"),
        ("hello", "greeting"),
        ("hey there", "greeting"),
        ("good morning", "greeting"),
        ("good afternoon", "greeting"),
        ("good evening", "greeting"),
        ("welcome", "greeting"),
        
        # === GREETING MISSPELLINGS ===
        ("helo", "greeting"),          # missing 'l'
        ("helloo", "greeting"),        # extra 'l'
        ("hii", "greeting"),           # extra 'i'
        ("hiiii", "greeting"),         # multiple extra 'i's
        ("heyy", "greeting"),          # extra 'y'
        ("welcom", "greeting"),        # missing letter
        
        # === EXACT GOODBYES ===
        ("bye", "goodbye"),
        ("bye bye", "goodbye"),
        ("goodbye", "goodbye"),
        ("see you", "goodbye"),
        ("see you later", "goodbye"),
        ("farewell", "goodbye"),
        ("see ya", "goodbye"),
        
        # === GOODBYE MISSPELLINGS ===
        ("byee", "goodbye"),           # extra 'e'
        ("byebye", "goodbye"),         # variant
        ("goodbyee", "goodbye"),       # extra 'e'
        ("see yaa", "goodbye"),        # extra 'a'
        ("farewel", "goodbye"),        # missing 'l'
        
        # === EXACT THANKS ===
        ("thank you", "thanks"),
        ("thanks", "thanks"),
        ("appreciate it", "thanks"),
        ("much appreciated", "thanks"),
        ("thx", "thanks"),
        
        # === THANKS MISSPELLINGS ===
        ("thankss", "thanks"),         # extra 's'
        ("thankyou", "thanks"),        # no space (still detects "thank")
        ("apreciate", "thanks"),       # misspelled "appreciate"
        ("appreciatee", "thanks"),     # extra 'e'
        
        # === NON-MATCHING (SHOULD RETURN NONE) ===
        ("How many users do we have?", None),
        ("What is a database?", None),
        ("Show me recent orders", None),
        ("Can you tell me a joke?", None),
        ("List all employees in Sales", None),  # Should go to RAG+SQL, not a greeting
    ]
    
    print("=" * 60)
    print("KRAYA AI - GREETING/GOODBYE/THANKS DETECTION TEST")
    print("=" * 60)
    
    passed = 0
    failed = 0
    
    for query, expected in test_cases:
        result = planner.detect_greeting_or_goodbye(query)
        status = "✅ PASS" if result == expected else "❌ FAIL"
        
        if result == expected:
            passed += 1
        else:
            failed += 1
        
        print(f"{status} | Query: '{query}'")
        print(f"         Expected: {expected}, Got: {result}")
        print()
    
    print("=" * 60)
    print(f"SUMMARY: {passed} passed, {failed} failed")
    print("=" * 60)
    
    return failed == 0

def test_intent_classification():
    """Test that database-related questions go through RAG+SQL pipeline."""
    planner = PlannerAgent()
    
    test_cases = [
        # === DATABASE QUESTIONS (SHOULD BE 'rag_sql') ===
        ("List all employees in the Sales department", "rag_sql"),
        ("Total revenue from Electronics category", "rag_sql"),
        ("How many orders last month?", "rag_sql"),
        ("Show me recent customers", "rag_sql"),
        ("Revenue by product category", "rag_sql"),
        ("Employees in Finance department", "rag_sql"),
        ("What products are in stock?", "rag_sql"),
        
        # === GENERAL QUESTIONS (SHOULD BE 'direct') ===
        ("What is supply chain management?", "direct"),
        ("How does inflation work?", "direct"),
        ("Tell me a joke", "direct"),
        ("Who was Napoleon?", "direct"),
        ("What's the weather?", "direct"),
        ("Explain machine learning", "direct"),
    ]
    
    print("\n" + "=" * 60)
    print("KRAYA AI - INTENT CLASSIFICATION TEST")
    print("=" * 60)
    
    passed = 0
    failed = 0
    
    for query, expected in test_cases:
        result = planner.classify_intent(query)
        status = "✅ PASS" if result == expected else "❌ FAIL"
        
        if result == expected:
            passed += 1
        else:
            failed += 1
        
        print(f"{status} | Query: '{query}'")
        print(f"         Expected: {expected}, Got: {result}")
        print()
    
    print("=" * 60)
    print(f"SUMMARY: {passed} passed, {failed} failed")
    print("=" * 60)
    
    return failed == 0

if __name__ == "__main__":
    test1_passed = test_greetings_and_goodbyes()
    test2_passed = test_intent_classification()
    
    all_passed = test1_passed and test2_passed
    exit(0 if all_passed else 1)
