#!/usr/bin/env python3
"""
Database Initialization Script — Phase 1
==========================================
This script:
1. Ensures PostgreSQL database exists with Phase 1 procurement schema (po, po_items, items)
2. Initializes Qdrant with db_metadata.txt chunks
3. Verifies all connections work
"""

import os
import sys
import psycopg2
from psycopg2 import sql
from datetime import datetime, timedelta
from uuid import uuid4
from sentence_transformers import SentenceTransformer
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct

# ============================================================================
# PART 1: Ensure PostgreSQL database has Phase 1 schema with sample data
# ============================================================================

def init_postgresql():
    """Initialize PostgreSQL database with Phase 1 procurement schema."""
    print("\n" + "="*60)
    print("INITIALIZING POSTGRESQL DATABASE")
    print("="*60)
    
    try:
        # Connect to PostgreSQL
        conn = psycopg2.connect(
            dbname="procure_phase1_first3tables",
            user="rutujadhage",
            password="",
            host="localhost",
            port=5432
        )
        cursor = conn.cursor()
        print("✓ Connected to PostgreSQL (procure_phase1_first3tables)")
        
        # Drop existing tables to recreate with fixes
        cursor.execute("DROP TABLE IF EXISTS po_items CASCADE;")
        cursor.execute("DROP TABLE IF EXISTS po CASCADE;")
        cursor.execute("DROP TABLE IF EXISTS items CASCADE;")
        
        # === CREATE ITEMS TABLE ===
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS items (
                id UUID PRIMARY KEY,
                name TEXT NOT NULL,
                code_sku TEXT NOT NULL UNIQUE,
                item_type TEXT NOT NULL DEFAULT 'GOODS',
                company_id UUID NOT NULL,
                item_category_id UUID,
                item_subcategory_id UUID,
                item_classification TEXT,
                parent_item_management_body_id UUID,
                hsn_code TEXT,
                sac_code TEXT,
                gst_percent NUMERIC(10, 2),
                item_tax_preference TEXT NOT NULL DEFAULT 'TAXABLE',
                uom TEXT NOT NULL,
                sale_uom TEXT,
                tolerence NUMERIC(10, 4),
                size_or_weight TEXT,
                ean_or_batch TEXT,
                base_price NUMERIC(12, 2),
                landing_price NUMERIC(12, 2),
                selling_price NUMERIC(12, 2),
                mrp NUMERIC(12, 2),
                margin NUMERIC(10, 2),
                additional_discount_after_billing_before_tax_percent NUMERIC(5, 2),
                additional_discount_after_billing_before_tax_value NUMERIC(12, 2),
                least_purchase_price NUMERIC(12, 2),
                least_purchase_company_vendor_id UUID,
                least_purchase_date TIMESTAMP,
                least_purchase_po_id UUID,
                previous_purchase_price NUMERIC(12, 2),
                previous_purchase_company_vendor_id UUID,
                previous_purchase_date TIMESTAMP,
                previous_purchase_po_id UUID,
                status TEXT DEFAULT 'APPROVED',
                is_editable BOOLEAN DEFAULT TRUE,
                is_enabled BOOLEAN DEFAULT TRUE,
                is_deleted BOOLEAN,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                deleted_at TIMESTAMP,
                sent_for_approval_at TIMESTAMP,
                approved_at TIMESTAMP,
                cancelled_at TIMESTAMP,
                cancellation_remark TEXT,
                sent_for_approval_by_id UUID,
                last_updated_by_id UUID NOT NULL,
                cancelled_by_user_id UUID,
                item_image TEXT,
                primary_item_image TEXT,
                item_images TEXT[],
                inventory_entries JSONB,
                created_by_user JSONB,
                sent_for_approval_by JSONB,
                item_category JSONB,
                item_subcategory JSONB,
                company JSONB
            );
        """)
        print("✓ Table items created/exists")
        
        # === CREATE PO TABLE ===
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS po (
                id UUID PRIMARY KEY,
                po_no TEXT NOT NULL UNIQUE,
                po_type TEXT DEFAULT 'STANDARD',
                company_id UUID NOT NULL,
                company_vendor_id UUID,
                vendor_id UUID,
                shipping_store_location_id UUID,
                purchase_location_id UUID,
                created_by_user_id UUID NOT NULL,
                last_updated_by_user_id UUID NOT NULL,
                sent_for_approval_by_id UUID,
                sent_to_vendor_by_id UUID,
                contact_person_type TEXT DEFAULT 'INTERNAL',
                contact_person_id UUID,
                external_contact_person_id UUID,
                status TEXT DEFAULT 'DRAFT',
                accepted_or_rejected_by_vendor_at TIMESTAMP,
                sent_for_approval_at TIMESTAMP,
                sent_to_vendor_at TIMESTAMP,
                is_deleted BOOLEAN,
                delivery_date TIMESTAMP,
                request_date TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                deleted_at TIMESTAMP,
                subtotal NUMERIC(14, 2),
                total NUMERIC(14, 2),
                remaining_amount_for_invoices NUMERIC(14, 2) DEFAULT 0,
                parent_quote_id UUID,
                comparative_id UUID,
                tnc_id UUID,
                pt_id UUID,
                rejection_remark TEXT,
                attachment_link TEXT,
                terms_and_conditions TEXT,
                delivery_schedule TEXT,
                payment_terms TEXT,
                remark TEXT,
                company JSONB,
                purchase_location JSONB,
                shipping_store_location JSONB,
                created_by_user JSONB,
                last_updated_by_user JSONB,
                company_vendor JSONB,
                contact_person JSONB,
                external_contact_person JSONB,
                sent_for_approval_by JSONB,
                sent_to_vendor_by JSONB,
                parent_quote JSONB,
                comparative JSONB,
                items JSONB,
                boms JSONB,
                approval_chain JSONB,
                taxes JSONB
            );
        """)
        print("✓ Table po created/exists")
        
        # === CREATE PO_ITEMS TABLE ===
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS po_items (
                id UUID PRIMARY KEY,
                company_id UUID NOT NULL,
                parent_po_id UUID REFERENCES po(id),
                item_id UUID REFERENCES items(id),
                item_name TEXT NOT NULL,
                code_sku TEXT NOT NULL,
                item_type TEXT,
                type TEXT,
                hsn_code TEXT,
                sac_code TEXT,
                uom TEXT,
                tolerence NUMERIC(10, 4),
                requested_quantity NUMERIC(14, 2),
                provided_quantity NUMERIC(14, 2),
                per_unit_rate NUMERIC(12, 2),
                discount_value NUMERIC(12, 2),
                discount_type TEXT,
                gst NUMERIC(5, 2),
                total NUMERIC(14, 2),
                parent_po_bom_id UUID,
                parent_po_bom_code TEXT,
                referenced_comparative_item_id UUID,
                is_deleted BOOLEAN,
                deleted_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP,
                attachment_link TEXT,
                remark TEXT,
                company JSONB,
                item JSONB,
                parent_po JSONB,
                parent_po_bom JSONB,
                referenced_comparative_item JSONB
            );
        """)
        print("✓ Table po_items created/exists")
        
        # Check row counts
        cursor.execute("SELECT COUNT(*) FROM items;")
        items_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM po;")
        po_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM po_items;")
        po_items_count = cursor.fetchone()[0]
        
        print(f"\nCurrent data:")
        print(f"  • items: {items_count} rows")
        print(f"  • po: {po_count} rows")
        print(f"  • po_items: {po_items_count} rows")
        
        # Insert sample data if empty
        if items_count == 0:
            print("\nInserting sample items...")
            sample_items = [
                ("Cement (50kg)", "CEMENT-50", "GOODS", "2523", 500, 550),
                ("Steel TMT 12mm", "STEEL-TMT-12", "GOODS", "7326", 45, 50),
                ("Paint (10L)", "PAINT-10L", "GOODS", "3208", 400, 450),
                ("Wood (Ply)", "WOOD-PLY", "GOODS", "4407", 800, 900),
                ("Labour Service", "LABOUR-SVC", "SERVICE", "9989", 150, 200),
            ]
            
            company_id = str(uuid4())
            user_id = str(uuid4())
            
            for name, sku, itype, hsn, base_price, selling_price in sample_items:
                try:
                    cursor.execute("""
                        INSERT INTO items (
                            id, name, code_sku, item_type, company_id,
                            hsn_code, gst_percent, uom, base_price, selling_price,
                            status, is_enabled, last_updated_by_id, created_at
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                        str(uuid4()), name, sku, itype, company_id,
                        hsn, 18.0, "UNIT", base_price, selling_price,
                        "APPROVED", True, user_id, datetime.now()
                    ))
                except Exception as e:
                    if "unique constraint" in str(e).lower() or "duplicate key" in str(e).lower():
                        pass  # Item SKU already exists, skip
                    else:
                        raise
            
            conn.commit()
            cursor.execute("SELECT COUNT(*) FROM items;")
            new_count = cursor.fetchone()[0]
            print(f"  ✓ Added items. Total: {new_count}")
        
        if po_count == 0:
            print("\nInserting sample purchase orders...")
            cursor.execute("SELECT id FROM items LIMIT 5;")
            item_ids = [row[0] for row in cursor.fetchall()]
            
            company_id = str(uuid4())
            vendor_id = str(uuid4())
            user_id = str(uuid4())
            
            po_ids = []
            for i in range(10):
                po_id = str(uuid4())
                po_no = f"PO-{str(i+1).zfill(3)}"
                status = ["DRAFT", "APPROVED", "REJECTED"][i % 3]
                total_val = 5000 + (i * 1000)
                
                try:
                    cursor.execute("""
                        INSERT INTO po (
                            id, po_no, status, company_id, vendor_id,
                            created_by_user_id, last_updated_by_user_id,
                            total, remaining_amount_for_invoices,
                            created_at
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                        po_id, po_no, status, company_id, vendor_id,
                        user_id, user_id, total_val, total_val,
                        datetime.now() - timedelta(days=i)
                    ))
                    po_ids.append(po_id)
                except Exception as e:
                    if "unique constraint" in str(e).lower() or "duplicate key" in str(e).lower():
                        # Get existing PO ID
                        cursor.execute("SELECT id FROM po WHERE po_no = %s;", (po_no,))
                        result = cursor.fetchone()
                        if result:
                            po_ids.append(result[0])
                    else:
                        raise
            
            conn.commit()
            cursor.execute("SELECT COUNT(*) FROM po;")
            new_count = cursor.fetchone()[0]
            print(f"  ✓ Added POs. Total: {new_count}")
            
            # Insert PO line items
            if po_count == 0 and item_ids:
                print("\nInserting PO line items...")
                for i, po_id in enumerate(po_ids):
                    # 1-3 items per PO
                    for j in range(1 + (i % 3)):
                        item_id = item_ids[j % len(item_ids)]
                        
                        cursor.execute("SELECT name, code_sku FROM items WHERE id = %s;", (item_id,))
                        item_name, item_sku = cursor.fetchone()
                        
                        qty = 10 + (i * j)
                        rate = 100 + (j * 50)
                        line_total = qty * rate
                        
                        cursor.execute("""
                            INSERT INTO po_items (
                                id, company_id, parent_po_id, item_id,
                                item_name, code_sku, item_type,
                                requested_quantity, per_unit_rate,
                                gst, total, uom,
                                created_at
                            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
                        """, (
                            str(uuid4()), company_id, po_id, item_id,
                            item_name, item_sku, "GOODS",
                            qty, rate, 18.0, line_total, "UNIT",
                            datetime.now()
                        ))
                
                conn.commit()
                cursor.execute("SELECT COUNT(*) FROM po_items;")
                new_count = cursor.fetchone()[0]
                print(f"  ✓ Added PO line items. Total: {new_count}")
        
        cursor.close()
        conn.close()
        print("\n✅ PostgreSQL initialization complete!")
        return True
        
    except Exception as e:
        print(f"\n❌ PostgreSQL error: {e}")
        print("\nMake sure PostgreSQL is running and database 'procure_phase1_first3tables' exists:")
        print("  createdb procure_phase1_first3tables")
        return False


# ============================================================================
# PART 2: Initialize Qdrant with metadata chunks
# ============================================================================

def chunk_metadata_by_sections(text):
    """
    Chunk db_metadata.txt by logical sections AND by content density.
    Creates more granular chunks for better RAG retrieval.
    
    Returns list of tuples: (section_title, chunk_text, table_category)
    """
    chunks_with_metadata = []
    
    # Split by major sections first
    section_markers = {
        "## Table: po": "po",
        "## Table: items": "items",
        "## Table: po_items": "po_items",
        "## Relationships": "relationships",
        "## NL→SQL Mapping": "nl_sql_rules",
        "## Common Example Questions": "examples",
        "## Best-Practice Guidance": "guidance",
    }
    
    # Split text by section markers
    current_section = "Overview"
    current_table = "general"
    current_chunk_lines = []
    
    lines = text.split('\n')
    
    for i, line in enumerate(lines):
        # Check if this line is a section marker
        matched_section = False
        for marker, table_type in section_markers.items():
            if line.strip().startswith(marker.replace("## ", "")):
                # Save previous chunk
                if current_chunk_lines:
                    chunk_text = '\n'.join(current_chunk_lines).strip()
                    if len(chunk_text) > 30:
                        chunks_with_metadata.append((
                            current_section,
                            chunk_text,
                            current_table
                        ))
                
                # Start new section
                current_section = marker.replace("## ", "").strip()
                current_table = table_type
                current_chunk_lines = [line]
                matched_section = True
                break
        
        if not matched_section:
            current_chunk_lines.append(line)
            
            # For table definitions, break into smaller chunks at key boundaries
            if current_table in ["po", "items", "po_items"] and len(current_chunk_lines) > 15:
                # Check if we have a complete definition block (e.g., after a blank line following content)
                if line.strip() == "" and len(current_chunk_lines) > 5:
                    chunk_text = '\n'.join(current_chunk_lines).strip()
                    if len(chunk_text) > 30:
                        chunks_with_metadata.append((
                            f"{current_section} - Part {len(chunks_with_metadata) % 5 + 1}",
                            chunk_text,
                            current_table
                        ))
                    current_chunk_lines = []
    
    # Don't forget last chunk
    if current_chunk_lines:
        chunk_text = '\n'.join(current_chunk_lines).strip()
        if len(chunk_text) > 30:
            chunks_with_metadata.append((
                current_section,
                chunk_text,
                current_table
            ))
    
    # If we only have 1-2 chunks, create additional synthetic chunks for key concepts
    if len(chunks_with_metadata) < 8:
        # Add synthetic chunks for critical concepts and common queries
        synthetic_chunks = [
            ("PO-Item Relationship & Joins", 
             "Purchase Orders (po) are related to Purchase Order Items (po_items) via: "
             "po.id = po_items.parent_po_id. "
             "Items table (items) is related to po_items via: items.id = po_items.item_id. "
             "This allows querying: which items are in a specific PO, which POs contain a specific item, "
             "service-type vs goods-type items, item order counts.",
             "relationships"),
            
            ("Aggregation & Counting Queries",
             "To count items ordered (highest): SELECT item_name, COUNT(*) FROM po_items GROUP BY item_name ORDER BY COUNT(*) DESC. "
             "To count by quantity: SELECT item_name, SUM(requested_quantity) FROM po_items GROUP BY item_name. "
             "To sum PO totals: SELECT status, SUM(total) FROM po GROUP BY status. "
             "To find totals for approved POs: SELECT SUM(total) FROM po WHERE status = 'APPROVED'.",
             "nl_sql_rules"),
             
            ("Item Type Filtering",
             "Items have an item_type column with values like 'GOODS' or 'SERVICE'. "
             "To find service-type items in purchase orders: "
             "SELECT DISTINCT poi.item_name FROM po_items poi JOIN items i ON poi.item_id = i.id WHERE i.item_type = 'SERVICE'. "
             "To find POs containing service items: "
             "SELECT DISTINCT p.po_no FROM po p JOIN po_items poi ON p.id = poi.parent_po_id JOIN items i ON poi.item_id = i.id WHERE i.item_type = 'SERVICE'.",
             "nl_sql_rules"),
             
            ("Searching for Specific Items",
             "To find POs containing Cement: "
             "SELECT DISTINCT p.po_no, p.status, p.total FROM po p JOIN po_items poi ON p.id = poi.parent_po_id WHERE poi.item_name LIKE '%Cement%' OR poi.code_sku LIKE '%CEMENT%'. "
             "Item names in po_items table come from items.name, and code_sku from items.code_sku.",
             "nl_sql_rules"),
             
            ("Data Availability Summary",
             "Tables available: po (purchase orders), items (master item list), po_items (line items per PO). "
             "Key po columns: id, po_no, status (DRAFT/APPROVED/REJECTED), total, created_at. "
             "Key items columns: id, name, code_sku, item_type (GOODS/SERVICE), base_price, selling_price. "
             "Key po_items columns: parent_po_id, item_id, item_name, code_sku, requested_quantity, per_unit_rate, gst, total. "
             "All use soft-delete: is_deleted column.",
             "guidance"),
             
            ("Cost & GST Calculations",
             "Total GST amount: SUM(gst * total) or SUM((requested_quantity * per_unit_rate * gst / 100)) from po_items. "
             "Total PO value: SUM(total) from po or SUM(total) from po_items grouped by parent_po_id. "
             "All monetary amounts are NUMERIC(12,2) for price fields, NUMERIC(14,2) for totals.",
             "nl_sql_rules"),
        ]
        
        for title, text, table_type in synthetic_chunks:
            chunks_with_metadata.append((title, text, table_type))
    
    return chunks_with_metadata


def init_qdrant():
    """
    Initialize Qdrant with Phase 1 procurement metadata.
    
    Creates a NEW collection to keep old metadata separate.
    Chunks by logical sections for better RAG retrieval.
    """
    print("\n" + "="*60)
    print("INITIALIZING QDRANT — PHASE 1 PROCUREMENT METADATA")
    print("="*60)
    
    # Collection name for Phase 1 (different from old "rag_schema_chunks")
    COLLECTION_NAME = "procure_phase1_metadata"
    
    try:
        # Connect to Qdrant
        client = QdrantClient(url="http://localhost:6333")
        print("✓ Connected to Qdrant")
        
        # Check if collection exists
        collections = client.get_collections()
        collection_exists = any(c.name == COLLECTION_NAME for c in collections.collections)
        
        if collection_exists:
            print(f"✓ Collection '{COLLECTION_NAME}' already exists")
            collection_info = client.get_collection(COLLECTION_NAME)
            print(f"  Current points: {collection_info.points_count}")
            
            if collection_info.points_count > 0:
                print(f"✓ Collection already has {collection_info.points_count} chunks. Skipping population.")
                return True
        
        # Load db_metadata.txt
        if not os.path.exists("db_metadata.txt"):
            print("❌ db_metadata.txt not found!")
            return False
        
        with open("db_metadata.txt", "r") as f:
            metadata_text = f.read()
        
        print(f"✓ Loaded db_metadata.txt ({len(metadata_text)} bytes)")
        
        # Load embedding model (same model used by RetrievalAgent)
        print("Loading embedding model (BAAI/bge-small-en-v1.5)...")
        model = SentenceTransformer("BAAI/bge-small-en-v1.5")
        embedding_dim = 384
        print(f"✓ Model loaded (dimension: {embedding_dim})")
        
        # Create collection if doesn't exist
        if not collection_exists:
            client.create_collection(
                collection_name=COLLECTION_NAME,
                vectors_config=VectorParams(size=embedding_dim, distance=Distance.COSINE),
            )
            print(f"✓ Created NEW collection '{COLLECTION_NAME}' (separate from old metadata)")
        
        # Chunk by logical sections
        chunks_with_metadata = chunk_metadata_by_sections(metadata_text)
        print(f"✓ Split metadata into {len(chunks_with_metadata)} semantic chunks")
        
        # Embed and create points with rich metadata
        print("\nEmbedding and upserting chunks...")
        points = []
        for i, (section_title, chunk_text, table_category) in enumerate(chunks_with_metadata):
            # Embed the chunk
            embedding = model.encode(chunk_text).tolist()
            
            # Rich payload for accurate RAG retrieval
            point = PointStruct(
                id=i,
                vector=embedding,
                payload={
                    "text": chunk_text,
                    "source": "db_metadata.txt",
                    "database": "procure_phase1_first3tables",
                    "table": table_category,  # po, items, po_items, relationships, nl_sql_rules, guidance, general
                    "section_title": section_title,
                    "chunk_index": i,
                    "token_count": len(chunk_text.split()),  # Approximate token count
                }
            )
            points.append(point)
        
        # Upsert points in batches
        batch_size = 20
        for i in range(0, len(points), batch_size):
            batch = points[i:i+batch_size]
            client.upsert(
                collection_name=COLLECTION_NAME,
                points=batch
            )
            print(f"  ✓ Upserted {min(i+batch_size, len(points))}/{len(points)} chunks")
        
        print(f"\n✅ Qdrant initialization complete!")
        print(f"   Collection: '{COLLECTION_NAME}'")
        print(f"   Chunks: {len(points)}")
        print(f"\n   Update retriever to use: {COLLECTION_NAME}")
        return True
        
    except Exception as e:
        print(f"\n❌ Qdrant error: {e}")
        print("\nMake sure Qdrant is running:")
        print("  docker run -p 6333:6333 qdrant/qdrant")
        return False


# ============================================================================
# PART 3: Verify connections
# ============================================================================

def verify_connections():
    """Verify that all connections work."""
    print("\n" + "="*60)
    print("VERIFYING CONNECTIONS")
    print("="*60)
    
    # Test PostgreSQL
    try:
        conn = psycopg2.connect(
            dbname="procure_phase1_first3tables",
            user="rutujadhage",
            password="",
            host="localhost",
            port=5432
        )
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM po;")
        po_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM items;")
        items_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM po_items;")
        po_items_count = cursor.fetchone()[0]
        cursor.close()
        conn.close()
        print(f"✓ PostgreSQL: Connected (po={po_count}, items={items_count}, po_items={po_items_count})")
    except Exception as e:
        print(f"❌ PostgreSQL: {e}")
        return False
    
    # Test Qdrant
    try:
        client = QdrantClient(url="http://localhost:6333")
        collection_info = client.get_collection("rag_schema_chunks")
        print(f"✓ Qdrant: Connected (rag_schema_chunks has {collection_info.points_count} points)")
    except Exception as e:
        print(f"❌ Qdrant: {e}")
        return False
    
    print("\n✅ All connections verified!")
    return True


# ============================================================================
# Main
# ============================================================================

if __name__ == "__main__":
    print("\n" + "="*60)
    print("DATABASE INITIALIZATION SCRIPT")
    print("="*60)
    
    # Step 1: Initialize PostgreSQL
    if not init_postgresql():
        sys.exit(1)
    
    # Step 2: Initialize Qdrant
    if not init_qdrant():
        print("\n⚠️  Qdrant initialization failed.")
        print("Make sure Qdrant is running:")
        print("  docker run -p 6333:6333 qdrant/qdrant")
        sys.exit(1)
    
    # Step 3: Verify
    if not verify_connections():
        sys.exit(1)
    
    print("\n" + "="*60)
    print("✅ INITIALIZATION COMPLETE!")
    print("="*60)
    print("\nYou can now run the application:")
    print("  python -m uvicorn app:app --reload --host 0.0.0.0 --port 8000")
    print("\nTest with:")
    print("  curl -X POST http://localhost:8000/query \\")
    print("    -H 'Content-Type: application/json' \\")
    print("    -d '{\"question\": \"How many users do we have?\"}'")
