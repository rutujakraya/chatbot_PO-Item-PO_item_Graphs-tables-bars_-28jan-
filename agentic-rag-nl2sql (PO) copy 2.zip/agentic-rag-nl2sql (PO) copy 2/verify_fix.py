#!/usr/bin/env python3
"""Quick test to verify 'helo' is detected as greeting, not rag_sql."""

from agent_planner import PlannerAgent

planner = PlannerAgent()

# Test the original issue
user_query = "helo"

# Step 1: Check if greeting is detected
greeting_result = planner.detect_greeting_or_goodbye(user_query)
print(f"Input: '{user_query}'")
print(f"Greeting detection result: {greeting_result}")

if greeting_result == "greeting":
    print("✓ FIXED! 'helo' is now correctly detected as a greeting")
    print("  The system will return a greeting response instead of trying rag_sql")
else:
    print("✗ FAILED! 'helo' is still not detected as a greeting")
    
    # Step 2: If not detected as greeting, check intent classification (old behavior)
    intent = planner.classify_intent(user_query)
    print(f"Intent classification result: {intent}")
    if intent == "rag_sql":
        print("  The system is still incorrectly treating it as rag_sql")

print("\n" + "="*70 + "\n")

# Test all the user's examples
examples = ["hi", "hey", "heyyyym", "hhhhey", "heeeeey", "hhhhelo", "heeeelo", "heollo"]
print("Testing user's greeting examples:")
for example in examples:
    result = planner.detect_greeting_or_goodbye(example)
    status = "✓" if result == "greeting" else "✗"
    print(f"{status} '{example}' -> {result}")
